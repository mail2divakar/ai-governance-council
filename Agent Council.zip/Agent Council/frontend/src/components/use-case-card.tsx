import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/status-badge";
import { MessageSquare, Clock, ArrowRight, Building2, Users, Database, Trash2 } from "lucide-react";
import { format } from "date-fns";
import type { UseCase, DecisionStatus } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";

interface UseCaseCardProps {
  useCase: UseCase;
}

export function UseCaseCard({ useCase }: UseCaseCardProps) {
  const status = (useCase.status as DecisionStatus | null) || "PENDING";
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/use-cases/${useCase.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases"] });
      toast({
        title: "Use case deleted",
        description: "The use case has been permanently deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Deletion failed",
        description: "Could not delete the use case. Please try again.",
        variant: "destructive",
      });
    },
  });


  return (
    <ContextMenu>
      <ContextMenuTrigger>
        <Card

          className="group hover-elevate transition-all duration-200"
          data-testid={`card-usecase-${useCase.id}`}
        >
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-base text-card-foreground truncate">
                  {useCase.title || "Untitled Use Case"}
                </h3>
              </div>
              <StatusBadge status={status} size="sm" />
            </div>
          </CardHeader>

          <CardContent className="pb-4">
            {useCase.whatTheAIDoes && (
              <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                {useCase.whatTheAIDoes}
              </p>
            )}

            <div className="grid grid-cols-2 gap-3">
              {useCase.whoUsesIt && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Users className="h-3.5 w-3.5 flex-shrink-0" />
                  <span className="truncate">{useCase.whoUsesIt}</span>
                </div>
              )}
              {useCase.dataItMightTouch && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Database className="h-3.5 w-3.5 flex-shrink-0" />
                  <span className="truncate">{useCase.dataItMightTouch}</span>
                </div>
              )}
            </div>

            {useCase.governanceDomains && useCase.governanceDomains.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-3">
                {useCase.governanceDomains.slice(0, 2).map((domain: string) => (
                  <span
                    key={domain}
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-accent/50 text-accent-foreground"
                  >
                    {domain?.replace(/_/g, " ")}
                  </span>
                ))}
                {useCase.governanceDomains.length > 2 && (
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-muted text-muted-foreground">
                    +{useCase.governanceDomains.length - 2}
                  </span>
                )}
              </div>
            )}
          </CardContent>

          <CardFooter className="pt-0 flex items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span>
                {useCase.createdAt
                  ? format(new Date(useCase.createdAt), "MMM d, yyyy")
                  : "Recently"}
              </span>
            </div>
            <Button variant="ghost" size="sm" asChild className="gap-1.5">
              <Link href={`/use-case/${useCase.id}/overview`} data-testid={`link-usecase-${useCase.id}`}>
                <MessageSquare className="h-3.5 w-3.5" />
                View Overview
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </ContextMenuTrigger>
      <ContextMenuContent>
        <ContextMenuItem
          className="text-destructive focus:text-destructive cursor-pointer"
          onClick={() => {
            if (confirm("Are you sure you want to delete this use case? This action cannot be undone.")) {
              deleteMutation.mutate();
            }
          }}
        >
          <Trash2 className="h-4 w-4 mr-2" />
          Delete
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}

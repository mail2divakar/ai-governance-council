import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Shield, ShieldAlert, ShieldCheck, ChevronDown, ChevronUp } from "lucide-react";
import type { RiskLevel } from "@shared/schema";

interface RiskPanelProps {
  score: number;
  level: RiskLevel;
  drivers: string[];
  compact?: boolean;
}

const levelConfig: Record<RiskLevel, {
  color: string;
  bgColor: string;
  icon: typeof Shield;
}> = {
  LOW: {
    color: "text-emerald-700 dark:text-emerald-400",
    bgColor: "bg-emerald-100 dark:bg-emerald-900/30",
    icon: ShieldCheck,
  },
  MEDIUM: {
    color: "text-amber-700 dark:text-amber-400",
    bgColor: "bg-amber-100 dark:bg-amber-900/30",
    icon: Shield,
  },
  HIGH: {
    color: "text-red-700 dark:text-red-400",
    bgColor: "bg-red-100 dark:bg-red-900/30",
    icon: ShieldAlert,
  },
};

export function RiskPanel({ score, level, drivers, compact = false }: RiskPanelProps) {
  const [expanded, setExpanded] = useState(false);
  const config = levelConfig[level] || levelConfig.LOW;
  const Icon = config.icon;

  return (
    <div 
      className={`rounded-md border p-2 ${config.bgColor}`}
      data-testid="risk-panel"
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Icon className={`h-4 w-4 ${config.color}`} />
          <span className={`text-xs font-semibold ${config.color}`} data-testid="risk-score">
            Risk: {score}
          </span>
          <Badge 
            variant="outline" 
            className={`text-xs px-1.5 py-0 ${config.color} border-current`}
            data-testid="risk-level-badge"
          >
            {level}
          </Badge>
        </div>
        {drivers && drivers.length > 0 && (
          <button
            onClick={() => setExpanded(!expanded)}
            className={`flex items-center gap-1 text-xs ${config.color} hover:underline`}
            data-testid="button-toggle-drivers"
          >
            {expanded ? (
              <>Hide <ChevronUp className="h-3 w-3" /></>
            ) : (
              <>Drivers <ChevronDown className="h-3 w-3" /></>
            )}
          </button>
        )}
      </div>
      
      {expanded && drivers && drivers.length > 0 && (
        <div className="mt-2 pt-2 border-t border-current/10">
          <ul className="space-y-0.5" data-testid="risk-drivers">
            {drivers.slice(0, 3).map((driver, idx) => (
              <li key={idx} className="text-xs text-muted-foreground flex items-start gap-1.5">
                <AlertTriangle className="h-3 w-3 mt-0.5 shrink-0" />
                <span>{driver}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export function RiskBadge({ level }: { level: RiskLevel }) {
  const config = levelConfig[level] || levelConfig.LOW;
  
  return (
    <Badge 
      variant="outline" 
      className={`text-xs ${config.color} ${config.bgColor} border-current`}
      data-testid={`risk-badge-${level.toLowerCase()}`}
    >
      {level}
    </Badge>
  );
}

import React from "react";
import { FileText, PencilRuler, Hammer, ShieldCheck, Rocket, ActivitySquare } from "lucide-react";
interface WorkflowPhase {
  id: string;
  label: string;
  number: number;
  description?: string;
  icon?: React.ElementType;
}

const WORKFLOW_PHASES: WorkflowPhase[] = [
  { id: "intake", label: "Intake", number: 1, description: "Use Case Registration", icon: FileText },
  { id: "design", label: "Design", number: 2, description: "Architecture & Data Flow", icon: PencilRuler },
  { id: "develop", label: "Develop", number: 3, description: "Build & Engineering", icon: Hammer },
  { id: "validate", label: "Validate", number: 4, description: "Testing & Compliance", icon: ShieldCheck },
  { id: "deploy", label: "Deploy", number: 5, description: "Release & Access", icon: Rocket },
  { id: "monitor", label: "Monitor", number: 6, description: "Performance & Drift", icon: ActivitySquare },
];

interface WorkflowTabsProps {
  currentPhase: string;
  completedPhases?: string[];
  onTabChange?: (phaseId: string) => void;
}

export function WorkflowStepper({ currentPhase, onTabChange, completedPhases = [] }: WorkflowTabsProps) {
  return (
    <div className="w-full">
      <div className="px-4 pt-3">
        <div className="inline-flex bg-muted rounded-lg p-1">
          {WORKFLOW_PHASES.map((phase) => {
            const isActive = phase.id === currentPhase;
            const isCompleted = completedPhases.includes(phase.id);
            const Icon = phase.icon;

            return (
              <button
                key={phase.id}
                onClick={() => onTabChange && onTabChange(phase.id)}
                type="button"
                className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md transition-all duration-200
                  ${isActive
                    ? "bg-background shadow-sm text-foreground"
                    : isCompleted
                      ? "text-primary hover:text-primary/80"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
              >
                {Icon && <Icon className={`w-4 h-4 ${isCompleted && !isActive ? "text-primary" : ""}`} />}
                {phase.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}


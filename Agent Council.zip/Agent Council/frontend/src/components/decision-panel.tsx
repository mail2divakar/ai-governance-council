import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/status-badge";
import { CheckCircle2, XCircle, AlertTriangle, HelpCircle } from "lucide-react";
import type { Decision, DecisionStatus } from "@shared/schema";

interface DecisionPanelProps {
  decision?: Decision | null;
  onApprove?: () => void;
  onDisapprove?: () => void;
  onRequestInfo?: () => void;
  onApproveWithConditions?: () => void;
  isLoading?: boolean;
  canDecide?: boolean;
}

export function DecisionPanel({
  decision,
  onApprove,
  onDisapprove,
  onRequestInfo,
  onApproveWithConditions,
  isLoading,
  canDecide = true,
}: DecisionPanelProps) {
  if (decision) {
    return (
      <Card className="border-2" data-testid="panel-decision-result">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <CardTitle className="text-lg">Governance Decision</CardTitle>
            <StatusBadge status={decision.status as DecisionStatus} />
          </div>
        </CardHeader>
        <CardContent>
          {decision.rationale && decision.rationale.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-foreground">Rationale</h4>
              <ul className="space-y-1.5">
                {decision.rationale.map((item: string, index: number) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="text-muted-foreground/60 mt-1">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  if (!canDecide) {
    return null;
  }

  return (
    <Card className="border-2 border-dashed" data-testid="panel-decision-actions">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Ready to Decide?</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">
          Review the assessment and make a governance decision for this AI use case.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={onApprove}
            disabled={isLoading}
            className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
            data-testid="button-approve"
          >
            <CheckCircle2 className="h-4 w-4" />
            Approve
          </Button>
          <Button
            onClick={onApproveWithConditions}
            disabled={isLoading}
            variant="outline"
            className="gap-1.5 border-amber-500 text-amber-700 hover:bg-amber-50 dark:border-amber-600 dark:text-amber-400 dark:hover:bg-amber-950"
            data-testid="button-approve-conditions"
          >
            <AlertTriangle className="h-4 w-4" />
            Approve with Conditions
          </Button>
          <Button
            onClick={onRequestInfo}
            disabled={isLoading}
            variant="outline"
            className="gap-1.5"
            data-testid="button-request-info"
          >
            <HelpCircle className="h-4 w-4" />
            Needs More Info
          </Button>
          <Button
            onClick={onDisapprove}
            disabled={isLoading}
            variant="destructive"
            className="gap-1.5"
            data-testid="button-disapprove"
          >
            <XCircle className="h-4 w-4" />
            Disapprove
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

import { Check } from "lucide-react";
import type { Stage } from "@shared/schema";

interface ProgressStepsProps {
  currentStep?: number;
  totalSteps?: number;
  labels?: string[];
  stage?: Stage;
}

const defaultLabels = [
  "Basic Info",
  "Details",
  "Assessment",
  "Decision",
];

const stageToStep: Record<Stage, number> = {
  BASIC_INFO: 1,
  DETAILS: 2,
  ASSESSMENT: 3,
  DECISION: 4,
};

export function ProgressSteps({ currentStep, totalSteps = 4, labels = defaultLabels, stage }: ProgressStepsProps) {
  const activeStep = stage ? stageToStep[stage] : (currentStep || 1);
  
  return (
    <div className="flex items-center justify-center gap-2 py-4" data-testid="stage-stepper">
      {Array.from({ length: totalSteps }, (_, i) => {
        const stepNumber = i + 1;
        const isComplete = stepNumber < activeStep;
        const isCurrent = stepNumber === activeStep;

        return (
          <div key={stepNumber} className="flex items-center">
            <div className="flex flex-col items-center">
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium transition-colors ${
                  isComplete
                    ? "bg-primary text-primary-foreground"
                    : isCurrent
                    ? "bg-primary text-primary-foreground ring-2 ring-primary ring-offset-2 ring-offset-background"
                    : "bg-muted text-muted-foreground"
                }`}
                data-testid={`step-indicator-${stepNumber}`}
              >
                {isComplete ? <Check className="h-4 w-4" /> : stepNumber}
              </div>
              {labels[i] && (
                <span 
                  className={`mt-1.5 text-xs font-medium ${
                    isCurrent ? "text-foreground" : "text-muted-foreground"
                  }`}
                  data-testid={`step-label-${stepNumber}`}
                >
                  {labels[i]}
                </span>
              )}
            </div>
            
            {stepNumber < totalSteps && (
              <div
                className={`h-0.5 w-12 mx-2 ${
                  isComplete ? "bg-primary" : "bg-muted"
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

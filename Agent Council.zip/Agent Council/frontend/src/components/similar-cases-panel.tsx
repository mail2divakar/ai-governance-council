import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp, AlertCircle, Clock, ArrowRight, MessageSquare } from "lucide-react";
import { format } from "date-fns";

interface SimilarUseCase {
  id: string;
  title: string;
  threadStatus: string | null;
  riskLevel: string | null;
  stage: string | null;
  similarity: number;
  createdAt: string | null;
  whatTheAIDoes?: string | null;
}

interface SimilarCasesPanelProps {
  useCaseId?: string;
  similarCases?: SimilarUseCase[];
}

function getStatusColor(status: string | null): string {
  switch (status) {
    case "approved":
      return "bg-green-500/10 text-green-700 dark:text-green-400";
    case "disapproved":
      return "bg-red-500/10 text-red-700 dark:text-red-400";
    case "approval_required":
      return "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400";
    case "data_required":
      return "bg-blue-500/10 text-blue-700 dark:text-blue-400";
    default:
      return "bg-muted text-muted-foreground";
  }
}

function getStatusLabel(status: string | null): string {
  switch (status) {
    case "approved":
      return "Approved";
    case "disapproved":
      return "Disapproved";
    case "approval_required":
      return "Pending Approval";
    case "data_required":
      return "Data Required";
    case "info_required":
      return "Info Required";
    default:
      return "In Progress";
  }
}

function getRiskBadgeColor(level: string | null): string {
  switch (level) {
    case "HIGH":
      return "bg-red-500/10 text-red-700 dark:text-red-400";
    case "MEDIUM":
      return "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400";
    case "LOW":
      return "bg-green-500/10 text-green-700 dark:text-green-400";
    default:
      return "bg-muted text-muted-foreground";
  }
}

export function SimilarCasesPanel({ useCaseId, similarCases: propSimilarCases }: SimilarCasesPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  const { data: fetchSimilarCases, isLoading, error } = useQuery<SimilarUseCase[]>({
    queryKey: ["/api/use-cases", useCaseId, "similar"],
    enabled: !!useCaseId && !propSimilarCases,
  });

  const similarCases = propSimilarCases || fetchSimilarCases;

  if (isLoading && !propSimilarCases) {
    return (
      <div className="space-y-2" data-testid="similar-cases-loading">
        <Skeleton className="h-10 w-full rounded-lg" />
      </div>
    );
  }

  if (error || !similarCases || similarCases.length === 0) {
    return null;
  }

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <CollapsibleTrigger asChild>
        <Button
          variant="outline"
          className="w-full justify-between border-amber-500/30 bg-amber-50/50 dark:bg-amber-950/20"
          data-testid="similar-cases-toggle"
        >
          <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
            <AlertCircle className="h-4 w-4" />
            <span className="text-sm font-medium">
              {similarCases.length} Similar Use Case{similarCases.length > 1 ? "s" : ""} Found
            </span>
          </div>
          {isOpen ? (
            <ChevronUp className="h-4 w-4 text-amber-700 dark:text-amber-400" />
          ) : (
            <ChevronDown className="h-4 w-4 text-amber-700 dark:text-amber-400" />
          )}
        </Button>
      </CollapsibleTrigger>
      
      <CollapsibleContent className="mt-2 space-y-3" data-testid="similar-cases-panel">
        <p className="text-xs text-muted-foreground px-1">
          Consider reviewing these similar use cases to avoid duplicate work.
        </p>
        
        {similarCases.map((uc) => (
          <Card 
            key={uc.id}
            className="hover-elevate transition-all duration-200"
            data-testid={`similar-case-${uc.id}`}
          >
            <CardHeader className="pb-2 pt-3 px-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm text-card-foreground truncate">
                    {uc.title}
                  </h4>
                </div>
                <Badge 
                  variant="secondary" 
                  className={`text-xs shrink-0 ${getStatusColor(uc.threadStatus)}`}
                >
                  {getStatusLabel(uc.threadStatus)}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="pb-2 px-3">
              <div className="flex items-center gap-2 flex-wrap">
                {uc.riskLevel && (
                  <Badge variant="secondary" className={`text-xs ${getRiskBadgeColor(uc.riskLevel)}`}>
                    {uc.riskLevel}
                  </Badge>
                )}
                <span className="text-xs text-muted-foreground">
                  {Math.round(uc.similarity * 100)}% similar
                </span>
              </div>
            </CardContent>
            
            <CardFooter className="pt-0 pb-2 px-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span>
                  {uc.createdAt
                    ? format(new Date(uc.createdAt), "MMM d, yyyy")
                    : "Recently"}
                </span>
              </div>
              <Button variant="ghost" size="sm" asChild className="h-7 gap-1 text-xs">
                <Link href={`/use-case/${uc.id}`} data-testid={`view-similar-${uc.id}`}>
                  <MessageSquare className="h-3 w-3" />
                  View
                  <ArrowRight className="h-3 w-3" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </CollapsibleContent>
    </Collapsible>
  );
}

import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
    ChevronLeft, ChevronRight, Shield, ShieldAlert, 
    ShieldCheck, AlertCircle, FileText, TrendingUp, 
    Zap, Wrench, Info 
} from "lucide-react";
import type { UseCase, Stage, RiskLevel } from "@shared/schema";

interface QuestionConfig {
    id: string;
    section: string;
    label: string;
    type: string;
    extractionPrompt: string | null;
    weight: number | null;
    isActive: number;
}

interface IntakeFormPanelProps {
    useCase?: UseCase | null;
    stage: Stage;
    riskScore: number;
    riskLevel: RiskLevel;
    riskDrivers: string[];
    onFieldChange: (field: string, value: string | number, isSensitive: boolean, label?: string) => void;
    readOnly?: boolean;
}

const SECTION_META: Record<string, { label: string; color: string; icon: any; bg: string }> = {
    BASIC: { label: "Basic Info", color: "text-blue-600", icon: FileText, bg: "bg-blue-50 dark:bg-blue-950/30" },
    RISK: { label: "Risk Assessment", color: "text-red-600", icon: Shield, bg: "bg-red-50 dark:bg-red-950/30" },
    BENEFIT: { label: "Benefit Assessment", color: "text-green-600", icon: TrendingUp, bg: "bg-green-50 dark:bg-green-950/30" },
    MITIGATION: { label: "Mitigation Strategy", color: "text-amber-600", icon: Wrench, bg: "bg-amber-50 dark:bg-amber-950/30" },
    TECHNICAL: { label: "Technical Details", color: "text-purple-600", icon: Zap, bg: "bg-purple-50 dark:bg-purple-950/30" },
};

const RISK_REASONINGS: Record<number, string> = {
    1: "Low likelihood - Decoupled with minimal sensitivity.",
    2: "Low-Medium - Standard operational boundaries.",
    3: "Medium - Involves moderate complexity or data sensitivity.",
    4: "High - Operates in a complex environment or handles sensitive data.",
    5: "Critical - High-stakes decisions or unproven technology.",
};

const SECTION_ORDER = ["BASIC", "RISK", "MITIGATION", "BENEFIT", "TECHNICAL"];

export function IntakeFormPanel({
    useCase,
    stage,
    riskScore,
    riskLevel,
    riskDrivers,
    onFieldChange,
    readOnly = false,
}: IntakeFormPanelProps) {
    const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
    const [localVals, setLocalVals] = useState<Record<string, string>>({});

    const { data: configs = [], isLoading: isLoadingConfigs } = useQuery<QuestionConfig[]>({
        queryKey: ["/api/admin/questions"],
    });

    const activeConfigs = useMemo(() => configs.filter(c => c.isActive), [configs]);
    
    const groupedSections = useMemo(() => {
        const groups: Record<string, QuestionConfig[]> = {};
        activeConfigs.forEach(c => {
            if (!groups[c.section]) groups[c.section] = [];
            groups[c.section].push(c);
        });
        
        // Return only sections that have questions, in defined order
        return SECTION_ORDER.filter(s => groups[s]?.length > 0)
            .map(s => ({ id: s, questions: groups[s] }));
    }, [activeConfigs]);

    const currentSection = groupedSections[currentSectionIndex];

    const getFieldValue = (fieldId: string) => {
        if (localVals[fieldId] !== undefined) return localVals[fieldId];
        if (!useCase) return "";
        // Check direct model field first
        if (fieldId in useCase) {
            return (useCase as any)[fieldId] ?? "";
        }
        // Check dynamicAnswers
        return useCase.dynamicAnswers?.[fieldId] ?? "";
    };

    const handleTextChange = (fieldId: string, value: string) => {
        setLocalVals(prev => ({ ...prev, [fieldId]: value }));
    };

    const handleBlur = (fieldId: string, value: string, type: string, label?: string) => {
        const originalVal = (() => {
            if (!useCase) return "";
            if (fieldId in useCase) {
                return (useCase as any)[fieldId] ?? "";
            }
            return useCase.dynamicAnswers?.[fieldId] ?? "";
        })();
        
        if (value !== originalVal) {
             handleFieldUpdate(fieldId, value, type, label);
        }
    };

    const handleFieldUpdate = (fieldId: string, value: any, type: string, label?: string) => {
        let finalValue = value;
        if (type.startsWith("scale_") || type === "number") {
            finalValue = value ? parseInt(value) : 0;
        }

        const isSensitive = currentSection?.id === "RISK" || currentSection?.id === "BENEFIT";
        onFieldChange(fieldId, finalValue, isSensitive, label);
    };

    const riskConfig = useMemo(() => {
        switch (riskLevel) {
            case "HIGH":
            case "CRITICAL":
                return { icon: ShieldAlert, color: "text-red-600", bg: "bg-red-50 dark:bg-red-950/30" };
            case "MEDIUM":
                return { icon: Shield, color: "text-amber-600", bg: "bg-amber-50 dark:bg-amber-950/30" };
            default:
                return { icon: ShieldCheck, color: "text-emerald-600", bg: "bg-emerald-50 dark:bg-emerald-950/30" };
        }
    }, [riskLevel]);

    const RiskIcon = riskConfig.icon;

    if (isLoadingConfigs) {
        return (
            <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-[400px] w-full" />
            </div>
        );
    }

    if (groupedSections.length === 0) {
        return <div className="p-8 text-center text-muted-foreground">No intake questions configured.</div>;
    }

    const nextSection = () => {
        if (currentSectionIndex < groupedSections.length - 1) {
            setCurrentSectionIndex(i => i + 1);
        }
    };

    const prevSection = () => {
        if (currentSectionIndex > 0) {
            setCurrentSectionIndex(i => i - 1);
        }
    };

    const renderInput = (q: QuestionConfig) => {
        const val = getFieldValue(q.id);

        switch (q.type) {
            case "scale_1_5":
            case "scale_1_3":
                const max = q.type === "scale_1_5" ? 5 : 3;
                return (
                    <Select value={val.toString()} onValueChange={v => handleFieldUpdate(q.id, v, q.type, q.label)} disabled={readOnly}>
                        <SelectTrigger className="h-9">
                            <SelectValue placeholder="Select level..." />
                        </SelectTrigger>
                        <SelectContent>
                            {Array.from({ length: max }, (_, i) => i + 1).map(n => (
                                <SelectItem key={n} value={n.toString()}>{n}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                );
            case "boolean":
                return (
                    <div className="flex items-center gap-2 h-9 px-1">
                        <Switch 
                            checked={val === "yes" || val === "true" || val === 1} 
                            onCheckedChange={c => handleFieldUpdate(q.id, c ? "yes" : "no", q.type, q.label)} 
                            disabled={readOnly}
                        />
                        <span className="text-xs text-muted-foreground">{val === "yes" ? "Yes" : "No"}</span>
                    </div>
                );
            case "select":
                // Basic select handling, would ideally have options in config
                return (
                    <Input 
                        value={val} 
                        onChange={e => handleTextChange(q.id, e.target.value)}
                        onBlur={e => handleBlur(q.id, e.target.value, q.type, q.label)}
                        className="h-9"
                        disabled={readOnly}
                    />
                );
            default:
                if (q.id.toLowerCase().includes("description") || q.id.toLowerCase().includes("strategy") || q.id.toLowerCase().includes("reasoning") || q.id.toLowerCase().includes("summary")) {
                    return (
                        <Textarea 
                            value={val} 
                            onChange={e => handleTextChange(q.id, e.target.value)}
                            onBlur={e => handleBlur(q.id, e.target.value, q.type, q.label)}
                            className="min-h-[80px] text-sm"
                            disabled={readOnly}
                        />
                    );
                }
                return (
                    <Input 
                        value={val} 
                        onChange={e => handleTextChange(q.id, e.target.value)}
                        onBlur={e => handleBlur(q.id, e.target.value, q.type, q.label)}
                        className="h-9"
                        disabled={readOnly}
                    />
                );
        }
    };

    const sectionMeta = SECTION_META[currentSection.id] || { label: currentSection.id, color: "text-foreground", icon: FileText, bg: "" };
    const SectionIcon = sectionMeta.icon;

    return (
        <div className="space-y-4">
            {/* Header Info Card */}
            <Card className={`${riskConfig.bg} border-0`}>
                <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <RiskIcon className={`h-5 w-5 ${riskConfig.color}`} />
                        <div>
                            <div className="flex items-center gap-2">
                                <span className={`text-sm font-semibold ${riskConfig.color}`}>
                                    Risk: {riskLevel}
                                </span>
                                <Badge variant="secondary" className="text-[10px] h-4">Step {currentSectionIndex + 1} of {groupedSections.length}</Badge>
                            </div>
                            <p className="text-[10px] text-muted-foreground">Score: {riskScore} · Stage: {stage}</p>
                        </div>
                    </div>
                    <div className="flex gap-1.5 overflow-hidden">
                        {groupedSections.map((s, idx) => (
                            <div 
                                key={s.id} 
                                className={`h-1.5 w-6 rounded-full transition-all ${idx === currentSectionIndex ? 'bg-primary' : idx < currentSectionIndex ? 'bg-primary/50' : 'bg-muted'}`}
                            />
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Questions Section */}
            <Card className="overflow-hidden border-muted-foreground/10">
                <CardHeader className={`py-3 px-4 flex flex-row items-center gap-2 border-b ${sectionMeta.bg}`}>
                    <SectionIcon className={`h-4 w-4 ${sectionMeta.color}`} />
                    <CardTitle className="text-sm font-semibold">{sectionMeta.label}</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-5">
                    {currentSection.questions.map(q => (
                        <div key={q.id} className="space-y-1.5">
                            <div className="flex items-center justify-between">
                                <Label className="text-xs font-semibold flex items-center gap-1.5">
                                    {q.label}
                                    {q.extractionPrompt && (
                                        <div className="group relative">
                                            <Info className="h-3 w-3 text-muted-foreground" />
                                            <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block w-48 p-2 bg-popover text-[10px] rounded border shadow-lg z-50">
                                                AI extracts this from your description.
                                            </div>
                                        </div>
                                    )}
                                </Label>
                            </div>
                            {renderInput(q)}
                        </div>
                    ))}
                </CardContent>
            </Card>

            {/* Navigation Buttons */}
            <div className="flex items-center justify-between gap-4 pt-2">
                <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={prevSection} 
                    disabled={currentSectionIndex === 0}
                    className="gap-1.5"
                >
                    <ChevronLeft className="h-4 w-4" />
                    Back
                </Button>
                <div className="text-[11px] text-muted-foreground font-medium">
                    {sectionMeta.label}
                </div>
                <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={nextSection} 
                    disabled={currentSectionIndex === groupedSections.length - 1}
                    className="gap-1.5"
                >
                    Next
                    <ChevronRight className="h-4 w-4" />
                </Button>
            </div>
        </div>
    );
}

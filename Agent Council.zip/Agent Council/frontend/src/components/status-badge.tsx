import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, AlertTriangle, HelpCircle, Clock } from "lucide-react";
import type { DecisionStatus } from "@shared/schema";

const statusConfig: Record<string, {
  label: string;
  variant: "default" | "secondary" | "destructive" | "outline";
  className: string;
  icon: typeof CheckCircle2;
}> = {
  PENDING: {
    label: "Pending",
    variant: "secondary",
    className: "bg-muted text-muted-foreground",
    icon: Clock,
  },
  APPROVED: {
    label: "Approved",
    variant: "default",
    className: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
    icon: CheckCircle2,
  },
  REJECTED: {
    label: "Rejected",
    variant: "destructive",
    className: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
    icon: XCircle,
  },
  MORE_INFO_NEEDED: {
    label: "Needs Info",
    variant: "outline",
    className: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400 border-blue-300 dark:border-blue-700",
    icon: HelpCircle,
  },
};

interface StatusBadgeProps {
  status: DecisionStatus;
  showIcon?: boolean;
  size?: "sm" | "default";
}

export function StatusBadge({ status, showIcon = true, size = "default" }: StatusBadgeProps) {
  const config = statusConfig[status] || statusConfig.PENDING;
  const Icon = config.icon;

  return (
    <Badge
      variant={config.variant}
      className={`${config.className} ${size === "sm" ? "text-xs px-2 py-0.5" : "px-3 py-1"} font-medium gap-1.5`}
      data-testid={`badge-status-${status.toLowerCase()}`}
    >
      {showIcon && <Icon className={size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5"} />}
      {config.label}
    </Badge>
  );
}

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Shield, User } from "lucide-react";
import { format } from "date-fns";
import type { Message } from "@shared/schema";

interface ChatMessageProps {
  message: Message;
  userImage?: string | null;
  userName?: string;
}

export function ChatMessage({ message, userImage, userName }: ChatMessageProps) {
  const isAgent = message.role === "agent";

  return (
    <div
      className={`flex gap-4 ${isAgent ? "justify-start" : "justify-end"}`}
      data-testid={`message-${message.id}`}
    >
      {isAgent && (
        <Avatar className="h-9 w-9 flex-shrink-0 ring-2 ring-primary/20">
          <AvatarFallback className="bg-primary text-primary-foreground">
            <Shield className="h-4 w-4" />
          </AvatarFallback>
        </Avatar>
      )}

      <div className={`flex flex-col gap-1 ${isAgent ? "max-w-3xl" : "max-w-2xl"}`}>
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-muted-foreground">
            {isAgent ? "AI Governance Co-Pilot Agent" : userName || "You"}
          </span>
          {message.createdAt && (
            <span className="text-xs text-muted-foreground/70">
              {format(new Date(message.createdAt), "h:mm a")}
            </span>
          )}
        </div>

        <div
          className={`rounded-xl px-4 py-3 ${isAgent
              ? "bg-card border border-card-border text-card-foreground"
              : "bg-primary text-primary-foreground"
            }`}
        >
          <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
        </div>
      </div>

      {!isAgent && (
        <Avatar className="h-9 w-9 flex-shrink-0 ring-2 ring-muted">
          <AvatarImage src={userImage || undefined} alt={userName} />
          <AvatarFallback className="bg-muted text-muted-foreground">
            <User className="h-4 w-4" />
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
}

import { useLocation, Link } from "wouter";
import { Plus, LogOut, Shield, MessageSquare, History, LayoutDashboard, Trash2, Settings, UserPlus } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import { useToast } from "@/hooks/use-toast";
import type { UseCase, CouncilChatSession } from "@shared/schema";

function getStatusBadge(threadStatus: string | null) {
  const status = threadStatus || "info_required";

  const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    info_required: { label: "info required", variant: "secondary" },
    data_required: { label: "data required", variant: "outline" },
    approval_required: { label: "approval required", variant: "default" },
    approved: { label: "approved", variant: "default" },
    disapproved: { label: "disapproved", variant: "destructive" },
  };

  const config = statusConfig[status] || statusConfig.info_required;

  return (
    <Badge
      variant={config.variant}
      className={`text-[10px] px-1.5 py-0 h-5 whitespace-nowrap ${status === "approved" ? "bg-green-600 hover:bg-green-700 text-white" : ""
        }`}
    >
      {config.label}
    </Badge>
  );
}

function formatTimeAgo(date: Date | string | null): string {
  if (!date) return "";
  const d = new Date(date);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return d.toLocaleDateString();
}

export function AppSidebar({ onSelectSession }: { onSelectSession?: (sessionId: string | null) => void }) {
  const [location, navigate] = useLocation();
  const { user, logout, devLogout, isLoggingOut, isCouncil, isProject, isAdmin } = useAuth();
  const { toast } = useToast();

  const { data: useCases = [] } = useQuery<UseCase[]>({
    queryKey: ["/api/use-cases"],
    enabled: !!isProject,
  });

  const { data: chatSessions = [] } = useQuery<CouncilChatSession[]>({
    queryKey: ["/api/council/chat/sessions"],
    enabled: !!isCouncil,
  });

  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/council/chat/sessions", { title: "New Chat" });
      return res.json();
    },
    onSuccess: (newSession: CouncilChatSession) => {
      queryClient.invalidateQueries({ queryKey: ["/api/council/chat/sessions"] });
      if (onSelectSession) {
        onSelectSession(newSession.id);
      }
      navigate("/");
    },
  });

  const deleteUseCaseMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/use-cases/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases"] });
      toast({
        title: "Use case deleted",
        description: "The use case has been permanently deleted.",
      });
      // If we were on the deleted use case page, navigate to dashboard
      if (location.startsWith("/use-case/")) {
        navigate("/dashboard");
      }
    },
    onError: () => {
      toast({
        title: "Deletion failed",
        description: "Could not delete the use case. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return "U";
  };

  const getDisplayName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user?.email || "User";
  };

  const handleLogout = () => {
    if (user?.username) {
      devLogout();
    } else {
      logout();
    }
  };

  const isNewCaseActive = location === "/new" || location === "/";

  return (
    <Sidebar className="border-r border-sidebar-border bg-sidebar/95 backdrop-blur supports-[backdrop-filter]:bg-sidebar/60">
      <SidebarHeader className="p-4">
        <Link href="/" className="flex items-center gap-3 hover-elevate rounded-lg p-2 -m-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
            <Shield className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="text-base font-semibold text-sidebar-foreground">AI Governance Co-Pilot</span>
            <span className="text-xs text-muted-foreground">
              {isCouncil ? "Council" : "Governance Agent"}
            </span>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarSeparator />

      <SidebarContent className="px-2">
        {isCouncil ? (
          <>
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={() => {
                        createSessionMutation.mutate();
                      }}
                      disabled={createSessionMutation.isPending}
                      tooltip="Start a new conversation"
                      className="h-11"
                      data-testid="button-new-conversation"
                    >
                      <Plus className="h-4 w-4" />
                      <span className="font-medium">New Conversation</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarSeparator className="my-2" />

            <SidebarGroup className="flex-1 overflow-hidden">
              <SidebarGroupLabel className="text-xs font-medium text-muted-foreground px-2 flex items-center gap-2">
                <History className="h-3 w-3" />
                History
              </SidebarGroupLabel>
              <SidebarGroupContent className="overflow-y-auto">
                <SidebarMenu>
                  {chatSessions.length === 0 ? (
                    <div className="px-2 py-4 text-center text-sm text-muted-foreground">
                      No conversations yet
                    </div>
                  ) : (
                    chatSessions.map((session) => (
                      <SidebarMenuItem key={session.id}>
                        <SidebarMenuButton
                          onClick={() => {
                            if (onSelectSession) {
                              onSelectSession(session.id);
                            }
                            navigate("/");
                          }}
                          className="h-auto py-2 px-2"
                          data-testid={`history-session-${session.id}`}
                        >
                          <div className="flex items-start gap-2 w-full min-w-0">
                            <MessageSquare className="h-4 w-4 mt-0.5 flex-shrink-0 text-muted-foreground" />
                            <div className="flex-1 min-w-0 space-y-1">
                              <span className="text-sm truncate block">
                                {session.title || "New Chat"}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {formatTimeAgo(session.updatedAt)}
                              </span>
                            </div>
                          </div>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))
                  )}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </>
        ) : (
          <>
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      asChild
                      isActive={location === "/dashboard"}
                      tooltip="Dashboard"
                      className="h-11"
                      data-testid="nav-dashboard"
                    >
                      <Link href="/dashboard">
                        <LayoutDashboard className="h-4 w-4" />
                        <span className="font-medium">Dashboard</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  {isProject && (
                    <SidebarMenuItem>
                      <SidebarMenuButton
                        asChild
                        isActive={isNewCaseActive}
                        tooltip="Start a new AI use case intake"
                        className="h-11"
                        data-testid="nav-new"
                      >
                        <Link href="/new">
                          <Plus className="h-4 w-4" />
                          <span className="font-medium">New Use Case</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            {isAdmin && (
              <>
                <SidebarSeparator className="my-2" />
                <SidebarGroup>
                  <SidebarGroupLabel className="text-xs font-medium text-muted-foreground px-2">Admin</SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu>
                      <SidebarMenuItem>
                        <SidebarMenuButton
                          asChild
                          isActive={location === "/admin/questions"}
                          tooltip="Manage intake question config, prompts and weights"
                          className="h-11"
                        >
                          <Link href="/admin/questions">
                            <Settings className="h-4 w-4" />
                            <span className="font-medium">Question Config</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <SidebarMenuButton
                          asChild
                          isActive={location === "/admin/documents"}
                          tooltip="Manage Knowledge Base Documents"
                          className="h-11"
                        >
                          <Link href="/admin/documents">
                            <Settings className="h-4 w-4" />
                            <span className="font-medium">Knowledge Base</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <SidebarMenuButton
                          asChild
                          isActive={location === "/admin/users"}
                          tooltip="Invite and Manage Users"
                          className="h-11"
                        >
                          <Link href="/admin/users">
                            <UserPlus className="h-4 w-4" />
                            <span className="font-medium">User Management</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
              </>
            )}

            <SidebarSeparator className="my-2" />

            {isProject && (
              <SidebarGroup className="flex-1 overflow-hidden">
                <SidebarGroupLabel className="text-xs font-medium text-muted-foreground px-2">
                  Your use cases
                </SidebarGroupLabel>
                <SidebarGroupContent className="overflow-y-auto">
                  <SidebarMenu>
                    {useCases.length === 0 ? (
                      <div className="px-2 py-4 text-center text-sm text-muted-foreground">
                        No use cases yet
                      </div>
                    ) : (
                      useCases.map((useCase) => {
                        const isActive = location === `/use-case/${useCase.id}`;
                        return (
                          <SidebarMenuItem key={useCase.id}>
                            <ContextMenu>
                              <ContextMenuTrigger>
                                <SidebarMenuButton
                                  asChild
                                  isActive={isActive}
                                  className="h-auto py-2 px-2"
                                  data-testid={`nav-usecase-${useCase.id}`}
                                >
                                  <Link href={`/use-case/${useCase.id}`}>
                                    <div className="flex items-start gap-2 w-full min-w-0">
                                      <MessageSquare className="h-4 w-4 mt-0.5 flex-shrink-0 text-muted-foreground" />
                                      <div className="flex-1 min-w-0 space-y-1">
                                        <div className="flex items-center justify-between gap-2">
                                          <span className="text-sm font-medium truncate flex-1">
                                            {useCase.title || "Untitled Use Case"}
                                          </span>
                                        </div>
                                        <div className="flex items-center justify-between gap-2">
                                          <span className="text-xs text-muted-foreground">
                                            {formatTimeAgo(useCase.updatedAt)}
                                          </span>
                                          {getStatusBadge(useCase.threadStatus)}
                                        </div>
                                      </div>
                                    </div>
                                  </Link>
                                </SidebarMenuButton>
                              </ContextMenuTrigger>
                              <ContextMenuContent>
                                <ContextMenuItem
                                  className="text-destructive focus:text-destructive cursor-pointer"
                                  onClick={() => {
                                    if (confirm("Are you sure you want to delete this use case? This action cannot be undone.")) {
                                      deleteUseCaseMutation.mutate(useCase.id);
                                    }
                                  }}
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </ContextMenuItem>
                              </ContextMenuContent>
                            </ContextMenu>
                          </SidebarMenuItem>
                        );
                      })
                    )}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            )}
          </>
        )}
      </SidebarContent>

      <SidebarFooter className="p-3">
        <SidebarSeparator className="mb-3" />
        <div className="flex items-center gap-3 rounded-lg bg-sidebar-accent/50 p-3">
          <Avatar className="h-9 w-9 ring-2 ring-sidebar-border">
            <AvatarImage src={user?.profileImageUrl || undefined} alt={getDisplayName()} />
            <AvatarFallback className="bg-primary text-primary-foreground text-sm font-medium">
              {getInitials()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate" data-testid="text-user-name">
              {getDisplayName()}
            </p>
            <p className="text-xs text-muted-foreground truncate" data-testid="text-user-role">
              {isAdmin ? "Admin" : isCouncil ? "Council Member" : "Project Team"}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLogout}
            disabled={isLoggingOut}
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            data-testid="button-logout"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}

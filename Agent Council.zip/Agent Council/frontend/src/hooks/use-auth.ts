import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

async function fetchUser(): Promise<User | null> {
  const response = await fetch("/api/auth/user", {
    credentials: "include",
  });

  if (response.status === 401) {
    return null;
  }

  if (!response.ok) {
    throw new Error(`${response.status}: ${response.statusText}`);
  }

  return response.json();
}

async function logout(): Promise<void> {
  window.location.href = "/api/logout";
}

async function devLogout(): Promise<void> {
  await fetch("/api/dev/logout", {
    method: "POST",
    credentials: "include",
  });
}

interface DevLoginCredentials {
  username: string;
  password: string;
}

async function devLogin(credentials: DevLoginCredentials): Promise<{ success: boolean; user: User }> {
  const response = await fetch("/api/dev/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(credentials),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || "Login failed");
  }

  return response.json();
}

export function useAuth() {
  const queryClient = useQueryClient();
  const { data: user, isLoading } = useQuery<User | null>({
    queryKey: ["/api/auth/user"],
    queryFn: fetchUser,
    retry: false,
    staleTime: 1000 * 60 * 5,
  });

  const logoutMutation = useMutation({
    mutationFn: logout,
    onSuccess: () => {
      queryClient.setQueryData(["/api/auth/user"], null);
    },
  });

  const devLogoutMutation = useMutation({
    mutationFn: devLogout,
    onSuccess: () => {
      queryClient.setQueryData(["/api/auth/user"], null);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
  });

  const devLoginMutation = useMutation({
    mutationFn: devLogin,
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/auth/user"], data.user);
    },
  });

  const isCouncil = user?.role === "COUNCIL";
  const isProject = user?.role === "PROJECT" || (user && !user.role);
  const isAdmin = user?.role === "ADMIN";

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    role: user?.role || "PROJECT",
    isCouncil,
    isProject,
    isAdmin,
    logout: logoutMutation.mutate,
    isLoggingOut: logoutMutation.isPending,
    devLogin: devLoginMutation.mutateAsync,
    devLogout: devLogoutMutation.mutate,
    isDevLoggingIn: devLoginMutation.isPending,
    devLoginError: devLoginMutation.error,
  };
}

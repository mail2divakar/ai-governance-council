import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { UserPlus, Mail, Shield, Loader2, Copy, CheckCircle2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";

interface User {
    id: string;
    email: string;
    firstName?: string;
    lastName?: string;
    role: string;
    username?: string;
    hasPassword: boolean;
    inviteToken?: string;
    inviteExpiresAt?: string;
    createdAt: string;
}

export function AdminUsersPage() {
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [email, setEmail] = useState("");
    const [role, setRole] = useState("PROJECT");
    const [lastInviteLink, setLastInviteLink] = useState<string | null>(null);

    const { data: users = [], isLoading } = useQuery<User[]>({
        queryKey: ["/api/admin/users"],
    });

    const inviteMutation = useMutation({
        mutationFn: async (data: { email: string; role: string }) => {
            const res = await apiRequest("POST", "/api/admin/users/invite", data);
            return res.json();
        },
        onSuccess: (data) => {
            queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
            setEmail("");
            // Construct the full link including the current origin
            const fullLink = `${window.location.origin}${data.inviteLink}`;
            setLastInviteLink(fullLink);
            toast({
                title: "Invite Created",
                description: `Invitation link generated for ${data.email}`,
            });
        },
        onError: (error: Error) => {
            toast({
                title: "Invite failed",
                description: error.message,
                variant: "destructive",
            });
        },
    });

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        toast({
            title: "Copied",
            description: "Invitation link copied to clipboard.",
        });
    };

    return (
        <div className="flex-1 space-y-4 p-8 pt-6 overflow-y-auto">
            <div className="flex items-center justify-between space-y-2">
                <div>
                    <h2 className="text-3xl font-bold tracking-tight">User Management</h2>
                    <p className="text-muted-foreground">
                        Onboard Project team members and Council reviewers by sending them an invitation link.
                    </p>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                <Card className="h-fit">
                    <CardHeader>
                        <CardTitle>Invite New User</CardTitle>
                        <CardDescription>Enter the email address and assign a role to generate an onboarding link.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="email">Email Address</Label>
                            <Input 
                                id="email" 
                                type="email" 
                                placeholder="user@example.com" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label>User Role</Label>
                            <Select value={role} onValueChange={setRole}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select a role" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="PROJECT">Project Team (Intake Access)</SelectItem>
                                    <SelectItem value="COUNCIL">Council Member (Review Access)</SelectItem>
                                    <SelectItem value="ADMIN">Administrator (Full Access)</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <Button
                            className="w-full"
                            disabled={!email || inviteMutation.isPending}
                            onClick={() => inviteMutation.mutate({ email, role })}
                        >
                            {inviteMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
                            Generate Invitation Link
                        </Button>

                        {lastInviteLink && (
                            <div className="mt-6 p-4 bg-muted rounded-lg border border-border animate-in fade-in slide-in-from-top-2">
                                <Label className="text-xs uppercase text-muted-foreground font-semibold mb-2 block">Generated Invitation Link</Label>
                                <div className="flex gap-2">
                                    <Input readOnly value={lastInviteLink} className="bg-background" />
                                    <Button size="icon" variant="outline" onClick={() => copyToClipboard(lastInviteLink)}>
                                        <Copy className="h-4 w-4" />
                                    </Button>
                                </div>
                                <p className="text-[10px] text-muted-foreground mt-2">
                                    Send this link to the user. They will be able to set their username and password.
                                </p>
                            </div>
                        )}
                    </CardContent>
                </Card>

                <Card className="flex flex-col h-full">
                    <CardHeader>
                        <CardTitle>Organization Users</CardTitle>
                        <CardDescription>List of all users and their registration status.</CardDescription>
                    </CardHeader>
                    <CardContent className="flex-1 overflow-auto">
                        {isLoading ? (
                            <div className="flex justify-center p-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
                        ) : users.length === 0 ? (
                            <div className="text-center p-8 text-muted-foreground">No users found.</div>
                        ) : (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Email</TableHead>
                                        <TableHead>Role</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead className="text-right">Joined</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {users.map((user) => (
                                        <TableRow key={user.id}>
                                            <TableCell className="max-w-[150px] truncate" title={user.email}>
                                                <div className="flex flex-col">
                                                    <span className="font-medium truncate">{user.email}</span>
                                                    {user.username && <span className="text-[10px] text-muted-foreground">@{user.username}</span>}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold gap-1 ${
                                                    user.role === 'ADMIN' ? 'bg-purple-100 text-purple-700' : 
                                                    user.role === 'COUNCIL' ? 'bg-blue-100 text-blue-700' : 
                                                    'bg-gray-100 text-gray-700'
                                                }`}>
                                                    <Shield className="h-3 w-3" /> {user.role}
                                                </span>
                                            </TableCell>
                                            <TableCell>
                                                {user.hasPassword ? (
                                                    <span className="flex items-center gap-1 text-green-600 text-xs">
                                                        <CheckCircle2 className="h-3 w-3" /> Active
                                                    </span>
                                                ) : (
                                                    <span className="flex items-center gap-1 text-amber-600 text-xs">
                                                        <Mail className="h-3 w-3" /> Pending
                                                    </span>
                                                )}
                                            </TableCell>
                                            <TableCell className="text-right text-muted-foreground text-xs">
                                                {user.createdAt ? format(new Date(user.createdAt), "MMM d") : ""}
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { UploadCloud, Trash2, FileText, Loader2, BookOpen } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import type { AdminDocumentOut } from "@shared/schema";

export function AdminDocumentsPage() {
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [isDragging, setIsDragging] = useState(false);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [category, setCategory] = useState<string>("BRD");
    const fileInputRef = useRef<HTMLInputElement>(null);

    const { data: documents = [], isLoading } = useQuery<AdminDocumentOut[]>({
        queryKey: ["/api/admin/documents"],
    });

    const uploadMutation = useMutation({
        mutationFn: async (data: { file: File; category: string }) => {
            const formData = new FormData();
            formData.append("file", data.file);
            formData.append("category", data.category);

            const res = await fetch("/api/admin/documents", {
                method: "POST",
                body: formData,
            });

            if (!res.ok) {
                const err = await res.json();
                throw new Error(err.detail || "Failed to upload document");
            }
            return res.json();
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["/api/admin/documents"] });
            setSelectedFile(null);
            if (fileInputRef.current) fileInputRef.current.value = "";
            toast({
                title: "Success",
                description: "Document uploaded and embedded successfully.",
            });
        },
        onError: (error: Error) => {
            toast({
                title: "Upload failed",
                description: error.message,
                variant: "destructive",
            });
        },
    });

    const deleteMutation = useMutation({
        mutationFn: async (id: string) => {
            await apiRequest("DELETE", `/api/admin/documents/${id}`);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["/api/admin/documents"] });
            toast({
                title: "Deleted",
                description: "Document and its vector embeddings removed.",
            });
        },
        onError: () => {
            toast({
                title: "Delete failed",
                description: "Could not remove the document.",
                variant: "destructive",
            });
        },
    });

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            const file = e.dataTransfer.files[0];
            if (file.type !== "application/pdf") {
                toast({ title: "Invalid file", description: "Please upload PDF files only.", variant: "destructive" });
                return;
            }
            setSelectedFile(file);
        }
    };

    return (
        <div className="flex-1 space-y-4 p-8 pt-6 overflow-y-auto">
            <div className="flex items-center justify-between space-y-2">
                <div>
                    <h2 className="text-3xl font-bold tracking-tight">Knowledge Base</h2>
                    <p className="text-muted-foreground">
                        Manage Organizational Data and BRD files. Uploaded PDFs are automatically indexed into the Vector DB.
                    </p>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle>Upload Document</CardTitle>
                        <CardDescription>Drag and drop a PDF file here to add it to the vector store.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label>Category</Label>
                            <Select value={category} onValueChange={setCategory}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select a category" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="BRD">BRD / Requirements</SelectItem>
                                    <SelectItem value="ORG_DATA">Organizational Data / Policies</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div
                            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${isDragging ? "border-primary bg-primary/10" : "border-border hover:bg-accent/50"
                                }`}
                            onDragOver={handleDragOver}
                            onDragLeave={handleDragLeave}
                            onDrop={handleDrop}
                        >
                            <Input
                                type="file"
                                ref={fileInputRef}
                                className="hidden"
                                accept=".pdf"
                                onChange={(e) => {
                                    if (e.target.files && e.target.files[0]) {
                                        setSelectedFile(e.target.files[0]);
                                    }
                                }}
                            />
                            <div className="flex flex-col items-center gap-2 cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                                <UploadCloud className="h-10 w-10 text-muted-foreground" />
                                {selectedFile ? (
                                    <p className="text-sm font-medium">{selectedFile.name}</p>
                                ) : (
                                    <div className="space-y-1">
                                        <p className="text-sm font-medium">Click to browse or drag PDF here</p>
                                        <p className="text-xs text-muted-foreground">Only .pdf files are supported</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        <Button
                            className="w-full"
                            disabled={!selectedFile || uploadMutation.isPending}
                            onClick={() => {
                                if (selectedFile) {
                                    uploadMutation.mutate({ file: selectedFile, category });
                                }
                            }}
                        >
                            {uploadMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Upload and Index
                        </Button>
                    </CardContent>
                </Card>

                <Card className="flex flex-col h-full">
                    <CardHeader>
                        <CardTitle>Indexed Documents</CardTitle>
                        <CardDescription>Files currently available to the AI agent.</CardDescription>
                    </CardHeader>
                    <CardContent className="flex-1 overflow-auto">
                        {isLoading ? (
                            <div className="flex justify-center p-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
                        ) : documents.length === 0 ? (
                            <div className="text-center p-8 text-muted-foreground">No documents uploaded yet.</div>
                        ) : (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Filename</TableHead>
                                        <TableHead>Category</TableHead>
                                        <TableHead>Uploaded</TableHead>
                                        <TableHead className="w-[50px]"></TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {documents.map((doc) => (
                                        <TableRow key={doc.id}>
                                            <TableCell className="font-medium flex items-center gap-2 max-w-[200px] truncate" title={doc.filename}>
                                                <FileText className="h-4 w-4 text-blue-500 shrink-0" />
                                                <span className="truncate">{doc.filename}</span>
                                            </TableCell>
                                            <TableCell>
                                                <span className="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold bg-secondary text-secondary-foreground gap-1">
                                                    {doc.category === 'BRD' ? <BookOpen className="h-3 w-3" /> : ''} {doc.category}
                                                </span>
                                            </TableCell>
                                            <TableCell className="text-muted-foreground text-xs whitespace-nowrap">
                                                {doc.uploadedAt ? format(new Date(doc.uploadedAt), "MMM d, yyyy") : ""}
                                            </TableCell>
                                            <TableCell>
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                                                    onClick={() => {
                                                        if (confirm("Permanently delete this document and its embeddings from the vector database?")) {
                                                            deleteMutation.mutate(doc.id);
                                                        }
                                                    }}
                                                    disabled={deleteMutation.isPending}
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { ShieldCheck, User, Lock, Loader2, AlertCircle, ArrowRight } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useAuth } from "@/hooks/use-auth";

export function InvitePage() {
    const [, params] = useRoute("/invite/:token");
    const token = params?.token;
    const [, setLocation] = useLocation();
    const { toast } = useToast();
    const { user: authUser } = useAuth();
    
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [invitationData, setInvitationData] = useState<{ email: string; role: string } | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isValidating, setIsValidating] = useState(true);

    useEffect(() => {
        // If user is already logged in, redirect them
        if (authUser) {
            setLocation("/");
            return;
        }

        async function verifyToken() {
            if (!token) {
                setError("No invitation token provided.");
                setIsValidating(false);
                return;
            }

            try {
                const res = await fetch(`/api/auth/verify-invite/${token}`);
                if (!res.ok) {
                    const data = await res.json();
                    throw new Error(data.detail || "Invalid or expired invitation link.");
                }
                const data = await res.json();
                setInvitationData(data);
            } catch (err: any) {
                setError(err.message);
            } finally {
                setIsValidating(false);
            }
        }

        verifyToken();
    }, [token, authUser, setLocation]);

    const registerMutation = useMutation({
        mutationFn: async (data: any) => {
            const res = await apiRequest("POST", "/api/auth/complete-registration", data);
            return res.json();
        },
        onSuccess: () => {
            toast({
                title: "Welcome onboard!",
                description: "Your account has been created successfully.",
            });
            // Redirect to home - the backend already set the session cookie
            window.location.href = "/";
        },
        onError: (error: Error) => {
            toast({
                title: "Registration failed",
                description: error.message,
                variant: "destructive",
            });
        },
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        if (password !== confirmPassword) {
            toast({
                title: "Passwords do not match",
                description: "Please make sure both passwords are the same.",
                variant: "destructive",
            });
            return;
        }

        if (password.length < 8) {
            toast({
                title: "Weak password",
                description: "Password must be at least 8 characters long.",
                variant: "destructive",
            });
            return;
        }

        registerMutation.mutate({
            token,
            username,
            password
        });
    };

    if (isValidating) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-accent/5">
                <div className="flex flex-col items-center gap-4">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <p className="text-muted-foreground animate-pulse">Verifying your invitation...</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="min-h-screen flex items-center justify-center p-4 bg-accent/5">
                <Alert variant="destructive" className="max-w-md">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Invalid Invitation</AlertTitle>
                    <AlertDescription>
                        {error} Please contact your administrator for a new link.
                    </AlertDescription>
                    <Button variant="outline" className="mt-4 w-full" onClick={() => setLocation("/")}>
                        Go to Home
                    </Button>
                </Alert>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-accent/5">
            <div className="w-full max-w-md space-y-6">
                <div className="text-center space-y-2">
                    <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                        <ShieldCheck className="h-6 w-6 text-primary" />
                    </div>
                    <h1 className="text-2xl font-bold tracking-tight">Complete Registration</h1>
                    <p className="text-muted-foreground underline">
                        {invitationData?.email}
                    </p>
                    <div className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold bg-primary/10 text-primary mt-2">
                        Role: {invitationData?.role}
                    </div>
                </div>

                <Card>
                    <form onSubmit={handleSubmit}>
                        <CardHeader>
                            <CardTitle>Create Your Account</CardTitle>
                            <CardDescription>Choose a username and a strong password to get started.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="username">Username</Label>
                                <div className="relative">
                                    <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                    <Input 
                                        id="username" 
                                        placeholder="jdoe" 
                                        className="pl-10"
                                        required
                                        value={username}
                                        onChange={(e) => setUsername(e.target.value)}
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="password">Password</Label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                    <Input 
                                        id="password" 
                                        type="password" 
                                        className="pl-10"
                                        required
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="confirmPassword">Confirm Password</Label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                    <Input 
                                        id="confirmPassword" 
                                        type="password" 
                                        className="pl-10"
                                        required
                                        value={confirmPassword}
                                        onChange={(e) => setConfirmPassword(e.target.value)}
                                    />
                                </div>
                            </div>
                        </CardContent>
                        <CardFooter>
                            <Button className="w-full" type="submit" disabled={registerMutation.isPending}>
                                {registerMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
                                Finish Registration
                            </Button>
                        </CardFooter>
                    </form>
                </Card>
            </div>
        </div>
    );
}

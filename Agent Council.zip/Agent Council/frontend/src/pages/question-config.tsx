import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
    Plus, Edit2, Trash2, Save, X, Info, ChevronDown, ChevronUp,
    Shield, TrendingUp, Zap, Wrench, FileText
} from "lucide-react";

interface QuestionConfig {
    id: string;
    section: string;
    label: string;
    type: string;
    extractionPrompt: string | null;
    weight: number | null;
    isActive: number;
    weightPercent: number | null;
}

const SECTION_META: Record<string, { label: string; color: string; icon: any; bg: string }> = {
    BASIC: { label: "Basic Info", color: "text-blue-600", icon: FileText, bg: "bg-blue-50 dark:bg-blue-950/30" },
    RISK: { label: "Risk", color: "text-red-600", icon: Shield, bg: "bg-red-50 dark:bg-red-950/30" },
    BENEFIT: { label: "Benefit", color: "text-green-600", icon: TrendingUp, bg: "bg-green-50 dark:bg-green-950/30" },
    MITIGATION: { label: "Mitigation", color: "text-amber-600", icon: Wrench, bg: "bg-amber-50 dark:bg-amber-950/30" },
    TECHNICAL: { label: "Technical", color: "text-purple-600", icon: Zap, bg: "bg-purple-50 dark:bg-purple-950/30" },
};

const TYPES = ["text", "scale_1_5", "scale_1_3", "boolean", "select"];

function SectionBadge({ section }: { section: string }) {
    const meta = SECTION_META[section] || { label: section, color: "text-gray-600", bg: "" };
    return (
        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${meta.color} ${meta.bg}`}>
            {meta.label}
        </span>
    );
}

function QuestionRow({ config, onEdit, onDelete, totalRiskWeight }: {
    config: QuestionConfig;
    onEdit: (c: QuestionConfig) => void;
    onDelete: (id: string) => void;
    totalRiskWeight: number;
}) {
    const [expanded, setExpanded] = useState(false);
    const pct = config.section === "RISK" && totalRiskWeight
        ? ((config.weight || 0) / totalRiskWeight * 100).toFixed(1)
        : null;

    return (
        <div className={`rounded-lg border mb-2 transition-all ${!config.isActive ? "opacity-50" : ""}`}>
            <div
                className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-muted/40 rounded-lg"
                onClick={() => setExpanded(e => !e)}
            >
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                        <SectionBadge section={config.section} />
                        <span className="font-medium text-sm">{config.label}</span>
                        {!config.isActive && <Badge variant="outline" className="text-xs">Inactive</Badge>}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1 font-mono">{config.id}</div>
                </div>

                <div className="flex items-center gap-4 flex-shrink-0">
                    {pct && (
                        <div className="text-right hidden sm:block">
                            <div className="text-xs text-muted-foreground">Risk Weight</div>
                            <div className="text-sm font-bold text-red-600">{pct}%</div>
                        </div>
                    )}
                    {config.section === "RISK" && (
                        <div className="text-right hidden sm:block">
                            <div className="text-xs text-muted-foreground">Weight</div>
                            <div className="text-sm font-semibold">{config.weight ?? 0}</div>
                        </div>
                    )}
                    <div className="flex items-center gap-1">
                        <Button
                            size="icon" variant="ghost" className="h-8 w-8"
                            onClick={e => { e.stopPropagation(); onEdit(config); }}
                        >
                            <Edit2 className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                            size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={e => { e.stopPropagation(); onDelete(config.id); }}
                        >
                            <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                        {expanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                    </div>
                </div>
            </div>

            {expanded && (
                <div className="px-4 pb-4 space-y-3 border-t pt-3">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <span className="text-muted-foreground text-xs uppercase font-medium">Field ID</span>
                            <p className="font-mono text-xs mt-0.5 bg-muted px-2 py-1 rounded">{config.id}</p>
                        </div>
                        <div>
                            <span className="text-muted-foreground text-xs uppercase font-medium">Input Type</span>
                            <p className="mt-0.5">{config.type}</p>
                        </div>
                    </div>
                    <div>
                        <span className="text-muted-foreground text-xs uppercase font-medium flex items-center gap-1">
                            <Info className="h-3 w-3" /> LLM Extraction Prompt
                        </span>
                        <p className="text-sm mt-1 leading-relaxed text-foreground/80 bg-muted/50 p-3 rounded-md border">
                            {config.extractionPrompt || <span className="italic text-muted-foreground">No prompt set — field will not be auto-extracted</span>}
                        </p>
                    </div>
                    {config.section === "RISK" && (
                        <div className="flex items-center gap-6">
                            <div>
                                <span className="text-muted-foreground text-xs uppercase font-medium">Scoring Weight</span>
                                <p className="text-lg font-bold text-red-600 mt-0.5">{config.weight ?? 0}</p>
                            </div>
                            {pct && (
                                <div>
                                    <span className="text-muted-foreground text-xs uppercase font-medium">% of Total Risk Score</span>
                                    <p className="text-lg font-bold mt-0.5">{pct}%</p>
                                </div>
                            )}
                            <div className="flex-1">
                                <span className="text-muted-foreground text-xs uppercase font-medium">Score Impact</span>
                                <div className="mt-1 h-2 bg-muted rounded-full overflow-hidden">
                                    <div
                                        className="h-full bg-red-500 rounded-full transition-all"
                                        style={{ width: `${pct}%` }}
                                    />
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

const EMPTY_FORM = {
    id: "", section: "BASIC", label: "", type: "text",
    extractionPrompt: "", weight: 0, isActive: 1,
};

export function QuestionConfigPage() {
    const { toast } = useToast();
    const qc = useQueryClient();
    const [editing, setEditing] = useState<QuestionConfig | null>(null);
    const [adding, setAdding] = useState(false);
    const [form, setForm] = useState<any>(EMPTY_FORM);
    const [filterSection, setFilterSection] = useState("ALL");

    const { data: configs = [], isLoading } = useQuery<QuestionConfig[]>({
        queryKey: ["/api/admin/questions"],
    });

    const saveMutation = useMutation({
        mutationFn: async (data: any) => {
            if (editing) {
                const res = await apiRequest("PATCH", `/api/admin/questions/${editing.id}`, data);
                return res.json();
            } else {
                const res = await apiRequest("POST", "/api/admin/questions", data);
                return res.json();
            }
        },
        onSuccess: () => {
            qc.invalidateQueries({ queryKey: ["/api/admin/questions"] });
            toast({ title: editing ? "Updated" : "Created", description: "Question config saved." });
            setEditing(null); setAdding(false); setForm(EMPTY_FORM);
        },
        onError: (err: any) => {
            toast({ title: "Error", description: err.message || "Failed to save", variant: "destructive" });
        },
    });

    const deleteMutation = useMutation({
        mutationFn: async (id: string) => {
            const res = await apiRequest("DELETE", `/api/admin/questions/${id}`);
            return res.json();
        },
        onSuccess: () => {
            qc.invalidateQueries({ queryKey: ["/api/admin/questions"] });
            toast({ title: "Deleted", description: "Question removed." });
        },
        onError: () => toast({ title: "Error", description: "Failed to delete", variant: "destructive" }),
    });

    const startEdit = (c: QuestionConfig) => {
        setEditing(c);
        setAdding(false);
        setForm({ ...c });
    };

    const startAdd = () => {
        setEditing(null);
        setAdding(true);
        setForm(EMPTY_FORM);
    };

    const cancelForm = () => { setEditing(null); setAdding(false); setForm(EMPTY_FORM); };

    const totalRiskWeight = configs.filter(c => c.section === "RISK").reduce((s, c) => s + (c.weight || 0), 0);

    const sections = ["ALL", ...Array.from(new Set(configs.map(c => c.section)))];
    const filtered = filterSection === "ALL" ? configs : configs.filter(c => c.section === filterSection);

    const grouped = sections.filter(s => s !== "ALL").reduce((acc, sec) => {
        const items = filtered.filter(c => c.section === sec);
        if (items.length) acc[sec] = items;
        return acc;
    }, {} as Record<string, QuestionConfig[]>);

    return (
        <div className="flex h-full bg-background">
            <ScrollArea className="flex-1">
                <div className="max-w-4xl mx-auto px-6 py-6 space-y-6">

                    {/* Header */}
                    <div className="flex items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-bold">Question Configuration</h1>
                            <p className="text-muted-foreground text-sm mt-1">
                                Manage intake questions, LLM extraction prompts, and risk scoring weights.
                                Changes here instantly affect how the AI populates and scores use cases.
                            </p>
                        </div>
                        <Button onClick={startAdd} className="gap-2">
                            <Plus className="h-4 w-4" /> Add Question
                        </Button>
                    </div>

                    {/* Stats row */}
                    <div className="grid grid-cols-3 gap-4">
                        <Card>
                            <CardContent className="pt-4 pb-3">
                                <div className="text-xs text-muted-foreground uppercase font-medium">Total Questions</div>
                                <div className="text-2xl font-bold mt-1">{configs.length}</div>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardContent className="pt-4 pb-3">
                                <div className="text-xs text-muted-foreground uppercase font-medium">Total Risk Weight</div>
                                <div className="text-2xl font-bold text-red-600 mt-1">{totalRiskWeight}</div>
                                <div className="text-xs text-muted-foreground">Score = weighted avg × 20 → 0–100</div>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardContent className="pt-4 pb-3">
                                <div className="text-xs text-muted-foreground uppercase font-medium">Active Questions</div>
                                <div className="text-2xl font-bold mt-1">{configs.filter(c => c.isActive).length}</div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Add / Edit Form */}
                    {(adding || editing) && (
                        <Card className="border-primary/40 shadow-md">
                            <CardHeader className="pb-3">
                                <CardTitle className="text-base">{editing ? `Edit: ${editing.label}` : "Add New Question"}</CardTitle>
                                <CardDescription>
                                    The <strong>Extraction Prompt</strong> is sent to GPT-4o to extract this field's value from the user's description.
                                    The <strong>Weight</strong> determines how much this question affects the overall risk score (RISK section only).
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1.5">
                                        <Label className="text-xs">Field ID <span className="text-muted-foreground">(camelCase, unique)</span></Label>
                                        <Input
                                            value={form.id}
                                            onChange={e => setForm((p: any) => ({ ...p, id: e.target.value }))}
                                            placeholder="e.g. complianceRiskLikelihood"
                                            disabled={!!editing}
                                            className="font-mono text-sm"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <Label className="text-xs">Label <span className="text-muted-foreground">(shown in UI)</span></Label>
                                        <Input
                                            value={form.label}
                                            onChange={e => setForm((p: any) => ({ ...p, label: e.target.value }))}
                                            placeholder="e.g. Compliance Risk (Q10)"
                                        />
                                    </div>
                                </div>
                                <div className="grid grid-cols-3 gap-4">
                                    <div className="space-y-1.5">
                                        <Label className="text-xs">Section</Label>
                                        <Select value={form.section} onValueChange={v => setForm((p: any) => ({ ...p, section: v }))}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {Object.keys(SECTION_META).map(s => (
                                                    <SelectItem key={s} value={s}>{SECTION_META[s].label}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-1.5">
                                        <Label className="text-xs">Input Type</Label>
                                        <Select value={form.type} onValueChange={v => setForm((p: any) => ({ ...p, type: v }))}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-1.5">
                                        <Label className="text-xs">Risk Weight <span className="text-muted-foreground">(0 if not RISK)</span></Label>
                                        <Input
                                            type="number" min={0} step={1}
                                            value={form.weight}
                                            onChange={e => setForm((p: any) => ({ ...p, weight: parseFloat(e.target.value) || 0 }))}
                                        />
                                    </div>
                                </div>
                                <div className="space-y-1.5">
                                    <Label className="text-xs">LLM Extraction Prompt</Label>
                                    <Textarea
                                        value={form.extractionPrompt || ""}
                                        onChange={e => setForm((p: any) => ({ ...p, extractionPrompt: e.target.value }))}
                                        placeholder="Describe what value to extract and how to score it. Example: '1-5 scale likelihood of safety risk. Extract from user description, infer based on use case context.'"
                                        className="min-h-[100px] text-sm font-mono"
                                    />
                                </div>
                                <div className="flex items-center gap-3">
                                    <Switch
                                        checked={form.isActive === 1}
                                        onCheckedChange={v => setForm((p: any) => ({ ...p, isActive: v ? 1 : 0 }))}
                                    />
                                    <Label className="text-sm">Active (included in intake and scoring)</Label>
                                </div>
                                <div className="flex gap-3 pt-2">
                                    <Button
                                        onClick={() => saveMutation.mutate(form)}
                                        disabled={saveMutation.isPending || !form.id || !form.label}
                                        className="gap-2"
                                    >
                                        <Save className="h-4 w-4" />
                                        {saveMutation.isPending ? "Saving..." : "Save Question"}
                                    </Button>
                                    <Button variant="outline" onClick={cancelForm} className="gap-2">
                                        <X className="h-4 w-4" /> Cancel
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Filter */}
                    <div className="flex items-center gap-2 flex-wrap">
                        {sections.map(sec => (
                            <Button
                                key={sec}
                                size="sm"
                                variant={filterSection === sec ? "default" : "outline"}
                                onClick={() => setFilterSection(sec)}
                                className="h-7 text-xs"
                            >
                                {sec === "ALL" ? "All" : SECTION_META[sec]?.label || sec}
                                <span className="ml-1.5 opacity-70">
                                    {sec === "ALL" ? configs.length : configs.filter(c => c.section === sec).length}
                                </span>
                            </Button>
                        ))}
                    </div>

                    {/* Question List by Section */}
                    {isLoading ? (
                        <div className="text-center text-muted-foreground py-12">Loading configurations...</div>
                    ) : (
                        Object.entries(grouped).map(([section, items]) => {
                            const meta = SECTION_META[section] || { label: section, color: "text-gray-600", icon: FileText, bg: "" };
                            const Icon = meta.icon;
                            return (
                                <div key={section}>
                                    <div className={`flex items-center gap-2 px-3 py-2 rounded-lg mb-3 ${meta.bg}`}>
                                        <Icon className={`h-4 w-4 ${meta.color}`} />
                                        <span className={`font-semibold text-sm ${meta.color}`}>{meta.label}</span>
                                        <span className="text-xs text-muted-foreground ml-auto">{items.length} question{items.length !== 1 ? "s" : ""}</span>
                                        {section === "RISK" && (
                                            <span className="text-xs text-muted-foreground">· Total weight: {totalRiskWeight}</span>
                                        )}
                                    </div>
                                    {items.map(c => (
                                        <QuestionRow
                                            key={c.id}
                                            config={c}
                                            onEdit={startEdit}
                                            onDelete={id => {
                                                if (confirm(`Delete "${id}"? This will stop it from being used in intake and scoring.`)) {
                                                    deleteMutation.mutate(id);
                                                }
                                            }}
                                            totalRiskWeight={totalRiskWeight}
                                        />
                                    ))}
                                    <Separator className="my-4" />
                                </div>
                            );
                        })
                    )}
                </div>
            </ScrollArea>
        </div>
    );
}

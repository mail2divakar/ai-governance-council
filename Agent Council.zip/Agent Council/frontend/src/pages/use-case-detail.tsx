import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { ChatMessage } from "@/components/chat-message";
import { ChatInput } from "@/components/chat-input";
import { IntakeFormPanel } from "@/components/intake-form-panel";
import { WorkflowStepper } from "@/components/workflow-stepper";
import { SimilarCasesPanel } from "@/components/similar-cases-panel";
import { DecisionPanel } from "@/components/decision-panel";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Loader2, MessageSquare, FileText, Save, Send, Users, Database, AlertTriangle, Info, Download } from "lucide-react";
import type { UseCase, Message, Assessment, Decision, DecisionStatus, Stage, RiskLevel } from "@shared/schema";

const welcomeMessage: Message = {
  id: "welcome",
  useCaseId: "",
  role: "agent",
  content: "Welcome back! Continue describing your AI use case and I'll help you complete the governance form. Ask me any questions about governance requirements.",
  metadata: null,
  createdAt: new Date(),
};

function getWorkflowPhase(status: string | null, stage: string | null): string {
  if (status === "SUBMITTED" && stage === "ASSESSMENT") {
    return "validate";
  }
  return "intake";
}

function getCompletedPhases(status: string | null, stage: string | null): string[] {
  const completed: string[] = [];
  if (status === "SUBMITTED") {
    completed.push("intake");
  }
  return completed;
}

export function UseCaseDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user, isCouncil, isAdmin } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [localMessages, setLocalMessages] = useState<Message[]>([]);
  const [isDownloading, setIsDownloading] = useState(false);

  // Single bundle fetch replaces 5 separate API calls
  const { data: bundle, isLoading: isLoadingBundle } = useQuery<{
    useCase: UseCase;
    messages: Message[];
    assessment: Assessment | null;
    decision: Decision | null;
    similar: any[];
  }>({
    queryKey: ["/api/use-cases", id, "detail-bundle"],
  });

  // Populate individual caches from bundle for downstream use
  useEffect(() => {
    if (bundle) {
      queryClient.setQueryData(["/api/use-cases", id], bundle.useCase);
      queryClient.setQueryData(["/api/use-cases", id, "messages"], bundle.messages);
      queryClient.setQueryData(["/api/use-cases", id, "assessment"], bundle.assessment);
      queryClient.setQueryData(["/api/use-cases", id, "decision"], bundle.decision);
      queryClient.setQueryData(["/api/use-cases", id, "similar"], bundle.similar);
    }
  }, [bundle, id, queryClient]);

  const useCase = bundle?.useCase;
  const messages = bundle?.messages ?? [];
  const assessment = bundle?.assessment ?? undefined;
  const decision = bundle?.decision ?? undefined;
  const isLoadingUseCase = isLoadingBundle;
  const similar = bundle?.similar ?? [];

  useEffect(() => {
    if (bundle && messages.length > 0) {
      setLocalMessages(messages);
    }
  }, [messages, bundle]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [localMessages]);

  const sendMessageMutation = useMutation({
    mutationFn: async ({ message, isFormUpdate = false }: { message: string; isFormUpdate?: boolean }) => {
      const response = await apiRequest("POST", `/api/use-cases/${id}/messages`, {
        content: message,
        isFormUpdate,
      });
      return response.json() as Promise<Message>;
    },
    onMutate: ({ message }) => {
      const tempUserMessage: Message = {
        id: `temp-user-${Date.now()}`,
        useCaseId: id || "",
        role: "user",
        content: message,
        metadata: null,
        createdAt: new Date(),
      };
      setLocalMessages(prev => [...prev, tempUserMessage]);
    },
    onSuccess: (agentMessage) => {
      setLocalMessages(prev => [...prev, agentMessage]);
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", id, "detail-bundle"] });
    },
    onError: () => {
      setLocalMessages(prev => prev.slice(0, -1));
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateFieldMutation = useMutation({
    mutationFn: async ({ field, value }: { field: string; value: string | number }) => {
      const response = await apiRequest("PATCH", `/api/use-cases/${id}`, {
        [field]: value,
      });
      return response.json() as Promise<UseCase>;
    },
    onSuccess: (updatedUseCase) => {
      // Optimistically update the detail-bundle cache
      queryClient.setQueryData(["/api/use-cases", id, "detail-bundle"], (old: any) => {
        if (!old) return old;
        return { ...old, useCase: updatedUseCase };
      });

      // Also update the general list if it exists in cache
      queryClient.setQueryData(["/api/use-cases"], (old: UseCase[] | undefined) => {
        if (!old) return old;
        return old.map(uc => uc.id === id ? updatedUseCase : uc);
      });
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PATCH", `/api/use-cases/${id}`, {
        status: "DRAFT",
      });
      return response.json() as Promise<UseCase>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", id, "detail-bundle"] });
      toast({
        title: "Saved",
        description: "Your use case has been saved as a draft.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save. Please try again.",
        variant: "destructive",
      });
    },
  });

  const submitMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PATCH", `/api/use-cases/${id}`, {
        status: "SUBMITTED",
        stage: "ASSESSMENT",
      });
      return response.json() as Promise<UseCase>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", id, "detail-bundle"] });
      toast({
        title: "Submitted",
        description: "Your use case has been submitted for validation.",
      });
      navigate("/use-cases");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit. Please try again.",
        variant: "destructive",
      });
    },
  });

  const decisionMutation = useMutation({
    mutationFn: async ({ status, rationale }: { status: DecisionStatus; rationale: string[] }) => {
      const response = await apiRequest("POST", `/api/council/use-cases/${id}/decision`, {
        status,
        rationale: rationale.join("; "),
      });
      return response.json() as Promise<Decision>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", id, "detail-bundle"] });
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases"] });
      toast({
        title: "Decision Recorded",
        description: "The governance decision has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to record decision. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFormFieldChange = (field: string, value: string | number, isSensitive: boolean, label?: string) => {
    if (!id) return;

    updateFieldMutation.mutate({ field, value });

    if (isSensitive) {
      const displayLabel = label || field;
      const message = `${displayLabel} changed to "${value}". Please provide risk recommendations.`;
      sendMessageMutation.mutate({ message, isFormUpdate: true });
    }
  };

  const handleSave = () => {
    if (id) {
      saveMutation.mutate();
    }
  };

  const handleSubmit = () => {
    if (id) {
      submitMutation.mutate();
    }
  };

  const handleDecision = (status: DecisionStatus) => {
    const rationaleMap: Record<DecisionStatus, string[]> = {
      APPROVE: ["Use case meets all governance requirements", "Risk assessment indicates acceptable risk level"],
      DISAPPROVE: ["Critical governance concerns identified", "Risk assessment indicates unacceptable risk level"],
      APPROVE_WITH_CONDITIONS: ["Use case approved subject to implementing recommended controls", "Periodic review required"],
      NEEDS_MORE_INFORMATION: ["Additional information required for complete assessment", "Please provide missing details"],
      PENDING: [],
    };
    decisionMutation.mutate({ status, rationale: rationaleMap[status] });
  };

  if (isLoadingUseCase) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-full max-w-md" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!useCase) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6">
        <p className="text-lg text-muted-foreground mb-4">Use case not found</p>
        <Button variant="outline" onClick={() => navigate("/new")}>
          Start New Use Case
        </Button>
      </div>
    );
  }

  const stage = (useCase.stage as Stage | null) || "BASIC_INFO";
  const riskScore = parseInt(useCase.riskScore || "0", 10);
  const riskLevel = (useCase.riskLevel as RiskLevel | null) || "LOW";
  const riskDrivers = useCase.riskDrivers || [];
  const isLoading = sendMessageMutation.isPending;
  const isSaving = saveMutation.isPending;
  const isSubmitting = submitMutation.isPending;
  const threadStatus = useCase.threadStatus || "info_required";
  const canApprove = threadStatus === "approval_required" && !decision;
  const isApprovedOrDisapproved = threadStatus === "approved" || threadStatus === "disapproved";
  const isSubmitted = useCase.status === "SUBMITTED";

  const currentPhase = getWorkflowPhase(useCase.status, useCase.stage);
  const completedPhases = getCompletedPhases(useCase.status, useCase.stage);

  return (
    <div className="flex flex-col h-full overflow-hidden">


      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 flex-shrink-0">
        <div className="px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/use-cases")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <FileText className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground">
                {useCase.title || "AI Governance Intake"}
              </h1>
              <p className="text-xs text-muted-foreground">
                Stage: {stage.replace("_", " ")} | Status: {useCase.status || "PENDING"}
              </p>
            </div>
          </div>
        </div>
      </div>
      <WorkflowStepper currentPhase={currentPhase} completedPhases={completedPhases} />
      <div className="flex-1 flex min-h-0 overflow-hidden">
        <div className="flex-1 flex flex-col border-r bg-muted/30 overflow-hidden">
          <div className="flex-1 overflow-hidden">
            <div className="h-full overflow-y-auto p-4 space-y-4">
              {id && (
                <SimilarCasesPanel similarCases={similar} />
              )}

              <IntakeFormPanel
                useCase={useCase}
                stage={stage}
                riskScore={riskScore}
                riskLevel={riskLevel}
                riskDrivers={riskDrivers}
                onFieldChange={handleFormFieldChange}
                readOnly={isAdmin}
              />

              {assessment && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-amber-500" />
                      Governance Assessment
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {assessment.risks && assessment.risks.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-1">Identified Risks</p>
                        <ul className="space-y-0.5">
                          {assessment.risks.map((risk: string, i: number) => (
                            <li key={i} className="text-xs text-foreground flex items-start gap-1">
                              <span className="text-red-500">-</span>
                              {risk}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {assessment.recommendations && assessment.recommendations.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-1">Recommendations</p>
                        <ul className="space-y-0.5">
                          {assessment.recommendations.map((rec: string, i: number) => (
                            <li key={i} className="text-xs text-foreground flex items-start gap-1">
                              <span className="text-green-500">-</span>
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {isCouncil && (canApprove || isApprovedOrDisapproved) && (
                <DecisionPanel
                  decision={decision}
                  onApprove={() => handleDecision("APPROVE")}
                  onDisapprove={() => handleDecision("DISAPPROVE")}
                  onApproveWithConditions={() => handleDecision("APPROVE_WITH_CONDITIONS")}
                  onRequestInfo={() => handleDecision("NEEDS_MORE_INFORMATION")}
                  isLoading={decisionMutation.isPending}
                  canDecide={canApprove}
                />
              )}
            </div>
          </div>

          {!isSubmitted && (
            <div className="border-t bg-background p-4 flex items-center justify-between flex-shrink-0">
              <Button
                variant="ghost"
                onClick={async () => {
                  if (!id) return;
                  try {
                    setIsDownloading(true);
                    const response = await fetch(`/api/use-cases/${id}/export`, {
                      credentials: "include"
                    });
                    
                    if (!response.ok) {
                      throw new Error("Failed to download file");
                    }
                    
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    
                    const contentDisposition = response.headers.get("Content-Disposition");
                    let filename = "use_case_export.xlsx";
                    if (contentDisposition && contentDisposition.includes("filename=")) {
                      filename = contentDisposition.split("filename=")[1].replace(/["']/g, "");
                    }
                    
                    a.download = filename;
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    document.body.removeChild(a);
                  } catch (error) {
                    console.error("Download error:", error);
                    toast({
                      title: "Download Failed",
                      description: "There was an error downloading the file. Please try again.",
                      variant: "destructive",
                    });
                  } finally {
                    setIsDownloading(false);
                  }
                }}
                disabled={isDownloading}
                className="gap-2"
                data-testid="button-download"
              >
                {isDownloading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Download className="h-4 w-4" />
                )}
                Download
              </Button>
              {!isAdmin && (
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    onClick={handleSave}
                    disabled={isSaving || isSubmitting}
                    className="gap-2"
                    data-testid="button-save"
                  >
                    {isSaving ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    Save
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={isSaving || isSubmitting}
                    className="gap-2"
                    data-testid="button-submit"
                  >
                    {isSubmitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                    Submit
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="w-[420px] flex flex-col overflow-hidden bg-background">
          <div className="border-b px-4 py-2 flex items-center gap-2 bg-muted/20">
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">Chat with AI Assistant</span>
          </div>

          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto min-h-0"
          >
            <div className="px-4 py-4 space-y-4">
              <ChatMessage
                message={welcomeMessage}
                userImage={user?.profileImageUrl}
                userName={user?.firstName || user?.email || "You"}
              />

              {isLoadingBundle ? (
                <div className="space-y-4">
                  {[1, 2].map((i) => (
                    <div key={i} className="flex gap-3">
                      <Skeleton className="h-8 w-8 rounded-full flex-shrink-0" />
                      <div className="space-y-2 flex-1">
                        <Skeleton className="h-3 w-24" />
                        <Skeleton className="h-16 w-full rounded-lg" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                localMessages.map((message) => (
                  <ChatMessage
                    key={message.id}
                    message={message}
                    userImage={user?.profileImageUrl}
                    userName={user?.firstName || user?.email || "You"}
                  />
                ))
              )}

              {isLoading && (
                <div className="flex gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary flex-shrink-0">
                    <Loader2 className="h-4 w-4 text-primary-foreground animate-spin" />
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <span>Thinking...</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="border-t p-3">
            <ChatInput
              onSend={(msg) => sendMessageMutation.mutate({ message: msg })}
              isLoading={isLoading}
              placeholder="Continue the conversation..."
            />
          </div>
        </div>
      </div>
    </div>
  );
}


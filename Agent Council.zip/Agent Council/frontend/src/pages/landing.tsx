import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/theme-toggle";
import { Shield, Brain, ClipboardCheck, BarChart3, Lock, CheckCircle2 } from "lucide-react";

const features = [
  {
    icon: Brain,
    title: "Intelligent Intake",
    description: "Conversational AI that structures even the vaguest use case descriptions into actionable governance profiles.",
  },
  {
    icon: ClipboardCheck,
    title: "Governance Assessment",
    description: "Comprehensive risk analysis across model risk, data governance, privacy, security, and compliance domains.",
  },
  {
    icon: BarChart3,
    title: "Decision Tracking",
    description: "Complete audit trail of approvals, conditions, and governance decisions for every AI initiative.",
  },
];

export function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <Shield className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold">AI Governance Co-Pilot</span>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <Button asChild data-testid="button-login">
              <a href="/api/login">Sign In</a>
            </Button>
          </div>
        </div>
      </header>

      <main className="pt-16">
        <section className="py-20 lg:py-32">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              <div className="space-y-8">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                    <Lock className="h-3.5 w-3.5" />
                    Enterprise AI Governance
                  </div>
                  <h1 className="text-4xl lg:text-5xl font-bold tracking-tight text-foreground">
                    Govern AI with
                    <span className="text-primary"> Confidence</span>
                  </h1>
                  <p className="text-lg text-muted-foreground max-w-lg">
                    Your virtual AI & Data Governance Council Officer. Intake, analyze, track, and govern AI use cases across their entire lifecycle.
                  </p>
                </div>

                <div className="flex flex-wrap gap-4">
                  <Button size="lg" asChild className="h-12 px-6" data-testid="button-get-started">
                    <a href="/api/login">Get Started</a>
                  </Button>
                  <Button size="lg" variant="outline" className="h-12 px-6">
                    Learn More
                  </Button>
                </div>

                <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                    Free to start
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                    No credit card required
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                    Enterprise-ready
                  </div>
                </div>
              </div>

              <div className="relative">
                <div className="relative bg-gradient-to-br from-primary/20 via-primary/5 to-transparent rounded-2xl p-8 lg:p-10 border border-primary/10">
                  <div className="absolute inset-0 bg-grid-pattern opacity-5 rounded-2xl" />
                  <div className="relative space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary flex-shrink-0">
                        <Shield className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">AI Governance Co-Pilot Agent</p>
                        <div className="bg-card rounded-xl p-4 border border-card-border">
                          <p className="text-sm text-card-foreground">
                            Welcome! I'm your AI Governance Council Officer. Tell me about the AI use case you'd like to intake, and I'll help structure it for governance review.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <div className="bg-primary rounded-xl p-4 max-w-xs">
                        <p className="text-sm text-primary-foreground">
                          We're building a customer support chatbot using GPT-4...
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary flex-shrink-0">
                        <Shield className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">AI Governance Co-Pilot Agent</p>
                        <div className="bg-card rounded-xl p-4 border border-card-border">
                          <p className="text-sm text-card-foreground">
                            Great! Let me help structure this. Who will be using this chatbot - internal employees or external customers?
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted/30">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
                Complete AI Governance Lifecycle
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                From initial intake to ongoing monitoring, manage every aspect of your AI governance program.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {features.map((feature) => (
                <Card key={feature.title} className="hover-elevate transition-all duration-200">
                  <CardContent className="p-6">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-4">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-card-foreground mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-3xl mx-auto px-6 text-center">
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
              Ready to govern your AI responsibly?
            </h2>
            <p className="text-muted-foreground mb-8">
              Join organizations using AI Governance Co-Pilot to manage AI governance with clarity and confidence.
            </p>
            <Button size="lg" asChild className="h-12 px-8">
              <a href="/api/login">Start Governing Today</a>
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium">AI Governance Co-Pilot</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} KSG AI Governance Council. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

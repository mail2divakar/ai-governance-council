import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { UseCase } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Edit, ExternalLink, ShieldAlert, CheckCircle, Clock } from "lucide-react";
import { StatusBadge } from "@/components/status-badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";

import { useAuth } from "@/hooks/use-auth";

export function UseCaseOverviewPage() {
    const { isAdmin } = useAuth();
    const [match, params] = useRoute("/use-case/:id/overview");
    const id = params?.id;

    const { data: useCase, isLoading } = useQuery<UseCase>({
        queryKey: [`/api/use-cases/${id}`],
        enabled: !!id,
    });

    const getNextActionInfo = (uc: UseCase) => {
        const status = uc.status || "PENDING";
        const threadStatus = uc.threadStatus || "info_required";

        if (status === "APPROVED") {
            return {
                status: "Approved",
                waitingOn: "Implementation Team",
                variant: "secondary" as const
            };
        }
        if (status === "REJECTED") {
            return {
                status: "Rejected",
                waitingOn: "None",
                variant: "destructive" as const
            };
        }
        if (status === "MORE_INFO_NEEDED") {
            return {
                status: "Clarification Needed",
                waitingOn: "Business Owner",
                variant: "secondary" as const
            };
        }

        if (threadStatus === "approval_required") {
            return {
                status: "Awaiting Review",
                waitingOn: "Risk Team & Council",
                variant: "secondary" as const
            };
        }

        return {
            status: "In Progress",
            waitingOn: "Project Team",
            variant: "secondary" as const
        };
    };

    if (isLoading || !useCase) {
        return (
            <div className="p-6 space-y-6 max-w-5xl mx-auto w-full">
                <div className="flex items-center gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2">
                        <Skeleton className="h-8 w-64" />
                        <Skeleton className="h-4 w-32" />
                    </div>
                </div>
                <div className="grid md:grid-cols-3 gap-6">
                    <Skeleton className="h-64 md:col-span-2 rounded-lg" />
                    <Skeleton className="h-64 rounded-lg" />
                </div>
            </div>
        );
    }

    const nextAction = getNextActionInfo(useCase);

    return (
        <div className="flex flex-col h-full bg-slate-50/50 dark:bg-slate-950/50">
            <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 sticky top-0 z-10">
                <div className="px-6 py-4 max-w-5xl mx-auto w-full">
                    <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                            <Button variant="ghost" size="icon" asChild>
                                <Link href="/dashboard">
                                    <ArrowLeft className="h-4 w-4" />
                                </Link>
                            </Button>
                            <div>
                                <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
                                    {useCase.title || "Untitled Use Case"}
                                </h1>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                                    <span>Created {useCase.createdAt ? format(new Date(useCase.createdAt), "MMM d, yyyy") : "Unknown"}</span>
                                    <span>•</span>
                                    <span>{useCase.businessOwner || "No Owner"}</span>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center gap-3">
                            {!isAdmin ? (
                                <Button asChild>
                                    <Link href={`/use-case/${id}`}>
                                        <Edit className="h-4 w-4 mr-2" />
                                        Edit / Continue Intake
                                    </Link>
                                </Button>
                            ) : (
                                <Button asChild variant="outline">
                                    <Link href={`/use-case/${id}`}>
                                        <ExternalLink className="h-4 w-4 mr-2" />
                                        View Details
                                    </Link>
                                </Button>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            <ScrollArea className="flex-1">
                <div className="p-6 max-w-5xl mx-auto w-full space-y-8">
                    {/* Summary Section */}
                    <section className="grid md:grid-cols-3 gap-6">
                        <div className="md:col-span-2 space-y-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Project Summary</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <h4 className="text-sm font-medium text-muted-foreground mb-1">Description</h4>
                                        <p className="text-sm leading-relaxed">
                                            {useCase.projectDescription || useCase.whatTheAIDoes || "No description provided."}
                                        </p>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <h4 className="text-sm font-medium text-muted-foreground mb-1">Target Audience</h4>
                                            <p className="text-sm">{useCase.targetAudiences || useCase.whoUsesIt || "N/A"}</p>
                                        </div>
                                        <div>
                                            <h4 className="text-sm font-medium text-muted-foreground mb-1">Executive Sponsor</h4>
                                            <p className="text-sm">{useCase.executiveSponsor || "N/A"}</p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>Risk Profile</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                        <div className="p-3 bg-muted/50 rounded-lg text-center">
                                            <div className="text-xs text-muted-foreground uppercase font-medium">Risk Score</div>
                                            <div className="text-2xl font-bold mt-1">{Math.round((useCase.calculatedRiskScore ?? useCase.riskScore ?? 0) as number)}</div>
                                        </div>
                                        <div className="p-3 bg-muted/50 rounded-lg text-center">
                                            <div className="text-xs text-muted-foreground uppercase font-medium">Risk Level</div>
                                            <Badge variant={useCase.riskLevel === "HIGH" || useCase.riskLevel === "CRITICAL" ? "destructive" : "secondary"} className="mt-1">
                                                {useCase.riskLevel || "LOW"}
                                            </Badge>
                                        </div>
                                        <div className="p-3 bg-muted/50 rounded-lg text-center">
                                            <div className="text-xs text-muted-foreground uppercase font-medium">Stage</div>
                                            <div className="text-sm font-medium mt-2">{useCase.stage}</div>
                                        </div>
                                        <div className="p-3 bg-muted/50 rounded-lg text-center">
                                            <div className="text-xs text-muted-foreground uppercase font-medium">Progress</div>
                                            <div className="text-sm font-medium mt-2">
                                                {Math.round(useCase.intakeProgressPercentage || 0)}%
                                            </div>
                                        </div>
                                    </div>

                                    <Separator className="my-4" />

                                    <h4 className="text-sm font-medium mb-3">Key Risk Factors</h4>
                                    <div className="space-y-3">
                                        <div className="flex items-center justify-between text-sm">
                                            <span>Safety Risk</span>
                                            <Badge variant="outline">{useCase.safetyRiskLikelihood || "Not Assessed"}</Badge>
                                        </div>
                                        <div className="flex items-center justify-between text-sm">
                                            <span>Security Risk</span>
                                            <Badge variant="outline">{useCase.securityRiskLikelihood || "Not Assessed"}</Badge>
                                        </div>
                                        <div className="flex items-center justify-between text-sm">
                                            <span>Privacy Risk</span>
                                            <Badge variant="outline">{useCase.privacyLikelihood || "Not Assessed"}</Badge>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>Benefit Profile</CardTitle>
                                    <CardDescription>AI-estimated business value assessment</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                        {[
                                            { label: "Revenue", value: useCase.revenueGenerationImpact },
                                            { label: "Patient Exp.", value: useCase.patientExperienceImpact },
                                            { label: "Productivity", value: useCase.employeeProductivityImpact },
                                            { label: "Satisfaction", value: useCase.employeeSatisfactionImpact },
                                        ].map((b) => (
                                            <div key={b.label} className="p-3 bg-muted/50 rounded-lg text-center">
                                                <div className="text-xs text-muted-foreground uppercase font-medium">{b.label}</div>
                                                <div className="text-2xl font-bold mt-1 text-emerald-600 dark:text-emerald-400">
                                                    {b.value ? `${b.value}/3` : <span className="text-base text-muted-foreground">—</span>}
                                                </div>
                                            </div>
                                        ))}
                                    </div>

                                    {useCase.benefitAssessmentSummary && (
                                        <>
                                            <Separator className="my-4" />
                                            <h4 className="text-sm font-medium mb-2">Assessment Summary</h4>
                                            <p className="text-sm text-muted-foreground leading-relaxed">
                                                {useCase.benefitAssessmentSummary}
                                            </p>
                                        </>
                                    )}
                                </CardContent>
                            </Card>
                        </div>

                        <div className="space-y-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <CheckCircle className="h-5 w-5" />
                                        Next Action
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    <div>
                                        <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Status</h4>
                                        <div className="flex items-start gap-2">
                                            <Badge variant={nextAction.variant} className="text-sm px-2.5 py-0.5">
                                                {nextAction.status}
                                            </Badge>
                                        </div>
                                    </div>

                                    <div>
                                        <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Waiting On</h4>
                                        <div className="flex items-center gap-2">
                                            <span className="text-sm font-semibold text-foreground/80 bg-background/50 px-2 py-1 rounded border border-primary/5 inline-block">
                                                {nextAction.waitingOn}
                                            </span>
                                        </div>
                                    </div>

                                    <div>
                                        <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Last Updated</h4>
                                        <div className="flex items-center gap-2 text-sm text-foreground/80">
                                            <Clock className="h-4 w-4 text-muted-foreground" />
                                            {useCase.updatedAt ? format(new Date(useCase.updatedAt), "MMMM d, yyyy") : "N/A"}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>Technical Context</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <h4 className="text-sm font-medium text-muted-foreground mb-1">Current Intake Level</h4>
                                        <p className="text-sm font-mono bg-muted px-2 py-1 rounded w-fit">
                                            {useCase.intakeStep || "BASIC"}
                                        </p>
                                    </div>
                                    <div>
                                        <h4 className="text-sm font-medium text-muted-foreground mb-1">AI Techniques</h4>
                                        <p className="text-sm text-foreground/90">{useCase.aiTechniquesUsed || "Not specified"}</p>
                                    </div>
                                    <div>
                                        <h4 className="text-sm font-medium text-muted-foreground mb-1">Deployment</h4>
                                        <p className="text-sm text-foreground/90">{useCase.deploymentType || "Not specified"}</p>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </section>
                </div>
            </ScrollArea>
        </div>
    );
}

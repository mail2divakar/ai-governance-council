import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { UseCaseCard } from "@/components/use-case-card";
import { EmptyState } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FolderOpen, Search, Plus, Filter } from "lucide-react";
import { useState, useMemo } from "react";
import type { UseCase, DecisionStatus } from "@shared/schema";

export function UseCasesPage() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const { data: useCases = [], isLoading } = useQuery<UseCase[]>({
    queryKey: ["/api/use-cases"],
  });

  const filteredUseCases = useMemo(() => {
    return useCases.filter((uc) => {
      const matchesSearch = 
        !searchQuery ||
        uc.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        uc.whatTheAIDoes?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = statusFilter === "all" || uc.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }, [useCases, searchQuery, statusFilter]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between gap-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="flex gap-4">
          <Skeleton className="h-10 flex-1 max-w-sm" />
          <Skeleton className="h-10 w-40" />
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-48 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div>
              <h1 className="text-xl font-semibold text-foreground">Your Use Cases</h1>
              <p className="text-sm text-muted-foreground">
                {useCases.length} use case{useCases.length !== 1 ? "s" : ""} in total
              </p>
            </div>
            <Button onClick={() => navigate("/new")} className="gap-1.5" data-testid="button-new-usecase">
              <Plus className="h-4 w-4" />
              New Use Case
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-3">
            <div className="relative flex-1 min-w-[200px] max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search use cases..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-usecases"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]" data-testid="select-status-filter">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="PENDING">Pending</SelectItem>
                <SelectItem value="APPROVE">Approved</SelectItem>
                <SelectItem value="DISAPPROVE">Disapproved</SelectItem>
                <SelectItem value="APPROVE_WITH_CONDITIONS">Conditional</SelectItem>
                <SelectItem value="NEEDS_MORE_INFORMATION">Needs Info</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-6">
          {filteredUseCases.length === 0 ? (
            useCases.length === 0 ? (
              <EmptyState
                icon={FolderOpen}
                title="No use cases yet"
                description="Start your first AI governance intake to create a use case record."
                actionLabel="Create Use Case"
                onAction={() => navigate("/new")}
              />
            ) : (
              <EmptyState
                icon={Search}
                title="No matching use cases"
                description="Try adjusting your search or filter criteria."
              />
            )
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              {filteredUseCases.map((useCase) => (
                <UseCaseCard key={useCase.id} useCase={useCase} />
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

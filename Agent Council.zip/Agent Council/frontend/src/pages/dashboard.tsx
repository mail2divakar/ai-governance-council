import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { UseCaseCard } from "@/components/use-case-card";
import { EmptyState } from "@/components/empty-state";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Search, LayoutDashboard, Filter, X, Calendar as CalendarIcon } from "lucide-react";
import { useState, useMemo } from "react";
import { format } from "date-fns";
import { DateRange } from "react-day-picker";
import { cn } from "@/lib/utils";
import type { UseCase } from "@shared/schema";

export function DashboardPage() {
    const [searchQuery, setSearchQuery] = useState("");
    const [statusFilter, setStatusFilter] = useState<string>("all");
    const [memberFilter, setMemberFilter] = useState<string>("all");
    const [dateRange, setDateRange] = useState<DateRange | undefined>();

    const { data: useCases = [], isLoading } = useQuery<UseCase[]>({
        queryKey: ["/api/use-cases"],
    });

    const uniqueMembers = useMemo(() => {
        const members = new Set<string>();
        useCases.forEach((uc) => {
            if (uc.creatorName) members.add(uc.creatorName);
        });
        return Array.from(members).sort();
    }, [useCases]);

    const activeFiltersCount = [
        statusFilter !== "all",
        memberFilter !== "all",
        dateRange?.from,
    ].filter(Boolean).length;

    const filteredUseCases = useMemo(() => {
        return useCases.filter((uc) => {
            const matchesSearch =
                !searchQuery ||
                uc.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                uc.whatTheAIDoes?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                uc.creatorName?.toLowerCase().includes(searchQuery.toLowerCase());

            const matchesStatus =
                statusFilter === "all" ||
                uc.threadStatus === statusFilter ||
                uc.status === statusFilter;

            const matchesMember =
                memberFilter === "all" || uc.creatorName === memberFilter;

            let matchesDate = true;
            if (dateRange?.from) {
                if (!uc.createdAt) {
                    matchesDate = false;
                } else {
                    const ucDate = new Date(uc.createdAt);
                    matchesDate = ucDate >= dateRange.from;
                    if (dateRange.to && matchesDate) {
                        matchesDate = ucDate <= new Date(dateRange.to.setHours(23, 59, 59, 999));
                    }
                }
            }

            return matchesSearch && matchesStatus && matchesMember && matchesDate;
        });
    }, [useCases, searchQuery, statusFilter, memberFilter, dateRange]);

    const clearFilters = () => {
        setStatusFilter("all");
        setMemberFilter("all");
        setDateRange(undefined);
    };

    if (isLoading) {
        return (
            <div className="p-6 space-y-6 max-w-7xl mx-auto w-full">
                <div className="flex items-center justify-between gap-4">
                    <Skeleton className="h-8 w-48" />
                    <Skeleton className="h-10 w-64" />
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                        <Skeleton key={i} className="h-48 rounded-lg" />
                    ))}
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full bg-slate-50/50 dark:bg-slate-950/50">
            <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 sticky top-0 z-10">
                <div className="px-6 py-4 max-w-7xl mx-auto w-full">
                    <div className="flex flex-col gap-4">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                            <div>
                                <h1 className="text-2xl font-semibold text-foreground flex items-center gap-2">
                                    <LayoutDashboard className="h-6 w-6 text-primary" />
                                    Dashboard
                                </h1>
                                <p className="text-sm text-muted-foreground mt-1">
                                    Overview of all AI governance use cases ({useCases.length})
                                </p>
                            </div>

                            <div className="flex items-center gap-2 w-full md:w-auto">
                                <div className="relative flex-1 md:w-80">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input
                                        placeholder="Search projects..."
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        className="pl-9 bg-background"
                                        data-testid="input-search-dashboard"
                                    />
                                </div>

                                <Popover>
                                    <PopoverTrigger asChild>
                                        <Button variant="outline" className="gap-2 relative" data-testid="button-filter">
                                            <Filter className="h-4 w-4" />
                                            Filter
                                            {activeFiltersCount > 0 && (
                                                <Badge variant="secondary" className="h-5 w-5 p-0 flex items-center justify-center rounded-full text-[10px]">
                                                    {activeFiltersCount}
                                                </Badge>
                                            )}
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-80 p-4" align="end">
                                        <div className="space-y-4">
                                            <div className="flex items-center justify-between">
                                                <h4 className="font-medium leading-none">Filters</h4>
                                                {activeFiltersCount > 0 && (
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={clearFilters}
                                                        className="h-auto p-0 text-muted-foreground hover:text-foreground"
                                                    >
                                                        Clear all
                                                    </Button>
                                                )}
                                            </div>

                                            <div className="space-y-2">
                                                <label className="text-sm font-medium text-muted-foreground">Status</label>
                                                <Select value={statusFilter} onValueChange={setStatusFilter}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select status" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="all">All Statuses</SelectItem>
                                                        <SelectItem value="info_required">Info Required</SelectItem>
                                                        <SelectItem value="approval_required">Approval Required</SelectItem>
                                                        <SelectItem value="approved">Approved</SelectItem>
                                                        <SelectItem value="disapproved">Disapproved</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>

                                            <div className="space-y-2">
                                                <label className="text-sm font-medium text-muted-foreground">Team Member</label>
                                                <Select value={memberFilter} onValueChange={setMemberFilter}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select team member" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="all">All Members</SelectItem>
                                                        {uniqueMembers.map((member) => (
                                                            <SelectItem key={member} value={member}>
                                                                {member}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </div>

                                            <div className="space-y-2">
                                                <label className="text-sm font-medium text-muted-foreground">Date Range</label>
                                                <Popover>
                                                    <PopoverTrigger asChild>
                                                        <Button
                                                            variant={"outline"}
                                                            className={cn(
                                                                "w-full justify-start text-left font-normal",
                                                                !dateRange && "text-muted-foreground"
                                                            )}
                                                        >
                                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                                            {dateRange?.from ? (
                                                                dateRange.to ? (
                                                                    <>
                                                                        {format(dateRange.from, "LLL dd, y")} -{" "}
                                                                        {format(dateRange.to, "LLL dd, y")}
                                                                    </>
                                                                ) : (
                                                                    format(dateRange.from, "LLL dd, y")
                                                                )
                                                            ) : (
                                                                <span>Pick a date range</span>
                                                            )}
                                                        </Button>
                                                    </PopoverTrigger>
                                                    <PopoverContent className="w-auto p-0" align="start">
                                                        <Calendar
                                                            initialFocus
                                                            mode="range"
                                                            defaultMonth={dateRange?.from}
                                                            selected={dateRange}
                                                            onSelect={setDateRange}
                                                            numberOfMonths={2}
                                                        />
                                                    </PopoverContent>
                                                </Popover>
                                            </div>
                                        </div>
                                    </PopoverContent>
                                </Popover>
                            </div>
                        </div>

                        {activeFiltersCount > 0 && (
                            <div className="flex flex-wrap gap-2">
                                {statusFilter !== "all" && (
                                    <Badge variant="secondary" className="gap-1 pl-2 pr-1">
                                        Status: {statusFilter.replace(/_/g, " ")}
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-3 w-3 p-0 hover:bg-transparent"
                                            onClick={() => setStatusFilter("all")}
                                        >
                                            <X className="h-3 w-3" />
                                        </Button>
                                    </Badge>
                                )}
                                {memberFilter !== "all" && (
                                    <Badge variant="secondary" className="gap-1 pl-2 pr-1">
                                        Team Member: {memberFilter}
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-3 w-3 p-0 hover:bg-transparent"
                                            onClick={() => setMemberFilter("all")}
                                        >
                                            <X className="h-3 w-3" />
                                        </Button>
                                    </Badge>
                                )}
                                {dateRange?.from && (
                                    <Badge variant="secondary" className="gap-1 pl-2 pr-1">
                                        Date: {format(dateRange.from, "MMM d")} - {dateRange.to ? format(dateRange.to, "MMM d") : "..."}
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-3 w-3 p-0 hover:bg-transparent"
                                            onClick={() => setDateRange(undefined)}
                                        >
                                            <X className="h-3 w-3" />
                                        </Button>
                                    </Badge>
                                )}
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={clearFilters}
                                    className="h-6 text-xs text-muted-foreground hover:text-foreground"
                                >
                                    Clear all
                                </Button>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            <ScrollArea className="flex-1">
                <div className="p-6 max-w-7xl mx-auto w-full">
                    {filteredUseCases.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-64 text-center">
                            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-4">
                                <Search className="h-6 w-6 text-muted-foreground" />
                            </div>
                            <h3 className="text-lg font-medium">No results found</h3>
                            <p className="text-muted-foreground mt-2 max-w-sm">
                                No use cases match your current filter criteria. Try creating a new use case or adjusting your filters.
                            </p>
                            <Button
                                variant="outline"
                                className="mt-4"
                                onClick={clearFilters}
                            >
                                Clear all filters
                            </Button>
                        </div>
                    ) : (
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {filteredUseCases.map((useCase) => (
                                <div key={useCase.id} className="h-full">
                                    <UseCaseCard useCase={useCase} />
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </ScrollArea>
        </div>
    );
}

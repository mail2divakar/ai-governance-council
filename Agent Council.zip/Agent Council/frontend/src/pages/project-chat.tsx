import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Send, FileText, ClipboardList, HelpCircle, BarChart, Building2, GraduationCap, Shield } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  actions?: Array<{
    label: string;
    action: string;
    prompt?: string;
    data?: any;
  }>;
}

interface SessionData {
  greeting: string;
  subtext?: string;
  userName: string;
  options: Array<{
    id: string;
    label: string;
    description: string;
    prompt: string;
    conversational?: boolean;
  }>;
}

function ChatContent({ content }: { content: string }) {
  return (
    <p className="text-sm text-foreground/90 whitespace-pre-wrap leading-relaxed">
      {content}
    </p>
  );
}

const optionIcons: Record<string, typeof FileText> = {
  baptist_health: Building2,
  ai_literacy: GraduationCap,
  policy_info: Shield,
  register_usecase: ClipboardList,
  track_status: BarChart,
  compliance_help: HelpCircle,
  risk_info: BarChart,
};

export function ProjectChatPage() {
  const [, navigate] = useLocation();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [hasStarted, setHasStarted] = useState(false);
  const [activeUseCaseId, setActiveUseCaseId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: sessionData, isLoading: sessionLoading } = useQuery<SessionData>({
    queryKey: ["/api/project/chat/session"],
  });

  const chatMutation = useMutation({
    mutationFn: async ({ message, action, actionData }: { message: string; action?: string; actionData?: any }) => {
      const response = await apiRequest("POST", "/api/project/chat", {
        message,
        history: messages.map(m => ({ role: m.role, content: m.content })),
        action,
        actionData,
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.useCaseId) {
        setActiveUseCaseId(data.useCaseId);
        queryClient.invalidateQueries({ queryKey: ["/api/use-cases"] });
      }
      setMessages(prev => [...prev, {
        role: "assistant",
        content: data.content,
        actions: data.actions,
      }]);
    },
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = (message: string, action?: string, actionData?: any) => {
    if (!message.trim()) return;

    setHasStarted(true);
    setMessages(prev => [...prev, { role: "user", content: message }]);
    setInputValue("");

    if (activeUseCaseId && !action) {
      chatMutation.mutate({ message, action: "continue_intake", actionData: { useCaseId: activeUseCaseId } });
    } else {
      chatMutation.mutate({ message, action, actionData });
    }
  };

  const handleOptionClick = (option: { id: string; prompt: string }) => {
    if (option.id === "register_usecase") {
      navigate("/new");
      return;
    }
    if (option.id === "track_status") {
      navigate("/use-cases");
      return;
    }
    const actionMap: Record<string, string> = {
      policy_info: "show_policy_categories",
      risk_info: "show_risk_model",
    };
    handleSendMessage(option.prompt, actionMap[option.id]);
  };

  const handleActionClick = (action: { action: string; prompt?: string; data?: any }) => {
    if (action.action === "start_registration" || action.action === "start_intake") {
      navigate("/new");
      return;
    }
    if (action.action === "view_my_cases") {
      navigate("/use-cases");
      return;
    }
    if (action.action === "view_use_case" && action.data?.useCaseId) {
      navigate(`/use-case/${action.data.useCaseId}`);
      return;
    }
    if (action.action === "policy_details") {
      navigate("/policies");
      return;
    }
    handleSendMessage(action.prompt || action.action, action.action, action.data);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputValue);
  };

  if (sessionLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="max-w-3xl mx-auto space-y-6">
          {!hasStarted ? (
            <div className="space-y-8 py-12">
              <div className="text-center space-y-3">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <h1 className="text-3xl font-semibold" data-testid="text-greeting">
                  {sessionData?.greeting || "Hey! I'm here to help you with AI governance."}
                </h1>
                <p className="text-lg text-muted-foreground max-w-lg mx-auto">
                  {sessionData?.subtext || "What would you like to do today?"}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                {sessionData?.options.map((option) => {
                  const Icon = optionIcons[option.id] || FileText;
                  return (
                    <Card
                      key={option.id}
                      className={cn(
                        "cursor-pointer hover-elevate transition-all border-2 border-transparent hover:border-primary/20",
                        option.id === "track_status" ? "md:col-span-2 md:w-[60%] md:mx-auto" : ""
                      )}
                      onClick={() => handleOptionClick(option)}
                      data-testid={`button-option-${option.id}`}
                    >
                      <CardContent className="p-5 flex items-start gap-4">
                        <div className="p-2.5 rounded-xl bg-primary/10 shrink-0">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-base">{option.label}</h3>
                          <p className="text-sm text-muted-foreground mt-1">{option.description}</p>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <p className="text-center text-sm text-muted-foreground">
                Or just type your question below - I'm happy to help with anything!
              </p>
            </div>
          ) : (
            <div className="space-y-4 py-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={cn(
                    "flex",
                    message.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  <div
                    className={cn(
                      "max-w-[80%] rounded-lg px-4 py-3",
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    )}
                    data-testid={`message-${message.role}-${index}`}
                  >
                    {message.role === "assistant" ? (
                      <ChatContent content={message.content} />
                    ) : (
                      <p className="text-sm">{message.content}</p>
                    )}

                    {message.actions && message.actions.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-border/50">
                        {message.actions.map((action, i) => (
                          <Button
                            key={i}
                            variant="outline"
                            size="sm"
                            onClick={() => handleActionClick(action)}
                            data-testid={`button-action-${action.action}`}
                          >
                            {action.label}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {chatMutation.isPending && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg px-4 py-3">
                    <Loader2 className="h-4 w-4 animate-spin" />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="border-t p-4 bg-background">
        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto flex gap-2">
          <Input
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask about policies, compliance, or use case registration..."
            disabled={chatMutation.isPending}
            data-testid="input-project-chat"
          />
          <Button
            type="submit"
            disabled={!inputValue.trim() || chatMutation.isPending}
            data-testid="button-send-project-chat"
          >
            {chatMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}

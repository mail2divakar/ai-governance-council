import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { CheckCircle, XCircle, AlertCircle, Calendar } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useState } from "react";

interface DecisionCase {
  id: string;
  title: string;
  status: string;
  riskLevel: string;
  riskScore: string;
  createdAt: string;
  decidedAt: string;
  decidedBy: string;
  rationale: string;
}

function StatusIcon({ status }: { status: string }) {
  if (status === "APPROVE") {
    return <CheckCircle className="h-5 w-5 text-green-600" />;
  }
  if (status === "DISAPPROVE") {
    return <XCircle className="h-5 w-5 text-red-600" />;
  }
  return <AlertCircle className="h-5 w-5 text-yellow-600" />;
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; className: string }> = {
    APPROVE: { label: "Approved", className: "bg-green-600 text-white" },
    DISAPPROVE: { label: "Rejected", className: "bg-red-600 text-white" },
    APPROVE_WITH_CONDITIONS: { label: "Approved with Conditions", className: "bg-yellow-600 text-white" },
  };
  const c = config[status] || { label: status, className: "bg-gray-500 text-white" };
  return <Badge className={c.className}>{c.label}</Badge>;
}

function RiskBadge({ level }: { level: string | null }) {
  const config: Record<string, { className: string }> = {
    LOW: { className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" },
    MEDIUM: { className: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" },
    HIGH: { className: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200" },
  };
  const c = config[level || "LOW"] || config.LOW;
  return <Badge variant="outline" className={c.className}>{level || "N/A"}</Badge>;
}

export function CouncilDecisionsPage() {
  const [search, setSearch] = useState("");

  const { data: cases = [], isLoading } = useQuery<DecisionCase[]>({
    queryKey: ["/api/council/use-cases/decisions"],
  });

  const filteredCases = cases.filter((c) =>
    c.title?.toLowerCase().includes(search.toLowerCase()) ||
    c.status?.toLowerCase().includes(search.toLowerCase())
  );

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  if (isLoading) {
    return <div className="p-4 text-muted-foreground">Loading decisions...</div>;
  }

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold">Decision History</h2>
            <p className="text-sm text-muted-foreground">
              View all finalized governance decisions
            </p>
          </div>
          <Badge variant="outline">{filteredCases.length} decisions</Badge>
        </div>
        <Input
          placeholder="Search by title or status..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
          data-testid="input-search-decisions"
        />
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {filteredCases.length === 0 ? (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <div className="text-center space-y-2">
              <CheckCircle className="h-12 w-12 mx-auto opacity-50" />
              <p>No finalized decisions yet</p>
            </div>
          </div>
        ) : (
          <div className="space-y-3 max-w-4xl">
            {filteredCases.map((c) => (
              <Link key={c.id} href={`/council/review/${c.id}`}>
                <Card 
                  className="cursor-pointer hover-elevate"
                  data-testid={`decision-history-usecase-${c.id}`}
                >
                  <CardHeader className="p-4">
                    <div className="flex items-start gap-4">
                      <StatusIcon status={c.status} />
                      <div className="flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <CardTitle className="text-base">{c.title || "Untitled"}</CardTitle>
                            <CardDescription className="flex items-center gap-2 mt-1">
                              <Calendar className="h-3 w-3" />
                              Decided {formatDate(c.decidedAt)}
                            </CardDescription>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            <StatusBadge status={c.status} />
                            <RiskBadge level={c.riskLevel} />
                          </div>
                        </div>
                        {c.rationale && (
                          <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                            {c.rationale}
                          </p>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

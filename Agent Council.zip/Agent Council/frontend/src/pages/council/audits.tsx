import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ClipboardList, Calendar, Filter, User, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface AuditLog {
  id: string;
  useCaseId: string | null;
  useCaseTitle: string | null;
  action: string;
  actorUserId: string;
  actorName: string;
  details: Record<string, any> | null;
  createdAt: string;
}

const ACTION_LABELS: Record<string, { label: string; color: string }> = {
  USER_LOGIN: { label: "User Login", color: "bg-gray-600" },
  USE_CASE_CREATED: { label: "Use Case Created", color: "bg-blue-600" },
  ASSESSMENT_RUN: { label: "Assessment Run", color: "bg-purple-600" },
  DECISION_SET: { label: "Decision Set", color: "bg-green-600" },
  POLICY_VIEWED: { label: "Policy Viewed", color: "bg-slate-600" },
  POLICY_ITEM_EDITED: { label: "Policy Item Edited", color: "bg-yellow-600" },
  OPA_UPDATED: { label: "OPA Updated", color: "bg-orange-600" },
  COUNCIL_MESSAGE_SENT: { label: "Council Message", color: "bg-indigo-600" },
  PROJECT_MESSAGE_SENT: { label: "Project Reply", color: "bg-cyan-600" },
};

function ActionBadge({ action }: { action: string }) {
  const config = ACTION_LABELS[action] || { label: action, color: "bg-gray-500" };
  return (
    <Badge className={`${config.color} text-white text-[10px]`}>
      {config.label}
    </Badge>
  );
}

export function CouncilAuditsPage() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");

  const queryParams = new URLSearchParams();
  if (statusFilter && statusFilter !== "all") queryParams.set("status", statusFilter);
  if (fromDate) queryParams.set("from", fromDate);
  if (toDate) queryParams.set("to", toDate);

  const { data: audits = [], isLoading } = useQuery<AuditLog[]>({
    queryKey: ["/api/audits", statusFilter, fromDate, toDate],
    queryFn: async () => {
      const response = await fetch(`/api/audits?${queryParams.toString()}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch audits");
      return response.json();
    },
  });

  const formatDate = (date: string) => {
    const d = new Date(date);
    return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const formatDetails = (details: Record<string, any> | null) => {
    if (!details) return "-";
    const entries = Object.entries(details).slice(0, 3);
    return entries.map(([k, v]) => `${k}: ${JSON.stringify(v)}`).join(", ");
  };

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold">Audit Logs</h2>
            <p className="text-sm text-muted-foreground">
              View all governance actions and changes
            </p>
          </div>
          <Badge variant="outline">{audits.length} records</Badge>
        </div>

        <Card>
          <CardHeader className="py-3 px-4">
            <CardTitle className="text-sm flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent className="py-3 px-4">
            <div className="flex gap-4 flex-wrap items-end">
              <div className="space-y-1">
                <Label className="text-xs">Action Type</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]" data-testid="select-action">
                    <SelectValue placeholder="All actions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All actions</SelectItem>
                    {Object.entries(ACTION_LABELS).map(([key, config]) => (
                      <SelectItem key={key} value={key}>
                        {config.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">From</Label>
                <Input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-[150px]"
                  data-testid="input-from"
                />
              </div>

              <div className="space-y-1">
                <Label className="text-xs">To</Label>
                <Input
                  type="date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-[150px]"
                  data-testid="input-to"
                />
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setStatusFilter("all");
                  setFromDate("");
                  setToDate("");
                }}
                data-testid="button-clear"
              >
                Clear
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">Loading audits...</div>
        ) : audits.length === 0 ? (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <div className="text-center space-y-2">
              <ClipboardList className="h-12 w-12 mx-auto opacity-50" />
              <p>No audit logs found</p>
            </div>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[180px]">Timestamp</TableHead>
                <TableHead className="w-[150px]">Action</TableHead>
                <TableHead className="w-[150px]">Actor</TableHead>
                <TableHead>Use Case</TableHead>
                <TableHead>Details</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {audits.map((audit) => (
                <TableRow key={audit.id} data-testid={`audit-row-${audit.id}`}>
                  <TableCell className="text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {formatDate(audit.createdAt)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <ActionBadge action={audit.action} />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1 text-sm">
                      <User className="h-3 w-3 text-muted-foreground" />
                      {audit.actorName}
                    </div>
                  </TableCell>
                  <TableCell>
                    {audit.useCaseTitle ? (
                      <div className="flex items-center gap-1 text-sm">
                        <FileText className="h-3 w-3 text-muted-foreground" />
                        <span className="truncate max-w-[200px]">{audit.useCaseTitle}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-xs">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className="text-xs text-muted-foreground truncate max-w-[300px] block">
                      {formatDetails(audit.details)}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  );
}

import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useSessionContext } from "@/App";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Send, 
  Loader2, 
  Bot, 
  User, 
  FileText,
  Users,
  History,
  ClipboardList,
  CheckCircle,
  XCircle,
  Edit,
  Eye,
  RefreshCw
} from "lucide-react";
import { format } from "date-fns";
import type { CouncilChatSession, CouncilChatMessage } from "@shared/schema";
import ReactMarkdown from "react-markdown";

export default function CouncilChat() {
  const { user } = useAuth();
  const { selectedSessionId, setSelectedSessionId } = useSessionContext();
  const [message, setMessage] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Get all sessions
  const { data: sessions = [] } = useQuery<CouncilChatSession[]>({
    queryKey: ["/api/council/chat/sessions"],
  });

  // Auto-select the most recent session if none selected
  useEffect(() => {
    if (sessions.length > 0 && !selectedSessionId) {
      setSelectedSessionId(sessions[0].id);
    }
  }, [sessions, selectedSessionId, setSelectedSessionId]);

  const { data: sessionData, isLoading: messagesLoading } = useQuery<{
    session: CouncilChatSession;
    messages: CouncilChatMessage[];
  }>({
    queryKey: ["/api/council/chat/sessions", selectedSessionId],
    enabled: !!selectedSessionId,
  });

  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/council/chat/sessions", { title: "New Chat" });
      return res.json();
    },
    onSuccess: (newSession: CouncilChatSession) => {
      queryClient.invalidateQueries({ queryKey: ["/api/council/chat/sessions"] });
      setSelectedSessionId(newSession.id);
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      let currentSessionId = selectedSessionId;
      
      // Create session if none exists
      if (!currentSessionId) {
        const res = await apiRequest("POST", "/api/council/chat/sessions", { title: "New Chat" });
        const newSession = await res.json();
        currentSessionId = newSession.id;
        setSelectedSessionId(currentSessionId);
        queryClient.invalidateQueries({ queryKey: ["/api/council/chat/sessions"] });
      }
      
      const msgRes = await apiRequest("POST", `/api/council/chat/sessions/${currentSessionId}/messages`, {
        message: content,
      });
      return msgRes.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/council/chat/sessions", selectedSessionId] });
      queryClient.invalidateQueries({ queryKey: ["/api/council/chat/sessions"] });
    },
  });

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [message]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [sessionData?.messages]);

  const handleSubmit = async () => {
    if (!message.trim() || sendMessageMutation.isPending) return;
    const content = message.trim();
    setMessage("");
    sendMessageMutation.mutate(content);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleQuickAction = (prompt: string) => {
    sendMessageMutation.mutate(prompt);
  };

  const handleStartNew = () => {
    setSelectedSessionId(null);
    createSessionMutation.mutate();
  };

  const getFirstName = () => {
    if (user?.firstName) return user.firstName;
    if (user?.email) return user.email.split("@")[0];
    return "there";
  };

  const getInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) return user.email[0].toUpperCase();
    return "U";
  };

  // Initial welcome actions
  const welcomeActions = [
    { label: "View Policies", icon: FileText, prompt: "Show me all the governance policies and let me manage them" },
    { label: "Review Use Cases", icon: Users, prompt: "Show me all use cases pending review so I can make decisions" },
    { label: "View Decisions", icon: History, prompt: "Show me the recent decisions made on use cases" },
    { label: "View Audit Logs", icon: ClipboardList, prompt: "Show me the recent audit logs" },
  ];

  const messages = sessionData?.messages || [];
  const showWelcome = messages.length === 0;

  // Parse action buttons from AI response metadata or content
  const parseActionButtons = (msg: CouncilChatMessage) => {
    // Check if metadata contains actions
    if (msg.metadata && typeof msg.metadata === 'object') {
      const meta = msg.metadata as { actions?: Array<{ label: string; prompt: string; type?: string }> };
      if (meta.actions && Array.isArray(meta.actions)) {
        return meta.actions;
      }
    }
    return [];
  };

  const getActionIcon = (type?: string) => {
    switch (type) {
      case 'approve': return CheckCircle;
      case 'disapprove': return XCircle;
      case 'edit': return Edit;
      case 'view': return Eye;
      case 'refresh': return RefreshCw;
      default: return FileText;
    }
  };

  return (
    <div className="flex flex-col h-full">
      {showWelcome ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <div className="max-w-2xl w-full space-y-8">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="h-16 w-16 rounded-full bg-primary flex items-center justify-center">
                <Bot className="h-8 w-8 text-primary-foreground" />
              </div>
              <div className="space-y-2">
                <h1 className="text-2xl font-semibold" data-testid="text-greeting">
                  Welcome, {getFirstName()}
                </h1>
                <p className="text-muted-foreground text-lg">
                  I'm your AI Governance Assistant. What would you like to do?
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {welcomeActions.map((action) => (
                <Button
                  key={action.label}
                  variant="outline"
                  onClick={() => handleQuickAction(action.prompt)}
                  className="h-auto py-4 px-4 flex flex-col items-center gap-2 hover-elevate"
                  disabled={sendMessageMutation.isPending || createSessionMutation.isPending}
                  data-testid={`quick-action-${action.label.toLowerCase().replace(/\s/g, '-')}`}
                >
                  <action.icon className="h-6 w-6 text-primary" />
                  <span className="font-medium">{action.label}</span>
                </Button>
              ))}
            </div>

            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                Or type your question below to get started
              </p>
            </div>
          </div>
        </div>
      ) : (
        <ScrollArea className="flex-1 p-4">
          <div className="max-w-3xl mx-auto space-y-6">
            {messagesLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              messages.map((msg) => {
                const actionButtons = parseActionButtons(msg);
                
                return (
                  <div
                    key={msg.id}
                    className={`flex gap-4 ${msg.role === "assistant" ? "justify-start" : "justify-end"}`}
                    data-testid={`message-${msg.id}`}
                  >
                    {msg.role === "assistant" && (
                      <Avatar className="h-9 w-9 flex-shrink-0 ring-2 ring-primary/20">
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          <Bot className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                    )}

                    <div className={`flex flex-col gap-2 ${msg.role === "assistant" ? "max-w-[85%]" : "max-w-2xl"}`}>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-muted-foreground">
                          {msg.role === "assistant" ? "AI Governance Assistant" : `${user?.firstName || "You"}`}
                        </span>
                        {msg.createdAt && (
                          <span className="text-xs text-muted-foreground/70">
                            {format(new Date(msg.createdAt), "h:mm a")}
                          </span>
                        )}
                      </div>

                      <div
                        className={`rounded-xl px-4 py-3 ${
                          msg.role === "assistant"
                            ? "bg-card border border-card-border text-card-foreground"
                            : "bg-primary text-primary-foreground"
                        }`}
                      >
                        {msg.role === "assistant" ? (
                          <div className="text-sm leading-relaxed prose prose-sm dark:prose-invert max-w-none">
                            <ReactMarkdown>{msg.content}</ReactMarkdown>
                          </div>
                        ) : (
                          <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                        )}
                      </div>

                      {/* Action buttons from AI */}
                      {msg.role === "assistant" && actionButtons.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-1">
                          {actionButtons.map((action, idx) => {
                            const IconComponent = getActionIcon(action.type);
                            return (
                              <Button
                                key={idx}
                                variant="outline"
                                size="sm"
                                onClick={() => handleQuickAction(action.prompt)}
                                disabled={sendMessageMutation.isPending}
                                className="gap-2"
                                data-testid={`action-button-${idx}`}
                              >
                                <IconComponent className="h-3 w-3" />
                                {action.label}
                              </Button>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    {msg.role === "user" && (
                      <Avatar className="h-9 w-9 flex-shrink-0 ring-2 ring-muted">
                        <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.firstName || "User"} />
                        <AvatarFallback className="bg-muted text-muted-foreground">
                          <User className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                );
              })
            )}
            
            {sendMessageMutation.isPending && (
              <div className="flex gap-4 justify-start">
                <Avatar className="h-9 w-9 flex-shrink-0 ring-2 ring-primary/20">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-card border border-card-border rounded-xl px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm text-muted-foreground">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      )}

      <div className="sticky bottom-0 border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 p-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex gap-3 items-end">
            <div className="flex-1 relative">
              <Textarea
                ref={textareaRef}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask me anything about governance, policies, or use cases..."
                disabled={sendMessageMutation.isPending}
                className="min-h-[48px] max-h-[120px] resize-none pr-4 text-sm"
                rows={1}
                data-testid="input-chat-message"
              />
            </div>
            <Button
              onClick={handleSubmit}
              disabled={!message.trim() || sendMessageMutation.isPending}
              size="default"
              className="h-12 px-4"
              data-testid="button-send-message"
            >
              {sendMessageMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
          <div className="flex items-center justify-between mt-2">
            <p className="text-xs text-muted-foreground">
              Press Enter to send, Shift + Enter for new line
            </p>
            {messages.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleStartNew}
                className="text-xs text-muted-foreground hover:text-foreground"
                data-testid="button-start-new-chat"
              >
                <RefreshCw className="h-3 w-3 mr-1" />
                Start New Conversation
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  FileText, 
  Users, 
  History, 
  ClipboardList,
  Bot
} from "lucide-react";

export default function CouncilHome() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const getFirstName = () => {
    if (user?.firstName) {
      return user.firstName;
    }
    if (user?.email) {
      return user.email.split("@")[0];
    }
    return "there";
  };

  const getInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return "U";
  };

  const actionButtons = [
    {
      label: "Policies",
      icon: FileText,
      path: "/council/policies",
      testId: "action-policies"
    },
    {
      label: "Review",
      icon: Users,
      path: "/council/review",
      testId: "action-review"
    },
    {
      label: "Decisions",
      icon: History,
      path: "/council/decisions",
      testId: "action-decisions"
    },
    {
      label: "Audits",
      icon: ClipboardList,
      path: "/council/audits",
      testId: "action-audits"
    }
  ];

  return (
    <div className="flex flex-col h-full p-6">
      <div className="flex-1 flex flex-col items-center justify-center max-w-2xl mx-auto w-full">
        <Card className="w-full">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                  <Bot className="h-5 w-5 text-primary-foreground" />
                </div>
              </div>
              <div className="flex-1 space-y-4">
                <div className="space-y-2">
                  <p className="text-lg font-medium" data-testid="text-greeting">
                    Hey {getFirstName()}, what do you want to do?
                  </p>
                  <p className="text-sm text-muted-foreground">
                    I can help you manage governance policies, review use cases, check decision history, or view audit logs.
                  </p>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {actionButtons.map((action) => (
                    <Button
                      key={action.path}
                      variant="outline"
                      onClick={() => setLocation(action.path)}
                      className="gap-2"
                      data-testid={action.testId}
                    >
                      <action.icon className="h-4 w-4" />
                      {action.label}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="mt-6 flex items-center gap-3 text-sm text-muted-foreground">
          <Avatar className="h-6 w-6">
            <AvatarImage src={user?.profileImageUrl || undefined} alt={getFirstName()} />
            <AvatarFallback className="bg-primary/10 text-primary text-xs">
              {getInitials()}
            </AvatarFallback>
          </Avatar>
          <span>Logged in as <strong className="text-foreground">{user?.firstName} {user?.lastName}</strong></span>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { MessageSquare, User, Bot, Send, CheckCircle, XCircle, AlertCircle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { UseCase } from "@shared/schema";

interface ReviewableCase {
  id: string;
  title: string;
  status: string;
  threadStatus: string;
  riskLevel: string;
  riskScore: string;
  createdAt: string;
  userId: string;
}

interface CouncilMessage {
  id: string;
  councilThreadId: string;
  role: string;
  content: string;
  createdAt: string;
}

interface CouncilReviewData {
  useCase: UseCase;
  projectMessages: any[];
  assessment: any;
  decision: any;
  councilThread: any;
  councilMessages: CouncilMessage[];
}

function RiskBadge({ level }: { level: string | null }) {
  const config: Record<string, { className: string }> = {
    LOW: { className: "bg-green-600 text-white" },
    MEDIUM: { className: "bg-yellow-600 text-white" },
    HIGH: { className: "bg-red-600 text-white" },
  };
  const c = config[level || "LOW"] || config.LOW;
  return <Badge className={c.className}>{level || "N/A"}</Badge>;
}

function StatusBadge({ status }: { status: string | null }) {
  const config: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    PENDING: { label: "Pending", variant: "secondary" },
    APPROVE: { label: "Approved", variant: "default" },
    DISAPPROVE: { label: "Rejected", variant: "destructive" },
    APPROVE_WITH_CONDITIONS: { label: "Conditional", variant: "outline" },
    NEEDS_MORE_INFORMATION: { label: "Needs Info", variant: "outline" },
  };
  const c = config[status || "PENDING"] || config.PENDING;
  return <Badge variant={c.variant}>{c.label}</Badge>;
}

function ReviewList() {
  const { data: cases = [], isLoading } = useQuery<ReviewableCase[]>({
    queryKey: ["/api/council/use-cases/review"],
  });

  if (isLoading) {
    return <div className="p-4 text-muted-foreground">Loading cases...</div>;
  }

  if (cases.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground">
        <div className="text-center space-y-2">
          <MessageSquare className="h-12 w-12 mx-auto opacity-50" />
          <p>No use cases ready for review</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-lg font-semibold">Cases for Review</h2>
      {cases.map((c) => (
        <Link key={c.id} href={`/council/review/${c.id}`}>
          <Card className="cursor-pointer hover-elevate" data-testid={`review-card-${c.id}`}>
            <CardHeader className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <CardTitle className="text-sm">{c.title || "Untitled"}</CardTitle>
                  <CardDescription className="text-xs">
                    Created {new Date(c.createdAt).toLocaleDateString()}
                  </CardDescription>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <RiskBadge level={c.riskLevel} />
                  <StatusBadge status={c.status} />
                </div>
              </div>
            </CardHeader>
          </Card>
        </Link>
      ))}
    </div>
  );
}

function ReviewDetail({ id }: { id: string }) {
  const [message, setMessage] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery<CouncilReviewData>({
    queryKey: ["/api/council/use-cases", id],
  });

  const createThreadMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/council/use-cases/${id}/thread`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/council/use-cases", id] });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      let threadId = data?.councilThread?.id;
      if (!threadId) {
        const response = await createThreadMutation.mutateAsync();
        const newThread = response as unknown as { id: string };
        threadId = newThread.id;
      }
      return apiRequest("POST", `/api/council/threads/${threadId}/messages`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/council/use-cases", id] });
      setMessage("");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const decisionMutation = useMutation({
    mutationFn: async ({ status, rationale }: { status: string; rationale: string }) => {
      return apiRequest("POST", `/api/council/use-cases/${id}/decision`, { status, rationale });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/council/use-cases", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/council/use-cases/review"] });
      toast({ title: "Decision recorded successfully" });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to record decision",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (message.trim()) {
      sendMessageMutation.mutate(message);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleDecision = (status: string) => {
    decisionMutation.mutate({ status, rationale: "Council decision" });
  };

  if (isLoading) {
    return <div className="p-4 text-muted-foreground">Loading case details...</div>;
  }

  if (!data?.useCase) {
    return <div className="p-4 text-muted-foreground">Case not found</div>;
  }

  const { useCase, projectMessages = [], assessment, councilMessages = [] } = data;

  return (
    <div className="flex flex-col h-full">
      <div className="border-b p-4">
        <div className="flex items-center gap-4">
          <Link href="/council/review">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h2 className="text-lg font-semibold">{useCase.title}</h2>
            <p className="text-sm text-muted-foreground">Risk Score: {useCase.riskScore || "N/A"}</p>
          </div>
          <div className="flex gap-2">
            <RiskBadge level={useCase.riskLevel} />
            <StatusBadge status={useCase.status} />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="details" className="h-full flex flex-col">
          <div className="border-b px-4">
            <TabsList>
              <TabsTrigger value="details">Use Case Details</TabsTrigger>
              <TabsTrigger value="project-chat">Project Chat</TabsTrigger>
              <TabsTrigger value="council-chat">Council Discussion</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="details" className="flex-1 overflow-y-auto p-4 m-0 data-[state=inactive]:hidden">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Use Case Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div><strong>What the AI does:</strong> {useCase.whatTheAIDoes || "N/A"}</div>
                  <div><strong>Who uses it:</strong> {useCase.whoUsesIt || "N/A"}</div>
                  <div><strong>User population:</strong> {useCase.userPopulation || "N/A"}</div>
                  <div><strong>Data touched:</strong> {useCase.dataItMightTouch || "N/A"}</div>
                  <div><strong>Data classification:</strong> {useCase.dataClassification || "N/A"}</div>
                  <div><strong>Personal data:</strong> {useCase.hasPersonalData || "N/A"}</div>
                  <div><strong>Sensitive data:</strong> {useCase.hasSensitiveData || "N/A"}</div>
                  <div><strong>Decisions/actions:</strong> {useCase.decisionsOrActions || "N/A"}</div>
                  <div><strong>Third-party tools:</strong> {useCase.thirdPartyTools || "N/A"}</div>
                </CardContent>
              </Card>

              {assessment && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Governance Assessment</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div><strong>Domains:</strong> {assessment.domains?.join(", ") || "N/A"}</div>
                    <div><strong>Risks:</strong> {assessment.risks?.join(", ") || "N/A"}</div>
                    <div><strong>Gaps:</strong> {assessment.gaps?.join(", ") || "N/A"}</div>
                    <div><strong>Recommendations:</strong> {assessment.recommendations?.join(", ") || "N/A"}</div>
                  </CardContent>
                </Card>
              )}

              {!data.decision && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Record Decision</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2 flex-wrap">
                      <Button
                        onClick={() => handleDecision("APPROVE")}
                        disabled={decisionMutation.isPending}
                        className="bg-green-600 hover:bg-green-700"
                        data-testid="button-approve"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Approve
                      </Button>
                      <Button
                        onClick={() => handleDecision("APPROVE_WITH_CONDITIONS")}
                        disabled={decisionMutation.isPending}
                        variant="outline"
                        data-testid="button-approve-conditions"
                      >
                        <AlertCircle className="h-4 w-4 mr-2" />
                        Approve with Conditions
                      </Button>
                      <Button
                        onClick={() => handleDecision("NEEDS_MORE_INFORMATION")}
                        disabled={decisionMutation.isPending}
                        variant="secondary"
                        data-testid="button-needs-info"
                      >
                        Needs More Info
                      </Button>
                      <Button
                        onClick={() => handleDecision("DISAPPROVE")}
                        disabled={decisionMutation.isPending}
                        variant="destructive"
                        data-testid="button-reject"
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="project-chat" className="flex-1 overflow-y-auto p-4 m-0 data-[state=inactive]:hidden">
            <div className="space-y-3">
              {projectMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {msg.role !== "user" && (
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Bot className="h-4 w-4 text-primary" />
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                  </div>
                  {msg.role === "user" && (
                    <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center">
                      <User className="h-4 w-4" />
                    </div>
                  )}
                </div>
              ))}
              {projectMessages.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No messages yet</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="council-chat" className="flex-1 flex flex-col overflow-hidden m-0 data-[state=inactive]:hidden">
            <div className="flex-1 overflow-y-auto p-4">
              <div className="space-y-3">
                {councilMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${msg.role === "council" ? "justify-end" : "justify-start"}`}
                  >
                    {msg.role !== "council" && (
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <Bot className="h-4 w-4 text-primary" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        msg.role === "council" ? "bg-primary text-primary-foreground" : "bg-muted"
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                    </div>
                    {msg.role === "council" && (
                      <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center">
                        <User className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                ))}
                {councilMessages.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    Start a council discussion about this use case
                  </p>
                )}
              </div>
            </div>

            <div className="border-t p-4">
              <div className="flex gap-2">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleKeyPress}
                  placeholder="Discuss this use case with the AI assistant... (Press Enter to send)"
                  className="min-h-[80px] flex-1"
                  data-testid="textarea-council-message"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={sendMessageMutation.isPending || !message.trim()}
                  data-testid="button-send-council"
                  className="self-end"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export function CouncilReviewPage() {
  const [match, params] = useRoute("/council/review/:id");

  if (match && params?.id) {
    return <ReviewDetail id={params.id} />;
  }

  return <ReviewList />;
}

import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { FileText, Edit, Eye, Save, X, ArrowLeft, Code, Plus, Send, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PolicyItem {
  id: string;
  policyId: string;
  itemIndex: number;
  title: string;
  statement: string;
  controls: string[] | null;
}

interface PolicyData {
  policy: {
    id: string;
    category: string;
    fullName: string;
    version: number;
    status: string;
  };
  items: PolicyItem[];
  opaVersion: number | null;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

const POLICY_CATEGORIES = [
  { key: "INTAKE", name: "AI Use-Case Intake & Approval Policy", description: "Requirements for submitting AI use cases" },
  { key: "DATA", name: "Data Governance & Privacy Policy", description: "Data handling and privacy policies" },
  { key: "MODEL", name: "Model Risk & Performance Management Policy", description: "Risk assessment and model management" },
  { key: "MONITOR", name: "AI Monitoring, Audit & Accountability Policy", description: "Monitoring and audit requirements" },
  { key: "ETHICS", name: "Responsible AI & Ethical Use Policy", description: "Ethical principles and responsible AI" },
];

type ViewState = "select-category" | "select-action" | "view" | "edit-select" | "edit-item" | "opa-upgrade" | "create-policy" | "opa-chat";

export function CouncilPoliciesPage() {
  const [viewState, setViewState] = useState<ViewState>("select-category");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedItemIndex, setSelectedItemIndex] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editStatement, setEditStatement] = useState("");
  const [editControls, setEditControls] = useState("");
  const [opaBundle, setOpaBundle] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: policyData, isLoading } = useQuery<PolicyData>({
    queryKey: ["/api/policies", selectedCategory],
    enabled: !!selectedCategory,
  });

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  const editItemMutation = useMutation({
    mutationFn: async ({ category, itemIndex, title, statement, controls }: { 
      category: string; 
      itemIndex: number; 
      title: string; 
      statement: string; 
      controls: string[];
    }) => {
      return apiRequest("POST", `/api/policies/${category}/item/${itemIndex}/edit`, { title, statement, controls });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/policies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/policies", selectedCategory] });
      toast({ title: "Policy item updated successfully" });
      setViewState("view");
    },
    onError: (error: any) => {
      toast({ title: "Failed to update policy item", description: error.message, variant: "destructive" });
    },
  });

  const opaUpgradeMutation = useMutation({
    mutationFn: async ({ category, bundle }: { category: string; bundle: object }) => {
      return apiRequest("POST", `/api/policies/${category}/opa`, { bundle });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/policies", selectedCategory] });
      toast({ title: "OPA bundle updated successfully" });
      setViewState("select-action");
      setOpaBundle("");
      setChatMessages([]);
    },
    onError: (error: any) => {
      toast({ title: "Failed to update OPA bundle", description: error.message, variant: "destructive" });
    },
  });

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setViewState("select-action");
  };

  const handleBack = () => {
    if (viewState === "select-action") {
      setSelectedCategory(null);
      setViewState("select-category");
    } else if (viewState === "view" || viewState === "edit-select" || viewState === "opa-upgrade" || viewState === "create-policy" || viewState === "opa-chat") {
      setChatMessages([]);
      setChatInput("");
      setViewState("select-action");
    } else if (viewState === "edit-item") {
      setViewState("edit-select");
    }
  };

  const handleView = () => setViewState("view");
  const handleEditSelect = () => setViewState("edit-select");
  const handleOpaUpgrade = () => setViewState("opa-upgrade");
  
  const handleCreatePolicy = () => {
    setChatMessages([{
      role: "assistant",
      content: "Welcome! I'll help you create a new policy item. Each policy has 5 items with a title, statement, and controls.\n\n**What topic would you like this policy item to cover?**\n\nFor example: data classification requirements, model validation procedures, ethics review processes, etc."
    }]);
    setViewState("create-policy");
  };

  const handleOpaChat = () => {
    setChatMessages([{
      role: "assistant",
      content: `I'll help you create or upgrade the OPA (Open Policy Agent) bundle for this policy.\n\n**Current OPA Version:** ${policyData?.opaVersion || "None"}\n\nLet's start by understanding your compliance requirements. **What specific rules or checks do you want the OPA bundle to enforce?**`
    }]);
    setViewState("opa-chat");
  };

  const handleEditItem = (index: number) => {
    const item = policyData?.items.find(i => i.itemIndex === index);
    if (item) {
      setSelectedItemIndex(index);
      setEditTitle(item.title);
      setEditStatement(item.statement);
      setEditControls(item.controls?.join("\n") || "");
      setViewState("edit-item");
    }
  };

  const handleSaveItem = () => {
    if (selectedCategory && selectedItemIndex) {
      const controls = editControls.split("\n").filter(c => c.trim());
      editItemMutation.mutate({
        category: selectedCategory,
        itemIndex: selectedItemIndex,
        title: editTitle,
        statement: editStatement,
        controls,
      });
    }
  };

  const handleSaveOpa = () => {
    if (selectedCategory && opaBundle) {
      try {
        const bundle = JSON.parse(opaBundle);
        opaUpgradeMutation.mutate({ category: selectedCategory, bundle });
      } catch {
        toast({ title: "Invalid JSON", description: "Please enter valid JSON for the OPA bundle", variant: "destructive" });
      }
    }
  };

  const handleSendChatMessage = async () => {
    if (!chatInput.trim() || !selectedCategory || isSending) return;

    const userMessage = chatInput.trim();
    setChatInput("");
    setChatMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setIsSending(true);

    try {
      const endpoint = viewState === "create-policy" 
        ? `/api/policies/${selectedCategory}/create-chat`
        : `/api/policies/${selectedCategory}/opa-chat`;

      const response = await apiRequest("POST", endpoint, {
        message: userMessage,
        conversationHistory: chatMessages,
      });
      
      const data = await response.json();
      setChatMessages(prev => [...prev, { role: "assistant", content: data.response }]);

      if (viewState === "opa-chat" && data.response.includes("```json")) {
        const jsonMatch = data.response.match(/```json\s*([\s\S]*?)\s*```/);
        if (jsonMatch) {
          setOpaBundle(jsonMatch[1].trim());
        }
      }
    } catch (error: any) {
      toast({ title: "Failed to get response", description: error.message, variant: "destructive" });
    } finally {
      setIsSending(false);
    }
  };

  const handleChatKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendChatMessage();
    }
  };

  const categoryInfo = POLICY_CATEGORIES.find(c => c.key === selectedCategory);

  const renderChatInterface = (title: string, showOpaExtract: boolean = false) => (
    <div className="flex flex-col h-full">
      <Card className="flex-1 flex flex-col overflow-hidden">
        <CardHeader className="border-b py-3">
          <CardTitle className="text-base">{title}</CardTitle>
          <CardDescription>Chat with AI to complete this task</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-4">
          <div className="space-y-4">
            {chatMessages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {msg.role === "assistant" && (
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                )}
                <div className={`max-w-[80%] rounded-lg p-3 ${msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                  <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                </div>
                {msg.role === "user" && (
                  <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                    <User className="h-4 w-4" />
                  </div>
                )}
              </div>
            ))}
            {isSending && (
              <div className="flex gap-3 justify-start">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bot className="h-4 w-4 text-primary animate-pulse" />
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <p className="text-sm text-muted-foreground">Thinking...</p>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
        </CardContent>
        <div className="border-t p-4">
          <div className="flex gap-2">
            <Textarea
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={handleChatKeyPress}
              placeholder="Type your message... (Press Enter to send)"
              className="min-h-[60px] flex-1"
              data-testid="textarea-policy-chat"
            />
            <Button
              onClick={handleSendChatMessage}
              disabled={isSending || !chatInput.trim()}
              className="self-end"
              data-testid="button-send-policy-chat"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          {showOpaExtract && opaBundle && (
            <div className="mt-4">
              <Label className="text-sm mb-2">Extracted OPA Bundle:</Label>
              <Textarea
                value={opaBundle}
                onChange={(e) => setOpaBundle(e.target.value)}
                className="font-mono text-sm mt-2"
                rows={6}
              />
              <Button 
                onClick={handleSaveOpa} 
                disabled={opaUpgradeMutation.isPending}
                className="mt-2"
                data-testid="button-save-opa-from-chat"
              >
                <Save className="h-4 w-4 mr-2" />
                Save OPA Bundle
              </Button>
            </div>
          )}
        </div>
      </Card>
    </div>
  );

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center gap-4">
          {viewState !== "select-category" && (
            <Button variant="ghost" size="icon" onClick={handleBack} data-testid="button-back">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          )}
          <div>
            <h2 className="text-lg font-semibold">
              {viewState === "select-category" ? "Governance Policies" : categoryInfo?.name}
            </h2>
            <p className="text-sm text-muted-foreground">
              {viewState === "select-category" 
                ? "Select a policy category to view or manage"
                : categoryInfo?.description}
            </p>
          </div>
          {policyData?.policy && (
            <Badge variant="outline" className="ml-auto">v{policyData.policy.version}</Badge>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {viewState === "select-category" && (
          <div className="grid gap-3 max-w-2xl">
            <p className="text-sm text-muted-foreground mb-2">
              Please select a policy category:
            </p>
            {POLICY_CATEGORIES.map((category) => (
              <Button
                key={category.key}
                variant="outline"
                className="justify-start h-auto py-4 px-4"
                onClick={() => handleCategorySelect(category.key)}
                data-testid={`policy-category-${category.key}`}
              >
                <FileText className="h-5 w-5 mr-3 text-primary" />
                <div className="text-left">
                  <div className="font-medium">{category.name}</div>
                  <div className="text-xs text-muted-foreground">{category.description}</div>
                </div>
              </Button>
            ))}
          </div>
        )}

        {viewState === "select-action" && (
          <div className="grid gap-3 max-w-md">
            <p className="text-sm text-muted-foreground mb-2">
              What would you like to do with this policy?
            </p>
            <Button
              variant="outline"
              className="justify-start h-12"
              onClick={handleView}
              data-testid="policy-action-view"
            >
              <Eye className="h-4 w-4 mr-3" />
              VIEW - View all policy items
            </Button>
            <Button
              variant="outline"
              className="justify-start h-12"
              onClick={handleEditSelect}
              data-testid="policy-action-edit"
            >
              <Edit className="h-4 w-4 mr-3" />
              EDIT - Edit individual policy items
            </Button>
            <Button
              variant="outline"
              className="justify-start h-12"
              onClick={handleCreatePolicy}
              data-testid="policy-action-create"
            >
              <Plus className="h-4 w-4 mr-3" />
              CREATE - Create new policy item with AI
            </Button>
            <Button
              variant="outline"
              className="justify-start h-12"
              onClick={handleOpaChat}
              data-testid="policy-action-opa-chat"
            >
              <Code className="h-4 w-4 mr-3" />
              OPA UPGRADE - Update OPA bundle with AI
            </Button>
          </div>
        )}

        {viewState === "view" && policyData && (
          <div className="space-y-4 max-w-3xl">
            {policyData.items.map((item) => (
              <Card key={item.id} data-testid={`policy-item-${item.itemIndex}`}>
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">#{item.itemIndex}</Badge>
                    <CardTitle className="text-base">{item.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-foreground mb-3">{item.statement}</p>
                  {item.controls && item.controls.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Controls:</p>
                      <ul className="list-disc list-inside text-sm text-muted-foreground">
                        {item.controls.map((control, i) => (
                          <li key={i}>{control}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {viewState === "edit-select" && policyData && (
          <div className="grid gap-3 max-w-md">
            <p className="text-sm text-muted-foreground mb-2">
              Select a policy item to edit:
            </p>
            {[1, 2, 3, 4, 5].map((index) => {
              const item = policyData.items.find(i => i.itemIndex === index);
              return (
                <Button
                  key={index}
                  variant="outline"
                  className="justify-start h-auto py-3"
                  onClick={() => handleEditItem(index)}
                  data-testid={`policy-edit-item-${index}`}
                >
                  <Badge variant="secondary" className="mr-3">#{index}</Badge>
                  <span className="truncate">{item?.title || `Policy Item ${index}`}</span>
                </Button>
              );
            })}
          </div>
        )}

        {viewState === "edit-item" && (
          <div className="space-y-4 max-w-2xl">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Edit Policy Item #{selectedItemIndex}</CardTitle>
                <CardDescription>Update the policy item details below</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    placeholder="Policy item title"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="statement">Statement</Label>
                  <Textarea
                    id="statement"
                    value={editStatement}
                    onChange={(e) => setEditStatement(e.target.value)}
                    placeholder="Policy statement (1-3 sentences)"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="controls">Controls (one per line)</Label>
                  <Textarea
                    id="controls"
                    value={editControls}
                    onChange={(e) => setEditControls(e.target.value)}
                    placeholder="Control 1&#10;Control 2&#10;Control 3"
                    rows={4}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleSaveItem} disabled={editItemMutation.isPending} data-testid="policy-save">
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                  <Button variant="outline" onClick={handleBack}>
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {viewState === "opa-upgrade" && (
          <div className="space-y-4 max-w-2xl">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">OPA Bundle Upgrade</CardTitle>
                <CardDescription>
                  Enter the new OPA policy bundle in JSON format
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={opaBundle}
                  onChange={(e) => setOpaBundle(e.target.value)}
                  placeholder='{"package": "ai.governance", "rules": [...]}'
                  rows={10}
                  className="font-mono text-sm"
                />
                <div className="flex gap-2">
                  <Button 
                    onClick={handleSaveOpa} 
                    disabled={opaUpgradeMutation.isPending || !opaBundle.trim()}
                    data-testid="opa-save"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save OPA Bundle
                  </Button>
                  <Button variant="outline" onClick={handleBack}>
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {viewState === "create-policy" && renderChatInterface("Create New Policy Item")}

        {viewState === "opa-chat" && renderChatInterface("OPA Bundle Upgrade Assistant", true)}

        {isLoading && viewState !== "select-category" && (
          <div className="text-muted-foreground">Loading policy data...</div>
        )}
      </div>
    </div>
  );
}

import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { ChatMessage } from "@/components/chat-message";
import { ChatInput } from "@/components/chat-input";
import { IntakeFormPanel } from "@/components/intake-form-panel";
// import { WorkflowStepper } from "@/components/workflow-stepper";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Loader2, MessageSquare, FileText, Save, Send } from "lucide-react";
import type { Message, UseCase, Stage, RiskLevel } from "@shared/schema";

const welcomeMessage: Message = {
  id: "welcome",
  useCaseId: "",
  role: "agent",
  content:
    "Welcome! I'm your AI Governance Council Officer. I help intake, analyze, and govern AI use cases across their lifecycle.\n\nStart with a quick brain-dump in 1–2 paragraphs (you can copy this pattern):\n\n\"We are building *what it is* for *who uses it* to *value*. It uses *data sources*. It does/does not make automated decisions; *human review* We use *vendor/tools*.\"\n\nNow, describe your AI use case in a similar way.",
  metadata: null,
  createdAt: new Date(),
};


export function NewUseCasePage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [currentUseCaseId, setCurrentUseCaseId] = useState<string | null>(null);
  const [localMessages, setLocalMessages] = useState<Message[]>([]);

  const { data: messages = [], isLoading: isLoadingMessages, isFetched } = useQuery<Message[]>({
    queryKey: ["/api/use-cases", currentUseCaseId, "messages"],
    enabled: !!currentUseCaseId,
  });

  const { data: useCase, refetch: refetchUseCase } = useQuery<UseCase>({
    queryKey: ["/api/use-cases", currentUseCaseId],
    enabled: !!currentUseCaseId,
  });

  useEffect(() => {
    if (isFetched && messages.length > 0) {
      setLocalMessages(messages);
    }
  }, [messages, isFetched]);

  const createUseCaseMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/use-cases", {
        title: message.slice(0, 100),
        initialMessage: message,
      });
      return response.json() as Promise<UseCase>;
    },
    onMutate: (message) => {
      const tempUserMessage: Message = {
        id: `temp-user-${Date.now()}`,
        useCaseId: "",
        role: "user",
        content: message,
        metadata: null,
        createdAt: new Date(),
      };
      setLocalMessages([tempUserMessage]);
    },
    onSuccess: (data) => {
      setCurrentUseCaseId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases"] });
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", data.id, "messages"] });
    },
    onError: () => {
      setLocalMessages([]);
      toast({
        title: "Error",
        description: "Failed to create use case. Please try again.",
        variant: "destructive",
      });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", `/api/use-cases/${currentUseCaseId}/messages`, {
        content: message,
      });
      return response.json() as Promise<Message>;
    },
    onMutate: (message) => {
      const tempUserMessage: Message = {
        id: `temp-user-${Date.now()}`,
        useCaseId: currentUseCaseId || "",
        role: "user",
        content: message,
        metadata: null,
        createdAt: new Date(),
      };
      setLocalMessages(prev => [...prev, tempUserMessage]);
    },
    onSuccess: (agentMessage) => {
      setLocalMessages(prev => [...prev, agentMessage]);
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", currentUseCaseId, "messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", currentUseCaseId] });
    },
    onError: () => {
      setLocalMessages(prev => prev.slice(0, -1));
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateFieldMutation = useMutation({
    mutationFn: async ({ field, value }: { field: string; value: string | number }) => {
      const response = await apiRequest("PATCH", `/api/use-cases/${currentUseCaseId}`, {
        [field]: value,
      });
      return response.json() as Promise<UseCase>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", currentUseCaseId] });
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PATCH", `/api/use-cases/${currentUseCaseId}`, {
        status: "DRAFT",
      });
      return response.json() as Promise<UseCase>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", currentUseCaseId] });
      toast({
        title: "Saved",
        description: "Your use case has been saved as a draft.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save. Please try again.",
        variant: "destructive",
      });
    },
  });

  const submitMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PATCH", `/api/use-cases/${currentUseCaseId}`, {
        status: "SUBMITTED",
        stage: "ASSESSMENT",
      });
      return response.json() as Promise<UseCase>;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/use-cases", data.id] });
      toast({
        title: "Submitted",
        description: "Your use case has been submitted for validation.",
      });
      if (data.id) {
        navigate(`/use-case/${data.id}`);
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [localMessages]);

  const handleSendMessage = (message: string) => {
    if (!currentUseCaseId) {
      createUseCaseMutation.mutate(message);
    } else {
      sendMessageMutation.mutate(message);
    }
  };

  const handleStartNew = () => {
    setCurrentUseCaseId(null);
    setLocalMessages([]);
  };

  const handleFormFieldChange = (field: string, value: string | number, isSensitive: boolean, label?: string) => {
    if (!currentUseCaseId) return;

    updateFieldMutation.mutate({ field, value });

    if (isSensitive) {
      const displayLabel = label || field;
      const message = `[FORM UPDATE] ${displayLabel} changed to "${value}". Please provide risk recommendations.`;
      sendMessageMutation.mutate(message);
    }
  };

  const handleSave = () => {
    if (currentUseCaseId) {
      saveMutation.mutate();
    }
  };

  const handleSubmit = () => {
    if (currentUseCaseId) {
      submitMutation.mutate();
    }
  };

  const stage = (useCase?.stage as Stage) || "BASIC_INFO";
  const riskScore = parseInt(useCase?.riskScore || "0", 10);
  const riskLevel = (useCase?.riskLevel as RiskLevel) || "LOW";
  const riskDrivers = useCase?.riskDrivers || [];
  const isLoading = createUseCaseMutation.isPending || sendMessageMutation.isPending;
  const isSaving = saveMutation.isPending;
  const isSubmitting = submitMutation.isPending;

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* <WorkflowStepper currentPhase="intake" /> */}

      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 flex-shrink-0">
        <div className="px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <FileText className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground">
                {currentUseCaseId ? (useCase?.title || "AI Governance Intake") : "AI Governance Intake"}
              </h1>
              <p className="text-xs text-muted-foreground">
                {currentUseCaseId ? `Stage: ${stage.replace("_", " ")}` : "Start a conversation to begin"}
              </p>
            </div>
          </div>
          {currentUseCaseId && (
            <Button variant="outline" size="sm" onClick={handleStartNew} className="gap-1.5" data-testid="button-new-intake">
              <Plus className="h-4 w-4" />
              New Intake
            </Button>
          )}
        </div>
      </div>

      <div className="flex-1 flex min-h-0 overflow-hidden">
        {currentUseCaseId ? (
          <>
            <div className="flex-1 flex flex-col border-r bg-muted/30 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4">
                <IntakeFormPanel
                  useCase={useCase}
                  stage={stage}
                  riskScore={riskScore}
                  riskLevel={riskLevel}
                  riskDrivers={riskDrivers}
                  onFieldChange={handleFormFieldChange}
                />
              </div>

              <div className="border-t bg-background p-4 flex items-center justify-end gap-3 flex-shrink-0">
                <Button
                  variant="outline"
                  onClick={handleSave}
                  disabled={isSaving || isSubmitting}
                  className="gap-2"
                  data-testid="button-save"
                >
                  {isSaving ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  Save
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={isSaving || isSubmitting}
                  className="gap-2"
                  data-testid="button-submit"
                >
                  {isSubmitting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  Submit
                </Button>
              </div>
            </div>

            <div className="w-[420px] flex flex-col overflow-hidden bg-background">
              <div className="border-b px-4 py-2 flex items-center gap-2 bg-muted/20">
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Chat with AI Assistant</span>
              </div>

              <div
                ref={scrollRef}
                className="flex-1 overflow-y-auto min-h-0"
              >
                <div className="px-4 py-4 space-y-4">
                  <ChatMessage
                    message={welcomeMessage}
                    userImage={user?.profileImageUrl}
                    userName={user?.firstName || user?.email || "You"}
                  />

                  {isLoadingMessages ? (
                    <div className="space-y-4">
                      {[1, 2].map((i) => (
                        <div key={i} className="flex gap-3">
                          <Skeleton className="h-8 w-8 rounded-full flex-shrink-0" />
                          <div className="space-y-2 flex-1">
                            <Skeleton className="h-3 w-24" />
                            <Skeleton className="h-16 w-full rounded-lg" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    localMessages.map((message) => (
                      <ChatMessage
                        key={message.id}
                        message={message}
                        userImage={user?.profileImageUrl}
                        userName={user?.firstName || user?.email || "You"}
                      />
                    ))
                  )}

                  {isLoading && (
                    <div className="flex gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary flex-shrink-0">
                        <Loader2 className="h-4 w-4 text-primary-foreground animate-spin" />
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <span>Thinking...</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t p-3">
                <ChatInput
                  onSend={handleSendMessage}
                  isLoading={isLoading}
                  placeholder="Ask a question or describe your use case..."
                />
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8">
            <div className="max-w-xl w-full space-y-6">
              <div className="text-center space-y-2">
                <div className="flex justify-center mb-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                    <MessageSquare className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h2 className="text-2xl font-semibold">Start Your AI Governance Intake</h2>
                <p className="text-muted-foreground">
                  Describe your AI use case and I'll help you complete the governance form while we chat.
                </p>
              </div>

              <div className="bg-muted/30 rounded-lg p-4">
                <ChatMessage
                  message={welcomeMessage}
                  userImage={user?.profileImageUrl}
                  userName={user?.firstName || user?.email || "You"}
                />
              </div>

              <ChatInput
                onSend={handleSendMessage}
                isLoading={isLoading}
                placeholder="Describe your AI use case to get started..."
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

import { useState, createContext, useContext, useEffect } from "react";
import { app } from "@microsoft/teams-js";
import { Switch, Route, Redirect, useRoute } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { useAuth } from "@/hooks/use-auth";
import { Skeleton } from "@/components/ui/skeleton";
import { LandingPage } from "@/pages/landing";
import { DevLoginPage } from "@/pages/dev-login";
import { DashboardPage } from "@/pages/dashboard";
import { NewUseCasePage } from "@/pages/new-use-case";
import { UseCasesPage } from "@/pages/use-cases";
import { UseCaseOverviewPage } from "@/pages/use-case-overview";
import { UseCaseDetailPage } from "@/pages/use-case-detail";
import { ProjectChatPage } from "@/pages/project-chat";
import { CouncilPoliciesPage } from "@/pages/council/policies";
import { CouncilReviewPage } from "@/pages/council/review";
import { CouncilDecisionsPage } from "@/pages/council/decisions";
import { CouncilAuditsPage } from "@/pages/council/audits";
import CouncilHome from "@/pages/council/home";
import CouncilChat from "@/pages/council/chat";
import NotFound from "@/pages/not-found";
import { QuestionConfigPage } from "@/pages/question-config";
import { AdminDocumentsPage } from "@/pages/admin/documents";
import { AdminUsersPage } from "@/pages/admin/users";
import { InvitePage } from "@/pages/invite";

// Context for session selection across sidebar and chat
const SessionContext = createContext<{
  selectedSessionId: string | null;
  setSelectedSessionId: (id: string | null) => void;
}>({ selectedSessionId: null, setSelectedSessionId: () => { } });

export const useSessionContext = () => useContext(SessionContext);

function AuthenticatedLayout({ children }: { children: React.ReactNode }) {
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const style = {
    "--sidebar-width": "17rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SessionContext.Provider value={{ selectedSessionId, setSelectedSessionId }}>
      <SidebarProvider style={style as React.CSSProperties}>
        <div className="flex h-screen w-full">
          <AppSidebar onSelectSession={setSelectedSessionId} />
          <SidebarInset className="flex flex-col flex-1 overflow-hidden">
            <header className="flex h-14 items-center justify-between border-b px-4 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <ThemeToggle />
            </header>
            <main className="flex-1 overflow-hidden">
              {children}
            </main>
          </SidebarInset>
        </div>
      </SidebarProvider>
    </SessionContext.Provider>
  );
}

function ProjectRoutes() {
  return (
    <AuthenticatedLayout>
      <Switch>
        <Route path="/" component={ProjectChatPage} />
        <Route path="/chat" component={ProjectChatPage} />
        <Route path="/dashboard" component={DashboardPage} />
        <Route path="/new" component={NewUseCasePage} />
        <Route path="/use-cases" component={UseCasesPage} />
        <Route path="/use-case/:id/overview" component={UseCaseOverviewPage} />
        <Route path="/use-case/:id" component={UseCaseDetailPage} />
        <Route component={NotFound} />
      </Switch>
    </AuthenticatedLayout>
  );
}

function CouncilRoutes() {
  return (
    <AuthenticatedLayout>
      <Switch>
        <Route path="/" component={CouncilChat} />
        <Route path="/council/home" component={CouncilChat} />
        <Route path="/council/chat" component={CouncilChat} />
        <Route path="/council/policies" component={CouncilPoliciesPage} />
        <Route path="/council/review" component={CouncilReviewPage} />
        <Route path="/council/review/:id" component={CouncilReviewPage} />
        <Route path="/council/decisions" component={CouncilDecisionsPage} />
        <Route path="/council/decisions/:id" component={CouncilDecisionsPage} />
        <Route path="/council/audits" component={CouncilAuditsPage} />
        <Route component={NotFound} />
      </Switch>
    </AuthenticatedLayout>
  );
}

function AdminRoutes() {
  return (
    <AuthenticatedLayout>
      <Switch>
        <Route path="/" component={AdminDocumentsPage} />
        <Route path="/admin/documents" component={AdminDocumentsPage} />
        <Route path="/admin/questions" component={QuestionConfigPage} />
        <Route path="/admin/users" component={AdminUsersPage} />
        <Route path="/dashboard" component={DashboardPage} />
        <Route path="/use-case/:id/overview" component={UseCaseOverviewPage} />
        <Route path="/use-case/:id" component={UseCaseDetailPage} />
        <Route component={NotFound} />
      </Switch>
    </AuthenticatedLayout>
  );
}

function AppContent() {
  const { user, isLoading, isCouncil, isAdmin } = useAuth();
  const [match] = useRoute("/invite/:token");

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <Skeleton className="h-12 w-12 rounded-lg" />
          <Skeleton className="h-4 w-32" />
        </div>
      </div>
    );
  }

  // Handle the public invite route
  if (match) {
    return <InvitePage />;
  }

  if (!user) {
    return <DevLoginPage />;
  }

  if (isAdmin) {
    return <AdminRoutes />;
  }

  if (isCouncil) {
    return <CouncilRoutes />;
  }

  return <ProjectRoutes />;
}

function App() {
  useEffect(() => {
    try {
      app.initialize().then(() => {
        console.log("Teams SDK initialized successfully");
      }).catch((e) => {
        console.warn("Teams SDK not running in Teams context", e);
      });
    } catch (e) {
      console.warn("Error initializing Teams SDK", e);
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <AppContent />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;

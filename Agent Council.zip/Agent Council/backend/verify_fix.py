
import requests
import json

BASE_URL = "http://127.0.0.1:5000"

def test_registration():
    # 1. Login
    login_data = {"username": "carol_davis", "password": "cdpt_1"}
    session = requests.Session()
    response = session.post(f"{BASE_URL}/api/dev/login", json=login_data)
    if response.status_code != 200:
        print(f"Login failed: {response.text}")
        return
    print("Logged in successfully.")

    # 2. Create Use Case
    create_data = {
        "title": "Patient Navigation RAG Application",
        "whatTheAIDoes": "RAG application for patients to navigate the portal and apply forms."
    }
    response = session.post(f"{BASE_URL}/api/use-cases", json=create_data)
    if response.status_code != 200:
        print(f"Registration failed: {response.text}")
        return
    
    use_case = response.json()
    print("Use case registered successfully!")
    print(f"Use Case ID: {use_case['id']}")
    print(f"Current Step: {use_case.get('intakeStep')}")
    print(f"Progress: {use_case.get('intakeProgressPercentage')}%")

    # 3. Update with the new 12-question fields
    use_case_id = use_case['id']
    update_data = {
        "businessOwner": "Kasyap",
        "executiveSponsor": "Sarah Connor",
        "safetyRiskLikelihood": 1,
        "reliabilityLikelihood": 2
    }
    response = session.patch(f"{BASE_URL}/api/use-cases/{use_case_id}", json=update_data)
    if response.status_code == 200:
        updated = response.json()
        print("Updated with new fields successfully!")
        print(f"Calculated Risk Score: {updated.get('calculatedRiskScore')}")
        print(f"Risk Tier: {updated.get('calculatedRiskTier')}")
    else:
        print(f"Update failed: {response.text}")

if __name__ == "__main__":
    test_registration()

import os
import json
import uuid
import hashlib
import time
from datetime import datetime, timedelta
from typing import Optional
from functools import wraps
from fastapi import Request, HTTPException, Depends
from sqlalchemy.orm import Session
from database import get_db
from models import User, Session as SessionModel


SESSION_SECRET = os.environ.get("SESSION_SECRET", "dev-secret-key")
CACHE_TTL = 60  # seconds

# Simple in-memory TTL cache for session and user lookups
_session_cache: dict[str, tuple[float, Optional[dict]]] = {}
_user_cache: dict[str, tuple[float, Optional[User]]] = {}


def _cache_get(cache: dict, key: str):
    """Return cached value if not expired, else None."""
    entry = cache.get(key)
    if entry and (time.time() - entry[0]) < CACHE_TTL:
        return entry[1]
    cache.pop(key, None)
    return None


def _cache_set(cache: dict, key: str, value):
    cache[key] = (time.time(), value)


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, password_hash: str) -> bool:
    return hashlib.sha256(password.encode()).hexdigest() == password_hash

def create_session(db: Session, user_id: str) -> str:
    session_id = str(uuid.uuid4())
    expire = datetime.now() + timedelta(days=7)
    
    session = SessionModel(
        sid=session_id,
        sess={"userId": user_id},
        expire=expire
    )
    db.add(session)
    db.commit()
    # Pre-populate caches
    _cache_set(_session_cache, session_id, {"userId": user_id})
    return session_id

def get_session(db: Session, session_id: str) -> Optional[dict]:
    # Check cache first
    cached = _cache_get(_session_cache, session_id)
    if cached is not None:
        return cached

    session = db.query(SessionModel).filter(SessionModel.sid == session_id).first()
    if session and session.expire > datetime.now():
        _cache_set(_session_cache, session_id, session.sess)
        return session.sess
    return None

def delete_session(db: Session, session_id: str):
    _session_cache.pop(session_id, None)
    db.query(SessionModel).filter(SessionModel.sid == session_id).delete()
    db.commit()

async def get_current_user(request: Request, db: Session = Depends(get_db)) -> Optional[User]:
    session_id = request.cookies.get("session_id")
    if not session_id:
        return None
    
    session_data = get_session(db, session_id)
    if not session_data:
        return None
    
    user_id = session_data.get("userId")
    if not user_id:
        return None
    
    # Check user cache
    cached_user = _cache_get(_user_cache, user_id)
    if cached_user is not None:
        # Re-attach the cached instance to the current session to avoid
        # DetachedInstanceError when accessing lazy-loaded attributes.
        return db.merge(cached_user, load=False)

    user = db.query(User).filter(User.id == user_id).first()
    if user:
        _cache_set(_user_cache, user_id, user)
    return user

async def require_auth(request: Request, db: Session = Depends(get_db)) -> User:
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user

def require_role(allowed_roles: list):
    async def role_checker(request: Request, db: Session = Depends(get_db)) -> User:
        user = await require_auth(request, db)
        if user.role not in allowed_roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return role_checker

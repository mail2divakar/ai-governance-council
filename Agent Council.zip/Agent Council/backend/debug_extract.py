"""Debug script: test what the LLM returns for a sample description."""
import asyncio
import json
from database import SessionLocal
from models import QuestionConfig
from routers.use_cases import extract_fields_from_conversation

class FakeUseCase:
    id = "test-123"
    title = None
    dynamicAnswers = None

class FakeMsg:
    def __init__(self, role, content):
        self.role = role
        self.content = content

async def main():
    db = SessionLocal()
    uc = FakeUseCase()

    description = (
        "We are building an AI assistant that helps hospital staff identify patients "
        "at high risk of readmission within 30 days using EHR data and ML models. "
        "It targets care coordinators and uses patient records, vitals, and discharge notes. "
        "It suggests interventions but does not make automated decisions. Human review required."
    )

    msgs = [FakeMsg("user", description)]

    print("Running extraction...")
    result = await extract_fields_from_conversation(description, uc, msgs, db)

    print("\n=== EXTRACTED FIELDS ===")
    for k, v in result.items():
        print(f"  {k}: {v!r}")

    benefit_keys = [
        "revenueGenerationImpact", "revenueGenerationReasoning", "revenueGenerationKpi",
        "patientExperienceImpact", "patientExperienceReasoning",
        "employeeProductivityImpact", "employeeProductivityReasoning",
        "employeeSatisfactionImpact", "employeeSatisfactionReasoning",
    ]
    print("\n=== BENEFIT FIELDS PRESENT? ===")
    for k in benefit_keys:
        print(f"  {k}: {'YES -> ' + str(result.get(k)) if k in result else 'MISSING'}")

    db.close()

asyncio.run(main())

import os, sqlite3, psycopg2, json
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))
pg_url = os.environ.get('DATABASE_URL')
if not pg_url:
    print('No DATABASE_URL')
    exit(1)
if pg_url.startswith('postgres://'):
    pg_url = pg_url.replace('postgres://', 'postgresql://', 1)

sqlite_conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), 'governance.db'))
cursor = sqlite_conn.cursor()

try:
    pg_conn = psycopg2.connect(pg_url)
    pg_cursor = pg_conn.cursor()
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [r[0] for r in cursor.fetchall() if r[0] not in ('sqlite_sequence',)]
    
    # Pre-defined insertion order to respect foreign key constraints
    known_order = ['users', 'use_cases', 'messages', 'assessments', 'decisions', 
                   'policies', 'policy_items', 'opa_policy_versions', 
                   'council_threads', 'council_messages', 'audit_logs',
                   'council_chat_sessions', 'council_chat_messages', 
                   'question_configs', 'admin_documents', 'sessions']
    tables.sort(key=lambda x: known_order.index(x) if x in known_order else 999)
    
    for table in tables:
        cursor.execute(f"PRAGMA table_info({table})")
        columns = [col[1] for col in cursor.fetchall()]
        
        pg_cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table}'")
        pg_columns = set([col[0] for col in pg_cursor.fetchall()])
        if not pg_columns: continue
        
        valid_columns = [col for col in columns if col in pg_columns]
        
        cursor.execute(f"SELECT {','.join(valid_columns)} FROM {table}")
        rows = cursor.fetchall()
        if not rows: continue
        
        print(f"Migrating {len(rows)} rows into {table} (Cols: {len(valid_columns)})...")
        
        placeholders = ','.join(['%s'] * len(valid_columns))
        insert_query = f"INSERT INTO {table} ({','.join(valid_columns)}) VALUES ({placeholders})"
        
        for row in rows:
            processed_row = []
            for i, val in enumerate(row):
                if isinstance(val, str) and (val.startswith('{') or val.startswith('[')):
                    try:
                        js = json.loads(val)
                        processed_row.append(json.dumps(js))
                    except:
                        processed_row.append(val)
                else:
                    processed_row.append(val)
            try:
                pg_cursor.execute(insert_query, tuple(processed_row))
            except Exception as e:
                # Print error if it's not a duplicate key error
                if "duplicate key" not in str(e).lower():
                    print(f"Error inserting into {table}: {e}")
                pg_conn.rollback()
            else:
                pg_conn.commit()

    print("Pure Psycopg2 Migration Finished!")
        
except Exception as e:
    print("Database Connection/Execution Error:", e)
finally:
    if 'pg_conn' in locals():
        pg_conn.close()
    sqlite_conn.close()

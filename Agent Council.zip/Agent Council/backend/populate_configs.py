import os
from sqlalchemy.orm import Session
from database import SessionLocal
from models import QuestionConfig

def populate_configs():
    db = SessionLocal()
    questions = db.query(QuestionConfig).all()
    
    updated_count = 0
    
    for q in questions:
        # Default weight
        weight = 0.0
        
        # Populate risk weights
        if q.section == "RISK":
            if q.type in ["scale_1_5", "scale_1_3", "boolean"]:
                weight = 1.0 # default weight for scorable risk questions
                
        # Populate extraction prompts
        prompt = ""
        
        if q.id == "q1":
            prompt = f"Extract the name of the use case for '{q.label}'. Generate a concise, professional summary name if not explicitly provided."
        elif q.type == "scale_1_5":
            prompt = f"Extract the user's answer to: '{q.label}'. Infer a score from 1 to 5 based on the user's description and context if not explicitly provided."
        elif q.type == "scale_1_3":
            prompt = f"Extract the user's answer to: '{q.label}'. Infer a score from 1 to 3 based on the user's description and context if not explicitly provided."
        elif q.type == "boolean":
            prompt = f"Extract the user's answer to: '{q.label}'. Return 'yes' or 'no'. Infer based on context if not explicit."
        else:
            prompt = f"Extract the user's answer to: '{q.label}'. Infer based on context if not explicitly provided."
            
        q.weight = weight
        q.extractionPrompt = prompt
        updated_count += 1
        
    db.commit()
    print(f"Successfully populated extraction prompts and weights for {updated_count} questions.")
    db.close()

if __name__ == "__main__":
    populate_configs()

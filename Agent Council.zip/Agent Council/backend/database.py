"""Database configuration - SQLite for local development."""
import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

load_dotenv()

# Use SQLite for local development, can be overridden with DATABASE_URL env var
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./governance.db")

# Handle both SQLite and PostgreSQL
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

# SQLite needs special config
if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    engine = create_engine(
        DATABASE_URL,
        pool_size=10,          # Maintain 10 persistent connections
        max_overflow=20,       # Allow up to 20 extra under load
        pool_pre_ping=True,    # Validate connections before use
        pool_recycle=300,      # Recycle connections every 5 minutes
    )

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """Dependency for getting database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Initialize database tables."""
    from models import (
        User, UseCase, Message, Assessment, Decision,
        Policy, PolicyItem, OpaPolicyVersion,
        CouncilThread, CouncilMessage, AuditLog,
        CouncilChatSession, CouncilChatMessage, Session,
        QuestionConfig, AdminDocument
    )
    Base.metadata.create_all(bind=engine)
    run_migrations()


def run_migrations():
    """Add any new columns that don't yet exist in the database."""
    from sqlalchemy import inspect, text
    insp = inspect(engine)

    # Map of table -> list of (column_name, column_definition)
    migrations = {
        "use_cases": [
            ("dynamic_answers", "JSON"),
            ("revenue_generation_impact", "INTEGER"),
            ("revenue_generation_reasoning", "TEXT"),
            ("revenue_generation_kpi", "TEXT"),
            ("patient_experience_impact", "INTEGER"),
            ("patient_experience_reasoning", "TEXT"),
            ("patient_experience_kpi", "TEXT"),
            ("employee_productivity_impact", "INTEGER"),
            ("employee_productivity_reasoning", "TEXT"),
            ("employee_productivity_kpi", "TEXT"),
            ("employee_satisfaction_impact", "INTEGER"),
            ("employee_satisfaction_reasoning", "TEXT"),
            ("employee_satisfaction_kpi", "TEXT"),
            ("benefit_assessment_summary", "TEXT"),
        ],
        "users": [
            ("invite_token", "TEXT"),
            ("invite_expires_at", "DATETIME"),
        ]
    }

    for table, columns in migrations.items():
        try:
            existing_cols = {c["name"] for c in insp.get_columns(table)}
        except Exception:
            continue
        with engine.connect() as conn:
            for col_name, col_type in columns:
                if col_name not in existing_cols:
                    try:
                        conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}"))
                        conn.commit()
                        print(f"Migration: added {table}.{col_name}")
                    except Exception as e:
                        print(f"Migration warning for {table}.{col_name}: {e}")


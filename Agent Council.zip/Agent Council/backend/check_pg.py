import os
import psycopg2
from dotenv import load_dotenv

# Load env from backend/.env
load_dotenv(r'c:\Users\KasyapRangacharyulu\Downloads\AG_AC\backend\.env')

db_url = os.environ.get("DATABASE_URL")
print(f"Connecting to: {db_url}")

try:
    conn = psycopg2.connect(db_url)
    cursor = conn.cursor()

    print("\n--- Users in Postgres ---")
    cursor.execute("SELECT id, username, first_name, last_name, email, role FROM users WHERE first_name ILIKE '%Carol%' OR last_name ILIKE '%Davis%';")
    users = cursor.fetchall()
    for user in users:
        print(user)

    if users:
        for user in users:
            user_id = user[0]
            print(f"\n--- Use Cases for User ID {user_id} ({user[1]}) ---")
            cursor.execute("SELECT id, title, status, user_id FROM use_cases WHERE user_id = %s;", (user_id,))
            use_cases = cursor.fetchall()
            for uc in use_cases:
                print(uc)
    else:
        print("\nCarol Davis not found in users table.")

    conn.close()
except Exception as e:
    print(f"Error connecting to Postgres: {e}")

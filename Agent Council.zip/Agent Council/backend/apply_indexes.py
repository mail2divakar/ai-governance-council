from sqlalchemy import text, create_engine
import os

# Use the same database URL as in database.py
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./governance.db")
engine = create_engine(DATABASE_URL)

def apply_indexes():
    indexes = [
        ("ix_use_cases_user_id", "use_cases", "user_id"),
        ("ix_messages_use_case_id", "messages", "use_case_id"),
        ("ix_assessments_use_case_id", "assessments", "use_case_id"),
        ("ix_decisions_use_case_id", "decisions", "use_case_id"),
        ("ix_council_threads_use_case_id", "council_threads", "use_case_id"),
        ("ix_audit_logs_use_case_id", "audit_logs", "use_case_id"),
    ]

    with engine.connect() as conn:
        for index_name, table_name, column_name in indexes:
            try:
                # SQLite syntax for creating indexes
                conn.execute(text(f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name} ({column_name})"))
                print(f"Index applied: {index_name} on {table_name}({column_name})")
            except Exception as e:
                print(f"Error applying index {index_name}: {e}")
        conn.commit()

if __name__ == "__main__":
    apply_indexes()

"""Export QuestionConfig and related tables to Excel with styled formatting."""
import sys
import os

# Add backend dir to path so we can import models
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database import SessionLocal
from models import QuestionConfig
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

OUTPUT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "QuestionConfig_Export.xlsx")

# ---------- Colours ----------
HEADER_BG   = "1E3A5F"   # dark navy
HEADER_FONT = "FFFFFF"   # white
SECTION_COLORS = {
    "BASIC":      "E3F2FD",
    "RISK":       "FFEBEE",
    "BENEFIT":    "E8F5E9",
    "MITIGATION": "FFF8E1",
    "TECHNICAL":  "F3E5F5",
}
BORDER_COLOR = "BDBDBD"

def make_border():
    side = Side(border_style="thin", color=BORDER_COLOR)
    return Border(left=side, right=side, top=side, bottom=side)

def style_header(cell, text):
    cell.value = text
    cell.font = Font(bold=True, color=HEADER_FONT, size=11)
    cell.fill = PatternFill("solid", fgColor=HEADER_BG)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = make_border()

def style_cell(cell, value, section=None, wrap=False):
    cell.value = value
    cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=wrap)
    cell.border = make_border()
    if section and section in SECTION_COLORS:
        cell.fill = PatternFill("solid", fgColor=SECTION_COLORS[section])

def autofit(ws, min_width=12, max_width=60):
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        max_len = max((len(str(c.value or "")) for c in col), default=0)
        ws.column_dimensions[col_letter].width = min(max(max_len + 2, min_width), max_width)


def build_question_config_sheet(wb, db):
    ws = wb.create_sheet("Question Config")
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 30

    headers = ["ID (Field Name)", "Section", "Label", "Type", "Extraction Prompt (LLM Instruction)", "Weight (Risk Score)", "Active"]
    for col_idx, h in enumerate(headers, 1):
        style_header(ws.cell(row=1, column=col_idx), h)

    configs = db.query(QuestionConfig).order_by(
        QuestionConfig.section, QuestionConfig.id
    ).all()

    for row_idx, c in enumerate(configs, 2):
        section = c.section or ""
        data = [c.id, section, c.label, c.type, c.extractionPrompt or "", c.weight or 0, "Yes" if c.isActive else "No"]
        for col_idx, val in enumerate(data, 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            style_cell(cell, val, section=section, wrap=(col_idx == 5))

    autofit(ws)
    # Wider column for the extraction prompt
    ws.column_dimensions["E"].width = 65
    ws.column_dimensions["C"].width = 35


def build_risk_scoring_sheet(wb, db):
    """Summary sheet showing only RISK questions with weights and how the score is calculated."""
    ws = wb.create_sheet("Risk Scoring Model")
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 30

    headers = ["Field Name", "Label", "Weight (%)", "Scale", "Extraction Prompt", "Notes"]
    for col_idx, h in enumerate(headers, 1):
        style_header(ws.cell(row=1, column=col_idx), h)

    risk_configs = db.query(QuestionConfig).filter(
        QuestionConfig.section == "RISK", QuestionConfig.isActive == 1
    ).all()

    total_weight = sum(c.weight or 0 for c in risk_configs)
    for row_idx, c in enumerate(risk_configs, 2):
        data = [
            c.id,
            c.label,
            c.weight or 0,
            "1–5",
            c.extractionPrompt or "",
            f"{round((c.weight or 0) / total_weight * 100, 1)}% of total score" if total_weight else ""
        ]
        for col_idx, val in enumerate(data, 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            style_cell(cell, val, section="RISK", wrap=(col_idx == 5))

    # Totals row
    last_row = len(risk_configs) + 2
    ws.cell(row=last_row, column=1).value = "TOTAL"
    ws.cell(row=last_row, column=1).font = Font(bold=True)
    ws.cell(row=last_row, column=3).value = total_weight
    ws.cell(row=last_row, column=3).font = Font(bold=True)
    ws.cell(row=last_row, column=6).value = "Score = weighted avg × 20  →  0–100 scale"
    ws.cell(row=last_row, column=6).font = Font(italic=True)

    autofit(ws)
    ws.column_dimensions["E"].width = 60


def build_benefit_scoring_sheet(wb, db):
    """Summary sheet for BENEFIT questions."""
    ws = wb.create_sheet("Benefit Assessment Model")
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 30

    headers = ["Field Name", "Label", "Scale", "Extraction Prompt", "KPI Field"]
    for col_idx, h in enumerate(headers, 1):
        style_header(ws.cell(row=1, column=col_idx), h)

    benefit_configs = db.query(QuestionConfig).filter(
        QuestionConfig.section == "BENEFIT", QuestionConfig.isActive == 1
    ).all()

    for row_idx, c in enumerate(benefit_configs, 2):
        kpi_field = c.id.replace("Impact", "Kpi") if "Impact" in c.id else ""
        data = [c.id, c.label, "1–3", c.extractionPrompt or "", kpi_field]
        for col_idx, val in enumerate(data, 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            style_cell(cell, val, section="BENEFIT", wrap=(col_idx == 4))

    autofit(ws)
    ws.column_dimensions["D"].width = 60


def build_legend_sheet(wb):
    ws = wb.create_sheet("Legend & Guide", 0)  # First sheet
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 70

    title = ws.cell(row=1, column=1, value="Question Config — Reference Guide")
    title.font = Font(bold=True, size=14, color=HEADER_BG)
    ws.merge_cells("A1:B1")

    ws.cell(row=2, column=1, value=f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    ws.cell(row=2, column=1).font = Font(italic=True, color="888888")
    ws.merge_cells("A2:B2")

    rows = [
        ("", ""),
        ("SECTIONS", ""),
        ("BASIC", "Core use case info: title, owner, description, target audience"),
        ("RISK", "Risk likelihood questions scored 1–5 (Safety, Security, Bias, Reliability, Privacy)"),
        ("BENEFIT", "Business value questions scored 1–3 (Revenue, Patient Exp, Productivity, Satisfaction)"),
        ("MITIGATION", "How identified risks will be mitigated"),
        ("TECHNICAL", "AI techniques used and monitoring metrics"),
        ("", ""),
        ("RISK SCORING FORMULA", ""),
        ("Formula", "Risk Score = Σ(score_i × weight_i) / Σ(weight_i) × 20"),
        ("Scale", "0–100, where 100 = highest possible risk"),
        ("Tiers", "LOW < 30 | MEDIUM 30–60 | HIGH 60–80 | CRITICAL ≥ 80"),
        ("", ""),
        ("BENEFIT SCORING", ""),
        ("Scale", "1 = Low impact, 2 = Moderate impact, 3 = High impact"),
        ("AI Inference", "Scores are auto-inferred by the LLM from the project description"),
        ("", ""),
        ("EDITING CONFIG", ""),
        ("To change weights", "Update the 'weight' column in Question Config sheet, then run seed.py or update DB directly"),
        ("To change prompts", "Update 'Extraction Prompt' — this is the instruction sent to GPT-4o to extract that field"),
        ("To disable a question", "Set Active = No to exclude from intake and scoring"),
    ]

    section_rows = {"SECTIONS", "RISK SCORING FORMULA", "BENEFIT SCORING", "EDITING CONFIG"}
    for i, (key, val) in enumerate(rows, 3):
        k_cell = ws.cell(row=i, column=1, value=key)
        v_cell = ws.cell(row=i, column=2, value=val)
        if key in section_rows:
            k_cell.font = Font(bold=True, color=HEADER_FONT)
            k_cell.fill = PatternFill("solid", fgColor=HEADER_BG)
            ws.merge_cells(f"A{i}:B{i}")
        elif key:
            k_cell.font = Font(bold=True)
        v_cell.alignment = Alignment(wrap_text=True)
        ws.row_dimensions[i].height = 18


db = SessionLocal()
wb = openpyxl.Workbook()
wb.remove(wb.active)  # Remove default sheet

build_legend_sheet(wb)
build_question_config_sheet(wb, db)
build_risk_scoring_sheet(wb, db)
build_benefit_scoring_sheet(wb, db)

db.close()

output = os.path.abspath(OUTPUT_PATH)
wb.save(output)
print(f"Saved: {output}")

import os
from sqlalchemy.orm import Session
from database import SessionLocal
from models import QuestionConfig
import docx

def get_section(q_num_int):
    if q_num_int <= 8:
        return "BASIC"
    elif q_num_int <= 45:
        return "RISK"
    elif q_num_int <= 58:
        return "BENEFIT"
    else:
        return "TECHNICAL"

def get_type(response_type_str):
    response_type_str = response_type_str.lower()
    if "radio" in response_type_str or "boolean" in response_type_str:
        if "yes" in response_type_str or "no" in response_type_str:
            return "boolean"
        return "scale_1_5" # mostly radio buttons are 1-5 scales
    if "string" in response_type_str or "text" in response_type_str:
        return "text"
    return "text"

def seed_from_docx():
    db = SessionLocal()
    docx_path = os.path.join(os.path.dirname(__file__), "AI_new_idea_submission_questionnaire_data.docx")
    try:
        doc = docx.Document(docx_path)
    except Exception as e:
        print(f"Error loading docx: {e}")
        return
    
    # Clear existing questions
    db.query(QuestionConfig).delete()
    db.commit()
    
    questions = []
    
    for table in doc.tables:
        for row in table.rows:
            raw_row_data = [cell.text.strip(' \n\r\t') for cell in row.cells]
            
            # Skip the header
            if not raw_row_data or raw_row_data[0] == "S.No.":
                continue
                
            q_num = raw_row_data[0]
            if q_num.isdigit():
                q_num_int = int(q_num)
                q_detail = raw_row_data[1] if len(raw_row_data) > 1 else ""
                q_type_str = raw_row_data[2] if len(raw_row_data) > 2 else ""
                
                # special handlers
                label = q_detail
                q_type = get_type(q_type_str)
                
                # Some manual overrides for types based on the docx
                if q_num_int == 7:
                    q_type = "boolean"
                elif q_num_int in [9, 11, 13, 15, 17, 19, 21, 23, 26, 29, 32, 35, 38, 41]:
                    q_type = "scale_1_5"
                elif q_num_int in [46, 49, 52, 55]:
                    q_type = "scale_1_3" # Benefit impacts use 1-3 scale
                elif "Radio buttons" in q_type_str and "Yes" in raw_row_data[3]:
                    q_type = "boolean"
                
                qc = QuestionConfig(
                    id=f"q{q_num}",
                    section=get_section(q_num_int),
                    label=label,
                    type=q_type,
                    isActive=1,
                    weight=0.0
                )
                db.add(qc)
                questions.append(qc)

    db.commit()
    print(f"Successfully seeded {len(questions)} questions from DOCX.")
    db.close()

if __name__ == "__main__":
    seed_from_docx()


import os
import sys
import asyncio
from dotenv import load_dotenv

# Add current directory to path so we can import from main
sys.path.append(os.getcwd())

load_dotenv()

# Mocking imports or importing ensuring we have env vars
try:
    from main import generate_agent_response, extract_fields_from_conversation
    from models import UseCase, Message
    from datetime import datetime
except ImportError as e:
    print(f"Import Error: {e}")
    sys.exit(1)

async def test_flow():
    print("--- Starting Debug Flow ---")

    # 1. Mock Data
    mock_use_case = UseCase(
        id="debug-id",
        title="Test Project",
        safetyRiskLikelihood=3, # Current value
        role="PROJECT"
    )
    
    # Mock message history
    messages = [
        Message(role="system", content="System prompt..."),
        Message(role="user", content="Safety Risk Likelihood changed to 3. Please provide risk recommendations.")
    ]
    
    user_input = "Safety Risk Likelihood changed to 3. Please provide risk recommendations."

    # 2. Test Generation
    print("\n[1] Testing Agent Generation...")
    # We need to simulate the status_result dict that generate_agent_response expects
    status_result = {
        "threadStatus": "info_required",
        "progress": 50,
        "currentQuestion": "q5",
        "intakeStep": "RISK",
        "answered": []
    }
    
    try:
        agent_response = await generate_agent_response(user_input, mock_use_case, messages, status_result)
        print(f"Agent Response:\n{agent_response}\n")
    except Exception as e:
        print(f"Generation failed: {e}")
        return

    # 3. Test Extraction
    print("[2] Testing Extraction from Agent Response...")
    
    # We pretend the agent response is the input to extraction (as we implemented in main.py)
    # Note: extraction function signature: extract_fields_from_conversation(content: str, use_case: UseCase, messages: List[Message])
    
    # The logic in main.py passes the agent_response as 'content'
    try:
        extracted = await extract_fields_from_conversation(agent_response, mock_use_case, messages)
        print(f"Extracted Fields:\n{extracted}\n")
        
        if extracted.get("safetyRiskReasoning"):
            print("SUCCESS: safetyRiskReasoning found!")
        else:
            print("FAILURE: safetyRiskReasoning NOT found.")
            
    except Exception as e:
        print(f"Extraction failed: {e}")

if __name__ == "__main__":
    asyncio.run(test_flow())

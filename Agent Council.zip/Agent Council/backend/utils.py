from datetime import datetime
from models import UseCase

def format_datetime(dt):
    if dt is None:
        return None
    if isinstance(dt, datetime):
        return dt.isoformat()
    if isinstance(dt, str):
        # Normalize SQLite-style space to ISO 'T'
        return dt.replace(' ', 'T')
    return str(dt)

def serialize_use_case(uc: UseCase):
    """Convert SQLAlchemy UseCase to dict for JSON response"""
    if uc is None:
        return None
    return {
        "id": uc.id,
        "userId": uc.userId,
        "creatorName": getattr(uc, "creatorName", None),
        "title": uc.title,
        "whatTheAIDoes": uc.whatTheAIDoes,
        "whoUsesIt": uc.whoUsesIt,
        "userPopulation": uc.userPopulation,
        "decisionsOrActions": uc.decisionsOrActions,
        "dataItMightTouch": uc.dataItMightTouch,
        "dataClassification": uc.dataClassification,
        "hasPersonalData": uc.hasPersonalData,
        "hasSensitiveData": uc.hasSensitiveData,
        "thirdPartyTools": uc.thirdPartyTools,
        "governanceDomains": uc.governanceDomains,
        "threadStatus": uc.threadStatus,
        "missingInfo": uc.missingInfo,
        "missingData": uc.missingData,
        "hasArchitectureDiagram": uc.hasArchitectureDiagram,
        "hasDataFlowDoc": uc.hasDataFlowDoc,
        "hasEvaluationResults": uc.hasEvaluationResults,
        "hasMonitoringPlan": uc.hasMonitoringPlan,
        "humanInTheLoop": uc.humanInTheLoop,
        "deploymentType": uc.deploymentType,
        "decisionImpact": uc.decisionImpact,
        "stage": uc.stage,
        "riskScore": uc.riskScore,
        "riskLevel": uc.riskLevel,
        "riskDrivers": uc.riskDrivers,
        "embedding": uc.embedding,
        "similarUseCaseIds": uc.similarUseCaseIds,
        "status": uc.status,
        "currentStep": uc.currentStep,
        "totalSteps": uc.totalSteps,
        "createdAt": format_datetime(uc.createdAt),
        "updatedAt": format_datetime(uc.updatedAt),
        
        # New 12-question fields
        "businessOwner": uc.businessOwner,
        "executiveSponsor": uc.executiveSponsor,
        "projectDescription": uc.projectDescription,
        "targetAudiences": uc.targetAudiences,
        "inputDataSources": uc.inputDataSources,
        "isAIResearch": uc.isAIResearch,
        "patientConsentDisclosure": uc.patientConsentDisclosure,
        "safetyRiskLikelihood": uc.safetyRiskLikelihood,
        "safetyRiskReasoning": uc.safetyRiskReasoning,
        "securityRiskLikelihood": uc.securityRiskLikelihood,
        "securityRiskReasoning": uc.securityRiskReasoning,
        "biasFairnessLikelihood": uc.biasFairnessLikelihood,
        "biasFairnessReasoning": uc.biasFairnessReasoning,
        "reliabilityLikelihood": uc.reliabilityLikelihood,
        "reliabilityReasoning": uc.reliabilityReasoning,
        "privacyLikelihood": uc.privacyLikelihood,
        "privacyReasoning": uc.privacyReasoning,
        "riskMitigationStrategy": uc.riskMitigationStrategy,
        "aiTechniquesUsed": uc.aiTechniquesUsed,
        "monitoringMetrics": uc.monitoringMetrics,
        "calculatedRiskScore": uc.calculatedRiskScore,
        "calculatedRiskTier": uc.calculatedRiskTier,
        "intakeStep": uc.intakeStep,
        "questionsAnswered": uc.questionsAnswered,
        "currentQuestion": uc.currentQuestion,
        "intakeProgressPercentage": uc.intakeProgressPercentage,
        "recommendation": uc.recommendation,
        "requiredReviewers": uc.requiredReviewers,
        "conditions": uc.conditions,
        "approvalStatus": uc.approvalStatus,
        "decisionNotes": uc.decisionNotes,

        # Benefit Assessment
        "revenueGenerationImpact": uc.revenueGenerationImpact,
        "revenueGenerationReasoning": uc.revenueGenerationReasoning,
        "revenueGenerationKpi": uc.revenueGenerationKpi,
        "patientExperienceImpact": uc.patientExperienceImpact,
        "patientExperienceReasoning": uc.patientExperienceReasoning,
        "patientExperienceKpi": uc.patientExperienceKpi,
        "employeeProductivityImpact": uc.employeeProductivityImpact,
        "employeeProductivityReasoning": uc.employeeProductivityReasoning,
        "employeeProductivityKpi": uc.employeeProductivityKpi,
        "employeeSatisfactionImpact": uc.employeeSatisfactionImpact,
        "employeeSatisfactionReasoning": uc.employeeSatisfactionReasoning,
        "employeeSatisfactionKpi": uc.employeeSatisfactionKpi,
        "benefitAssessmentSummary": uc.benefitAssessmentSummary,
        "dynamicAnswers": uc.dynamicAnswers,
    }

import os
import sys

from routers.export import get_user_answer
from models import UseCase

# Mock UseCase object
class MockUseCase:
    def __init__(self):
        self.title = "Test AI Project"
        self.businessOwner = "John Doe"
        self.executiveSponsor = "Jane Smith"
        self.projectDescription = "A test project"
        self.targetAudiences = "Everyone"
        self.inputDataSources = "Database"
        self.isAIResearch = "No"
        self.patientConsentDisclosure = ""
        self.safetyRiskLikelihood = 2
        self.safetyRiskReasoning = "Low risk"
        self.securityRiskLikelihood = 3
        self.securityRiskReasoning = "Moderate risk"
        self.biasFairnessLikelihood = 1
        self.biasFairnessReasoning = "No bias"
        self.reliabilityLikelihood = 4
        self.reliabilityReasoning = "High reliability"
        self.privacyLikelihood = 2
        self.privacyReasoning = "Low privacy risk"
        self.riskMitigationStrategy = "Firewalls"
        self.aiTechniquesUsed = "LLM"
        self.monitoringMetrics = "Accuracy"
        self.dynamicAnswers = {"q13": "Yes transparency", "q28": "Random dynamic answer"}
        
use_case = MockUseCase()

import docx
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment

docx_path = "AI_new_idea_submission_questionnaire_data.docx"
doc = docx.Document(docx_path)

wb = Workbook()
ws = wb.active
ws.title = "AI Use Case Intake"

headers = [
    "S.No.", 
    "Question detail", 
    "Question Response Type", 
    "Option values (if applicable)", 
    "Notes in quesiton if applicable", 
    "User Answer"
]

ws.append(headers)

for table in doc.tables:
    for row in table.rows:
        row_data = [cell.text.strip(' \n\r\t') for cell in row.cells]
        
        # Skip the header row from docx itself
        if not row_data or row_data[0] == "S.No.":
            continue
            
        # Normalize to 5 columns
        while len(row_data) < 5:
            row_data.append("")
        row_data = row_data[:5]
        
        # Determine user answer
        q_num = row_data[0]
        answer = ""
        if q_num and q_num.isdigit():
            answer = get_user_answer(q_num, use_case)
            
        row_data.append(answer)
        ws.append(row_data)

wb.save("test_export.xlsx")
print("Saved test_export.xlsx successfully")

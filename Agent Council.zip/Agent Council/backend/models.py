"""SQLAlchemy models for the governance application - SQLite compatible."""
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, Integer, DateTime, JSON, Float
from database import Base


def generate_uuid():
    return str(uuid.uuid4())


class Session(Base):
    __tablename__ = "sessions"
    
    sid = Column(String, primary_key=True)
    sess = Column(JSON, nullable=False)
    expire = Column(DateTime, nullable=False)


class User(Base):
    __tablename__ = "users"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    email = Column(String, unique=True)
    firstName = Column("first_name", String)
    lastName = Column("last_name", String)
    profileImageUrl = Column("profile_image_url", String)
    role = Column(String, default="PROJECT")
    username = Column(String)
    passwordHash = Column("password_hash", String)
    
    # Email Registration Invite Links
    inviteToken = Column("invite_token", String)
    inviteExpiresAt = Column("invite_expires_at", DateTime)
    
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)
    updatedAt = Column("updated_at", DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class UseCase(Base):
    __tablename__ = "use_cases"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    userId = Column("user_id", String, nullable=False, index=True)
    title = Column(Text, nullable=False)
    whatTheAIDoes = Column("what_the_ai_does", Text)
    whoUsesIt = Column("who_uses_it", Text)
    userPopulation = Column("user_population", Text)
    decisionsOrActions = Column("decisions_or_actions", Text)
    dataItMightTouch = Column("data_it_might_touch", Text)
    dataClassification = Column("data_classification", Text)
    hasPersonalData = Column("has_personal_data", Text)
    hasSensitiveData = Column("has_sensitive_data", Text)
    thirdPartyTools = Column("third_party_tools", Text)
    governanceDomains = Column("governance_domains", JSON)  # SQLite uses JSON instead of ARRAY
    threadStatus = Column("thread_status", Text, default="info_required")
    missingInfo = Column("missing_info", JSON)  # SQLite uses JSON instead of ARRAY
    missingData = Column("missing_data", JSON)  # SQLite uses JSON instead of ARRAY
    hasArchitectureDiagram = Column("has_architecture_diagram", Text, default="false")
    hasDataFlowDoc = Column("has_data_flow_doc", Text, default="false")
    hasEvaluationResults = Column("has_evaluation_results", Text, default="false")
    hasMonitoringPlan = Column("has_monitoring_plan", Text, default="false")
    humanInTheLoop = Column("human_in_the_loop", Text)
    deploymentType = Column("deployment_type", Text)
    decisionImpact = Column("decision_impact", Text)
    stage = Column(Text, default="BASIC_INFO")
    riskScore = Column("risk_score", Text, default="0")
    riskLevel = Column("risk_level", Text, default="LOW")
    riskDrivers = Column("risk_drivers", JSON)  # SQLite uses JSON instead of ARRAY
    embedding = Column(JSON)
    similarUseCaseIds = Column("similar_use_case_ids", JSON)  # SQLite uses JSON instead of ARRAY
    status = Column(Text, default="PENDING")
    currentStep = Column("current_step", Text, default="1")
    totalSteps = Column("total_steps", Text, default="4")
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)
    updatedAt = Column("updated_at", DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # === 12-QUESTION FRAMEWORK FIELDS ===
    businessOwner = Column("business_owner", Text)
    executiveSponsor = Column("executive_sponsor", Text)
    projectDescription = Column("project_description", Text)
    targetAudiences = Column("target_audiences", Text)
    inputDataSources = Column("input_data_sources", Text)
    isAIResearch = Column("is_ai_research", Text)
    patientConsentDisclosure = Column("patient_consent_disclosure", Text)
    
    safetyRiskLikelihood = Column("safety_risk_likelihood", Integer)
    safetyRiskReasoning = Column("safety_risk_reasoning", Text)
    securityRiskLikelihood = Column("security_risk_likelihood", Integer)
    securityRiskReasoning = Column("security_risk_reasoning", Text)
    biasFairnessLikelihood = Column("bias_fairness_likelihood", Integer)
    biasFairnessReasoning = Column("bias_fairness_reasoning", Text)
    reliabilityLikelihood = Column("reliability_likelihood", Integer)
    reliabilityReasoning = Column("reliability_reasoning", Text)
    privacyLikelihood = Column("privacy_likelihood", Integer)
    privacyReasoning = Column("privacy_reasoning", Text)
    
    riskMitigationStrategy = Column("risk_mitigation_strategy", Text)
    aiTechniquesUsed = Column("ai_techniques_used", Text)
    monitoringMetrics = Column("monitoring_metrics", Text)
    
    # === BENEFIT ASSESSMENT FIELDS ===
    revenueGenerationImpact = Column("revenue_generation_impact", Integer)
    revenueGenerationReasoning = Column("revenue_generation_reasoning", Text)
    revenueGenerationKpi = Column("revenue_generation_kpi", Text)
    
    patientExperienceImpact = Column("patient_experience_impact", Integer)
    patientExperienceReasoning = Column("patient_experience_reasoning", Text)
    patientExperienceKpi = Column("patient_experience_kpi", Text)
    
    employeeProductivityImpact = Column("employee_productivity_impact", Integer)
    employeeProductivityReasoning = Column("employee_productivity_reasoning", Text)
    employeeProductivityKpi = Column("employee_productivity_kpi", Text)
    
    employeeSatisfactionImpact = Column("employee_satisfaction_impact", Integer)
    employeeSatisfactionReasoning = Column("employee_satisfaction_reasoning", Text)
    employeeSatisfactionKpi = Column("employee_satisfaction_kpi", Text)
    
    benefitAssessmentSummary = Column("benefit_assessment_summary", Text)
    
    calculatedRiskScore = Column("calculated_risk_score", Float, default=0.0)
    calculatedRiskTier = Column("calculated_risk_tier", Text)
    
    intakeStep = Column("intake_step", Text, default="BASIC")
    questionsAnswered = Column("questions_answered", JSON, default=list)
    currentQuestion = Column("current_question", Text, default="q1")
    intakeProgressPercentage = Column("intake_progress_percentage", Float, default=0.0)
    
    recommendation = Column("recommendation", Text)
    requiredReviewers = Column("required_reviewers", JSON, default=list)
    conditions = Column("conditions", JSON, default=list)
    approvalStatus = Column("approval_status", Text)
    decisionNotes = Column("decision_notes", Text)
    
    # Store dynamic answers outside of hardcoded columns
    dynamicAnswers = Column("dynamic_answers", JSON, default=dict)


class QuestionConfig(Base):
    __tablename__ = "question_configs"
    
    id = Column(String, primary_key=True)  # e.g., "safetyRiskLikelihood"
    section = Column(String, nullable=False)  # e.g., "RISK", "BENEFIT", "BASIC", "TECHNICAL", "MITIGATION"
    label = Column(Text, nullable=False)  # User facing text
    type = Column(String, nullable=False)  # "text", "scale_1_5", "scale_1_3"
    extractionPrompt = Column("extraction_prompt", Text)  # Instructions for LLM
    weight = Column(Float, default=0.0)  # Scoring weight
    isActive = Column("is_active", Integer, default=1)  # 1 for True, 0 for False (SQLite boolean)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)
    updatedAt = Column("updated_at", DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Message(Base):
    __tablename__ = "messages"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    useCaseId = Column("use_case_id", String, nullable=False, index=True)
    role = Column(Text, nullable=False)
    content = Column(Text, nullable=False)
    message_metadata = Column("metadata", JSON)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)


class Assessment(Base):
    __tablename__ = "assessments"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    useCaseId = Column("use_case_id", String, nullable=False, index=True)
    domains = Column(JSON)  # SQLite uses JSON instead of ARRAY
    risks = Column(JSON)  # SQLite uses JSON instead of ARRAY
    gaps = Column(JSON)  # SQLite uses JSON instead of ARRAY
    recommendations = Column(JSON)  # SQLite uses JSON instead of ARRAY
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)


class Decision(Base):
    __tablename__ = "decisions"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    useCaseId = Column("use_case_id", String, nullable=False, index=True)
    status = Column(Text, nullable=False)
    rationale = Column(JSON)  # SQLite uses JSON instead of ARRAY
    decidedBy = Column("decided_by", String, nullable=False)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)


class Policy(Base):
    __tablename__ = "policies"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    category = Column(Text, nullable=False)
    fullName = Column("full_name", Text, nullable=False)
    version = Column(Integer, nullable=False, default=1)
    status = Column(Text, nullable=False, default="DRAFT")
    updatedBy = Column("updated_by", String, nullable=False)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)
    updatedAt = Column("updated_at", DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class PolicyItem(Base):
    __tablename__ = "policy_items"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    policyId = Column("policy_id", String, nullable=False)
    itemIndex = Column("item_index", Integer, nullable=False)
    title = Column(Text, nullable=False)
    statement = Column(Text, nullable=False)
    controls = Column(JSON)  # SQLite uses JSON instead of ARRAY
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)
    updatedAt = Column("updated_at", DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class OpaPolicyVersion(Base):
    __tablename__ = "opa_policy_versions"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    category = Column(Text, nullable=False)
    version = Column(Integer, nullable=False, default=1)
    bundle = Column(JSON, nullable=False)
    updatedBy = Column("updated_by", String, nullable=False)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)


class CouncilThread(Base):
    __tablename__ = "council_threads"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    useCaseId = Column("use_case_id", String, nullable=False, index=True)
    councilUserId = Column("council_user_id", String, nullable=False)
    status = Column(Text, nullable=False, default="OPEN")
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)
    updatedAt = Column("updated_at", DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class CouncilMessage(Base):
    __tablename__ = "council_messages"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    councilThreadId = Column("council_thread_id", String, nullable=False)
    role = Column(Text, nullable=False)
    content = Column(Text, nullable=False)
    message_metadata = Column("metadata", JSON)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    useCaseId = Column("use_case_id", String, index=True)
    action = Column(Text, nullable=False)
    actorUserId = Column("actor_user_id", String, nullable=False)
    details = Column(JSON)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)


class CouncilChatSession(Base):
    __tablename__ = "council_chat_sessions"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    userId = Column("user_id", String, nullable=False)
    title = Column(Text, nullable=False, default="New Chat")
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)
    updatedAt = Column("updated_at", DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class CouncilChatMessage(Base):
    __tablename__ = "council_chat_messages"
    
    id = Column(String, primary_key=True, default=generate_uuid)
    sessionId = Column("session_id", String, nullable=False)
    role = Column(Text, nullable=False)
    content = Column(Text, nullable=False)
    message_metadata = Column("metadata", JSON)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)


class AdminDocument(Base):
    __tablename__ = "admin_documents"

    id = Column(String, primary_key=True, default=generate_uuid)
    filename = Column(String, nullable=False)
    category = Column(String, nullable=False)  # "BRD" or "ORG_DATA"
    uploadedAt = Column("uploaded_at", DateTime, default=datetime.utcnow)

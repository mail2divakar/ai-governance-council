import requests
import time
import json

BASE_URL = "http://127.0.0.1:5000"

def test_performance():
    login_data = {"username": "carol_davis", "password": "cdpt_1"}
    session = requests.Session()
    
    print("Logging in...")
    start_time = time.time()
    response = session.post(f"{BASE_URL}/api/dev/login", json=login_data)
    login_time = time.time() - start_time
    
    if response.status_code != 200:
        print(f"Login failed: {response.text}")
        return
    print(f"Logged in successfully in {login_time:.4f}s")

    print("\nTesting /api/use-cases performance...")
    times = []
    for i in range(5):
        start_time = time.time()
        response = session.get(f"{BASE_URL}/api/use-cases")
        end_time = time.time()
        if response.status_code == 200:
            duration = end_time - start_time
            times.append(duration)
            print(f"Request {i+1}: {duration:.4f}s (Count: {len(response.json())})")
        else:
            print(f"Request {i+1} failed: {response.status_code}")
    
    if times:
        avg_time = sum(times) / len(times)
        print(f"\nAverage time for /api/use-cases: {avg_time:.4f}s")

if __name__ == "__main__":
    try:
        test_performance()
    except requests.exceptions.ConnectionError:
        print("Error: Could not connect to the backend server. Make sure it's running on http://127.0.0.1:5000")

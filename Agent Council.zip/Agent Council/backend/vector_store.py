import os
import uuid
import chromadb
from chromadb.config import Settings
import fitz  # PyMuPDF
from langchain_text_splitters import RecursiveCharacterTextSplitter

# Initialize local ChromaDB persistent client pointing to a folder in the backend directory
CHROMA_DB_DIR = os.path.join(os.path.dirname(__file__), "chroma_db")
os.makedirs(CHROMA_DB_DIR, exist_ok=True)

chroma_client = chromadb.PersistentClient(path=CHROMA_DB_DIR)

# We will store everything in a single collection with metadata filtering
COLLECTION_NAME = "admin_documents"
collection = chroma_client.get_or_create_collection(
    name=COLLECTION_NAME,
    metadata={"hnsw:space": "cosine"}
)

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    length_function=len,
    is_separator_regex=False,
)

def extract_text_from_pdf(filepath: str) -> str:
    """Extract all text from a PDF file using PyMuPDF."""
    doc = fitz.open(filepath)
    text = ""
    for page in doc:
        text += page.get_text() + "\n\n"
    doc.close()
    return text

def chunk_text(text: str) -> list[str]:
    """Split text into overlapping chunks using LangChain."""
    return text_splitter.split_text(text)

def store_document_chunks_in_chroma(doc_id: str, filename: str, category: str, chunks: list[str], embeddings_client):
    """
    Get embeddings via OpenAI client and store them in ChromaDB 
    along with metadata linking them back to the SQLite AdminDocument ID.
    """
    if not chunks:
        print("Warning: Attempted to store document with no text chunks.")
        return

    # Call Gemini to get embeddings for all chunks in one batch
    # The embeddings_client passed should be the initialized client from client.py
    response = embeddings_client.embeddings.create(
        input=chunks,
        model="models/gemini-embedding-001"
    )
    embeddings = [d.embedding for d in response.data]

    # Generate deterministic or random IDs for the chunks
    ids = [f"{doc_id}_chunk_{i}" for i in range(len(chunks))]
    
    # Metadata for perfect deletion and retrieval
    metadatas = [
        {
            "document_id": doc_id,
            "filename": filename,
            "category": category, # "BRD" or "ORG_DATA"
            "chunk_index": i
        } for i in range(len(chunks))
    ]

    collection.add(
        ids=ids,
        embeddings=embeddings,
        documents=chunks,
        metadatas=metadatas
    )

def delete_document_from_chroma(doc_id: str):
    """
    Delete all chunks associated with a specific SQL Document ID from ChromaDB.
    """
    # Chroma allows deleting by filtering metadata
    collection.delete(
        where={"document_id": doc_id}
    )

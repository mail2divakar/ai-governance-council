import pandas as pd
from datetime import datetime, timedelta

# Create a Pandas Excel Writer using XlsxWriter or Openpyxl
# We'll use openpyxl as it's standard with pandas
excel_file = "AI_Governance_Agent_Project_Plan.xlsx"

writer = pd.ExcelWriter(excel_file, engine='openpyxl')

# 1. Timeline Overview
overview_data = {
    'Phase': ['Intake', 'Design', 'Develop', 'Validate', 'Deploy', 'Monitor (Hypercare 1)', 'Monitor (Hypercare 2)'],
    'Sprint': ['Sprint 1', 'Sprint 1 & 2', 'Sprint 3 & 4', 'Sprint 5', 'Sprint 6 & 7', 'Hypercare Week 1', 'Hypercare Week 2'],
    'Start Date': ['2026-03-12', '2026-03-19', '2026-04-09', '2026-05-07', '2026-05-21', '2026-06-16', '2026-06-24'],
    'End Date': ['2026-03-25', '2026-04-08', '2026-05-06', '2026-05-20', '2026-06-15', '2026-06-23', '2026-06-30'],
    'Key Deliverable / Milestone': [
        'Requirements Gathered, Architecture Finalized',
        'UX/UI Mockups, Agent Persona Defined',
        'Core Agent Engine, Backend Integrations, Dashboard UI',
        'UAT Completed, Security Scanned, End-to-End Testing',
        'Production Deployment, Go-Live (Live by June 15th)',
        'Issue Triage, Performance Tuning',
        'Handover, Final Stabilisation'
    ],
    'JIRA Epic': ['EPIC-001', 'EPIC-002', 'EPIC-003', 'EPIC-004', 'EPIC-005', 'EPIC-006', 'EPIC-006']
}
df_overview = pd.DataFrame(overview_data)
df_overview.to_excel(writer, sheet_name='Timeline_Overview', index=False)

# Helper for other sheets
def add_sheet(writer, sheet_name, data):
    df = pd.DataFrame(data)
    df.to_excel(writer, sheet_name=sheet_name, index=False)

# 2. Intake
intake_data = {
    'Epic': ['EPIC-001']*4,
    'Story': [
        'Define AI Lifecycle Governance Business Requirements',
        'Identify Key Stakeholders and RACI Matrix',
        'Current State Assessment & Gap Analysis',
        'Finalize Scope and Success Criteria'
    ],
    'Sprint': ['Sprint 1']*4,
    'Status': ['To Do']*4,
    'Assignee': ['Business Analyst', 'Project Manager', 'Architect', 'Product Owner']
}
add_sheet(writer, '01_Intake', intake_data)

# 3. Design
design_data = {
    'Epic': ['EPIC-002']*5,
    'Story': [
        'Design System Architecture and Data Flow Diagram',
        'Create Wireframes for AI Governance Dashboard',
        'Design Agent Conversational Flows and Intents',
        'Define Data Models and Database Schema',
        'Security & Compliance Review of Architecture'
    ],
    'Sprint': ['Sprint 1', 'Sprint 2', 'Sprint 2', 'Sprint 2', 'Sprint 2'],
    'Status': ['To Do']*5,
    'Assignee': ['Architect', 'UX Designer', 'AI Engineer', 'Backend Dev', 'Security Lead']
}
add_sheet(writer, '02_Design', design_data)

# 4. Develop
develop_data = {
    'Epic': ['EPIC-003']*7,
    'Story': [
        'Setup Development Environment & CI/CD Pipelines',
        'Develop Frontend Dashboard UI Components',
        'Develop Backend APIs for Governance Rules',
        'Integrate LLM / Agent Orchestration Engine',
        'Implement Authentication & RBAC',
        'Develop Automated Policy Checks',
        'Integrate with External Systems (Jira/ServiceNow)'
    ],
    'Sprint': ['Sprint 3', 'Sprint 3', 'Sprint 3', 'Sprint 4', 'Sprint 4', 'Sprint 4', 'Sprint 4'],
    'Status': ['To Do']*7,
    'Assignee': ['DevOps', 'Frontend Dev', 'Backend Dev', 'AI Engineer', 'Security Eng', 'Backend Dev', 'Backend Dev']
}
add_sheet(writer, '03_Develop', develop_data)

# 5. Validate
validate_data = {
    'Epic': ['EPIC-004']*5,
    'Story': [
        'Write Unit & Integration Tests',
        'Perform System Integration Testing (SIT)',
        'Conduct User Acceptance Testing (UAT)',
        'Vulnerability Assessment and Penetration Testing (VAPT)',
        'Load and Performance Testing'
    ],
    'Sprint': ['Sprint 5']*5,
    'Status': ['To Do']*5,
    'Assignee': ['QA Automation', 'QA Team', 'Business Users', 'Security Team', 'Performance Eng']
}
add_sheet(writer, '04_Validate', validate_data)

# 6. Deploy
deploy_data = {
    'Epic': ['EPIC-005']*4,
    'Story': [
        'Prepare Production Environment & Resources',
        'Conduct Dry-Run Deployment',
        'User Training & Documentation Generation',
        'Production Deployment (Target: June 15)'
    ],
    'Sprint': ['Sprint 6', 'Sprint 6', 'Sprint 7', 'Sprint 7'],
    'Status': ['To Do']*4,
    'Assignee': ['DevOps', 'DevOps', 'Tech Writer', 'Release Manager']
}
add_sheet(writer, '05_Deploy', deploy_data)

# 7. Monitor
monitor_data = {
    'Epic': ['EPIC-006']*4,
    'Story': [
        'Hypercare W1: Active Monitoring & Triage',
        'Hypercare W1: Resolve Critical/High Priority Bugs',
        'Hypercare W2: Measure Agent Accuracy & KPIs',
        'Project Closure & Handoff to BAU Support'
    ],
    'Sprint': ['Hypercare 1', 'Hypercare 1', 'Hypercare 2', 'Hypercare 2'],
    'Status': ['To Do']*4,
    'Assignee': ['Support/Dev', 'Dev Team', 'Data Analyst', 'Project Manager']
}
add_sheet(writer, '06_Monitor_Hypercare', monitor_data)

# Formatting: Auto-adjust column widths
for sheetname in writer.sheets:
    worksheet = writer.sheets[sheetname]
    for col in worksheet.columns:
        max_length = 0
        column = col[0].column_letter # Get the column name
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(cell.value)
            except:
                pass
        adjusted_width = (max_length + 2)
        worksheet.column_dimensions[column].width = adjusted_width

writer.close()
print(f"Project plan generated successfully at {excel_file}")

import docx

doc = docx.Document('AI_new_idea_submission_questionnaire_data.docx')

with open('extracted_questions.txt', 'w', encoding='utf-8') as f:
    # Extract paragraphs
    f.write("--- PARAGRAPHS ---\n")
    for p in doc.paragraphs:
        if p.text.strip():
            f.write(p.text.strip() + '\n')
    
    # Extract tables
    f.write("\n--- TABLES ---\n")
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                text = cell.text.strip()
                if text:
                    f.write(text.replace('\n', ' ') + '\n')

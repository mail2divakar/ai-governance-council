from fastapi import APIRouter, Request, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from auth import get_current_user
from storage import storage
from client import async_client
from routers.use_cases import extract_fields_from_conversation, compute_thread_status, compute_stage, compute_risk_score

router = APIRouter()

GOVERNANCE_SYSTEM_PROMPT = ""

def get_next_intake_question(status_result: dict) -> dict:
    """Get the next conversational question based on the 12-question progress."""
    current_q = status_result.get("currentQuestion")
    
    questions = {
        "q1": "Great! Let's start with the basics. What should we call this project?",
        "q2": "Who is the Business Owner and Executive Sponsor for this initiative?",
        "q3": "Can you describe what the AI does, who the target audience is, and what data sources it uses?",
        "q4": "Is this project considered AI Research? If so, tell me about any patient consent disclosures.",
        "q5": "Let's talk about Safety. On a scale of 1-5, how likely is it that this system could cause harm? Please share your reasoning too.",
        "q6": "What about Security? How likely is a data breach or unauthorized access (1-5)?",
        "q7": "Bias and Fairness: how likely are discriminatory outcomes from this system (1-5)?",
        "q8": "Reliability: what's the likelihood of model failure or hallucinations (1-5)?",
        "q9": "Finally, Privacy: how likely is identifying individuals or data misuse (1-5)?",
        "q10": "Now, what is your strategy for mitigating these identified risks?",
        "q11": "What AI techniques are you using? (e.g., ML, NLP, CV, or LLMs)",
        "q12": "Lastly, what monitoring metrics will you track for performance, drift, and bias?"
    }
    
    if current_q == "complete":
        return {
            "content": "Brilliant! I've collected all 12 points of information for the framework. Your use case is now ready for formal governance review.",
            "actions": [
                {"label": "View My Use Cases", "action": "view_my_cases", "prompt": "Show my use cases"}
            ]
        }
    
    return {
        "content": questions.get(current_q, "Next question..."),
        "actions": []
    }


# ===== Project Chat Session Endpoints =====

@router.get("/api/project/chat/session")
async def get_project_chat_session(
    request: Request,
    db: Session = Depends(get_db)
):
    """Get or create project chat session with greeting and options."""
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    if user.role != "PROJECT":
        raise HTTPException(status_code=403, detail="Only PROJECT users can access this endpoint")
    
    first_name = user.firstName or "there"
    
    return {
        "greeting": f"Hey {first_name}! I'm here to help you with AI governance.",
        "subtext": "What would you like to do today?",
        "userName": first_name,
        "options": [
            {
                "id": "baptist_health",
                "label": "Learn About Baptist Health",
                "description": "Learn more about our organization's mission and values",
                "prompt": "Tell me about Baptist Health, its mission, and its values.",
                "conversational": True
            },
            {
                "id": "ai_literacy",
                "label": "AI Literacy",
                "description": "Understand the basics of AI technology",
                "prompt": "I want to improve my AI literacy. Can you explain the basics of AI?",
                "conversational": True
            },
            {
                "id": "policy_info",
                "label": "Governance Rules",
                "description": "I'll explain our AI governance requirements in plain language",
                "prompt": "Can you explain the AI governance policies and rules to me? I want to understand what's required.",
                "conversational": True
            },
            {
                "id": "register_usecase",
                "label": "Register a new AI project",
                "description": "Let's walk through submitting your AI use case together",
                "prompt": "I have an AI project I'd like to register for governance review. Can you help me?",
                "conversational": True
            },
            {
                "id": "track_status",
                "label": "Check my submissions",
                "description": "See how your use cases are progressing",
                "prompt": "Can you show me the status of my AI use case submissions?",
                "conversational": True
            },
        ],
    }


@router.post("/api/project/chat")
async def project_chat(
    request: Request,
    db: Session = Depends(get_db)
):
    """Process project team chat messages using OpenAI."""
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    if user.role != "PROJECT":
        raise HTTPException(status_code=403, detail="Only PROJECT users can access this endpoint")
    
    body = await request.json()
    message = body.get("message", "")
    history = body.get("history", [])
    action = body.get("action")
    action_data = body.get("actionData", {})
    
    # Handle start_intake action - create use case and begin conversation
    if action == "start_intake":
        use_case = storage.create_use_case(db, {
            "userId": user.id,
            "title": "New AI Use Case",
            "status": "PENDING",
            "currentStep": "1",
            "totalSteps": "4"
        })
        
        greeting = "I'll help you register a new AI use case. Let's start with the basics. What does your AI system do? Just give me a quick description."
        
        storage.create_message(db, {
            "useCaseId": use_case.id,
            "role": "agent",
            "content": greeting
        })
        
        return {
            "content": greeting,
            "actions": [],
            "useCaseId": use_case.id,
        }
    
    # Handle continue_intake action - continue collecting info for existing use case
    if action == "continue_intake" and action_data.get("useCaseId"):
        use_case_id = action_data["useCaseId"]
        use_case = storage.get_use_case(db, use_case_id)
        if use_case and use_case.userId == user.id:
            storage.create_message(db, {
                "useCaseId": use_case_id,
                "role": "user",
                "content": message
            })
            
            all_messages = storage.get_messages_by_use_case(db, use_case_id)
            extracted_fields = await extract_fields_from_conversation(message, use_case, all_messages, db)
            if extracted_fields:
                if "title" not in extracted_fields and use_case.title == "New AI Use Case" and extracted_fields.get("whatTheAIDoes"):
                    extracted_fields["title"] = extracted_fields["whatTheAIDoes"][:80]
                storage.update_use_case(db, use_case_id, extracted_fields)
            
            updated_use_case = storage.get_use_case(db, use_case_id)
            status_result = compute_thread_status(updated_use_case, db)
            assessment = storage.get_assessment_by_use_case(db, use_case_id)
            stage = compute_stage(updated_use_case, status_result["threadStatus"], assessment is not None)
            risk = compute_risk_score(updated_use_case, db)
            
            storage.update_use_case(db, use_case_id, {
                "threadStatus": status_result["threadStatus"],
                "questionsAnswered": status_result["answered"],
                "currentQuestion": status_result["currentQuestion"],
                "intakeStep": status_result["intakeStep"],
                "intakeProgressPercentage": status_result["progress"],
                "stage": stage,
                "calculatedRiskScore": risk["score"],
                "calculatedRiskTier": risk["tier"],
                "riskScore": str(risk["score"]),
                "riskLevel": risk["tier"],
                "riskDrivers": risk["drivers"]
            })
            
            next_question = get_next_intake_question(status_result)
            
            storage.create_message(db, {
                "useCaseId": use_case_id,
                "role": "agent",
                "content": next_question["content"]
            })
            
            if status_result["threadStatus"] == "approval_required":
                next_question["actions"] = [
                    {"label": "View Use Case", "action": "view_use_case", "data": {"useCaseId": use_case_id}},
                    {"label": "Start Another", "action": "start_intake", "prompt": "I want to register another AI use case"},
                ]
            
            return {
                "content": next_question["content"],
                "actions": next_question.get("actions", []),
                "useCaseId": use_case_id,
            }
    
    # Template responses for common actions
    if action == "show_policy_categories":
        return {
            "content": "Here are our governance policy categories. Click one to learn more:",
            "actions": [
                {"label": "AI Ethics", "action": "policy_category_AI_ETHICS", "prompt": "Tell me about AI Ethics policies"},
                {"label": "Data Governance", "action": "policy_category_DATA_GOVERNANCE", "prompt": "Tell me about Data Governance policies"},
                {"label": "Model Risk", "action": "policy_category_MODEL_RISK", "prompt": "Tell me about Model Risk policies"},
                {"label": "Security", "action": "policy_category_SECURITY", "prompt": "Tell me about Security policies"},
                {"label": "Compliance", "action": "policy_category_COMPLIANCE", "prompt": "Tell me about Compliance policies"},
            ]
        }
    
    if action == "show_risk_model":
        return {
            "content": """**Risk Scoring Model (0-100)**

The governance framework evaluates AI use cases across weighted risk dimensions:

- **Data Risk (20%)**: PII (+25), PHI (+35), sensitive data handling
- **Deployment Risk (20%)**: Production (+20), Pilot (+10), POC (+5)
- **Control Risk (15%)**: Missing audit logging, encryption, access controls
- **Human Oversight (10%)**: No human-in-the-loop (+10)

**Risk Tiers:**
- **Low (0-29)**: Approve with standard controls
- **Medium (30-59)**: Security review required
- **High (60+)**: Full council review with Security, Privacy, Legal""",
            "actions": [
                {"label": "View Policies", "action": "show_policy_categories", "prompt": "Show me the policy categories"},
                {"label": "Register Project", "action": "start_registration", "prompt": "I want to register a new AI use case"},
            ]
        }
    
    if action == "show_hard_stops":
        return {
            "content": """**Automatic Blocking Scenarios**

The following will automatically block an AI use case from approval:

1. **No data classification provided** - All AI systems must classify their data
2. **PHI without encryption** - Health data requires encryption at rest and in transit
3. **PII without consent mechanism** - Personal data needs documented consent
4. **No human oversight for high-impact decisions** - Critical decisions require human review
5. **Third-party AI without security review** - External tools need vetting""",
            "actions": [
                {"label": "View Risk Model", "action": "show_risk_model", "prompt": "Show me the risk model"},
                {"label": "Register Project", "action": "start_registration", "prompt": "I want to register a new AI use case"},
            ]
        }
    
    # Build messages for Gemini
    messages = [{"role": "system", "content": GOVERNANCE_SYSTEM_PROMPT}]
    for h in history[-10:]:
        messages.append({"role": h.get("role", "user"), "content": h.get("content", "")})
    messages.append({"role": "user", "content": message})
    
    try:
        response = await async_client.chat.completions.create(
            model="gemini-2.5-flash",
            messages=messages,
            temperature=0.7,
            max_tokens=500,
        )
        
        content = response.choices[0].message.content or "I apologize, but I couldn't generate a response."
        
        # Generate action buttons based on intent
        actions = []
        lower_msg = message.lower()
        if "polic" in lower_msg:
            actions.append({"label": "View Policies", "action": "show_policy_categories", "prompt": "Show me the policy categories"})
        if "risk" in lower_msg:
            actions.append({"label": "View Risk Model", "action": "show_risk_model", "prompt": "Show me the risk model"})
        if "register" in lower_msg or "submit" in lower_msg or "new" in lower_msg:
            actions.append({"label": "Start Registration", "action": "start_registration", "prompt": "I want to register a new AI use case"})
        
        return {
            "content": content,
            "actions": actions
        }
    except Exception as e:
        print(f"Gemini error in project chat: {e}")
        raise HTTPException(status_code=500, detail="Failed to process message")

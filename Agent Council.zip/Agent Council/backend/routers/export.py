from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from openpyxl import Workbook
from io import BytesIO

from database import get_db
from auth import get_current_user
from storage import storage

router = APIRouter()

import os
import docx
from openpyxl.styles import Font, Alignment

# ===== Excel Export Endpoint =====

def get_user_answer(q_num: str, use_case, all_questions=None) -> str:
    """Map the docx question number to the UseCase object's fields or dynamicAnswers."""
    # Basic hardcoded mapping for standard fields
    mapping = {
        "1": "title",
        "2": "businessOwner",
        "3": "executiveSponsor",
        "4": "projectDescription",
        "5": "targetAudiences",
        "6": "inputDataSources",
        "7": "isAIResearch",
        "8": "patientConsentDisclosure",
        "9": "safetyRiskLikelihood",
        "10": "safetyRiskReasoning",
        "11": "securityRiskLikelihood",
        "12": "securityRiskReasoning",
        "17": "biasFairnessLikelihood",
        "18": "biasFairnessReasoning",
        "19": "reliabilityLikelihood",
        "20": "reliabilityReasoning",
        "21": "privacyLikelihood",
        "22": "privacyReasoning",
        "25": "riskMitigationStrategy",
        "27": "aiTechniquesUsed",
        "70": "monitoringMetrics",
    }
    
    field_name = mapping.get(q_num)
    
    # If not in hardcoded mapping, try to find in QuestionConfig by label or ID
    if not field_name and all_questions:
        q_target = f"(Q{q_num})"
        for q in all_questions:
            if q_target in q.label or q.id == q_num or q.id == f"q{q_num}":
                field_name = q.id
                break
                
    if not field_name:
        # Fallback to searching dynamicAnswers directly for qX keys
        if use_case.dynamicAnswers and isinstance(use_case.dynamicAnswers, dict):
            keys = [f"q{q_num}", q_num, f"Q{q_num}"]
            for k in keys:
                if k in use_case.dynamicAnswers:
                    return str(use_case.dynamicAnswers[k])
        return ""

    # Get value from field_name (could be model attr or dynamicAnswers key)
    ans = None
    if hasattr(use_case, field_name):
        ans = getattr(use_case, field_name)
    elif use_case.dynamicAnswers and field_name in use_case.dynamicAnswers:
        ans = use_case.dynamicAnswers[field_name]
        
    if ans is not None:
        if isinstance(ans, bool):
            return "Yes" if ans else "No"
        return str(ans)
        
    return ""


@router.get("/api/use-cases/{use_case_id}/export")
async def export_use_case_excel(
    use_case_id: str,
    request: Request,
    db: Session = Depends(get_db)
):
    """Export use case intake form as Excel file, matching docx format."""
    print("Exporting to Excel matching docx framework")
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    
    # Fetch all questions for mapping
    from models import QuestionConfig
    all_questions = db.query(QuestionConfig).all()
    
    # Check authorization
    if user.role == "PROJECT" and use_case.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized to export this use case")
    
    # Load the docx file
    docx_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "AI_new_idea_submission_questionnaire_data.docx")
    try:
        doc = docx.Document(docx_path)
    except Exception as e:
        print(f"Error loading docx: {e}")
        raise HTTPException(status_code=500, detail=f"Could not load template docx: {str(e)}")
        
    # Create Excel workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "AI Use Case Intake"
    
    headers = [
        "Question detail", 
        "Question Response Type", 
        "Option values (if applicable)", 
        "Notes in quesiton if applicable", 
        "User Answer"
    ]
    
    ws.append(headers)
    for col in range(1, 6):
        cell = ws.cell(row=1, column=col)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    
    current_row = 2
    last_q_row_data = None
    
    for table in doc.tables:
        for row in table.rows:
            raw_row_data = [cell.text.strip(' \n\r\t') for cell in row.cells]
            
            # Skip the header row from docx itself
            if not raw_row_data or raw_row_data[0] == "S.No.":
                continue
                
            q_num = raw_row_data[0]
            
            if q_num:  # New question row
                if last_q_row_data:
                    ws.append(last_q_row_data)
                    for col in range(1, 6):
                        ws.cell(row=current_row, column=col).alignment = Alignment(wrap_text=True, vertical="top")
                    current_row += 1
                
                while len(raw_row_data) < 5:
                    raw_row_data.append("")
                
                new_row = raw_row_data[1:5]
                answer = get_user_answer(q_num, use_case, all_questions) if q_num.isdigit() else ""
                new_row.append(answer)
                last_q_row_data = new_row
            else:
                # Continuation of the previous question
                if last_q_row_data:
                    for i in range(1, min(len(raw_row_data), 5)):
                        val = raw_row_data[i]
                        if val:
                            if last_q_row_data[i-1]:
                                last_q_row_data[i-1] += "\n" + val
                            else:
                                last_q_row_data[i-1] = val

    # Append the last question
    if last_q_row_data:
        ws.append(last_q_row_data)
        for col in range(1, 6):
            ws.cell(row=current_row, column=col).alignment = Alignment(wrap_text=True, vertical="top")

    # Set column widths
    ws.column_dimensions['A'].width = 50
    ws.column_dimensions['B'].width = 25
    ws.column_dimensions['C'].width = 30
    ws.column_dimensions['D'].width = 30
    ws.column_dimensions['E'].width = 50
    
    # Save to BytesIO
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    
    filename = f"ai_use_case_{use_case.title[:30].replace(' ', '_')}.xlsx"
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

from fastapi import APIRouter, Request, Response, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from schemas import LoginRequest
from auth import verify_password, create_session, delete_session, get_current_user, hash_password
from storage import storage
import secrets
from datetime import datetime, timedelta
from models import User
from pydantic import BaseModel, EmailStr

router = APIRouter()

@router.post("/api/dev/login")
async def dev_login(request: LoginRequest, response: Response, db: Session = Depends(get_db)):
    user = storage.get_user_by_username(db, request.username)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    
    if not user.passwordHash or not verify_password(request.password, user.passwordHash):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    
    session_id = create_session(db, user.id)
    response.set_cookie(key="session_id", value=session_id, httponly=True, max_age=7*24*60*60, samesite="none", secure=True)
    
    storage.create_audit_log(db, {
        "action": "USER_LOGIN",
        "actorUserId": user.id,
        "details": {"username": user.username}
    })
    
    return {
        "success": True,
        "user": {
            "id": user.id,
            "email": user.email,
            "firstName": user.firstName,
            "lastName": user.lastName,
            "role": user.role,
            "username": user.username,
            "profileImageUrl": user.profileImageUrl
        }
    }


@router.post("/api/dev/logout")
async def dev_logout(request: Request, response: Response, db: Session = Depends(get_db)):
    session_id = request.cookies.get("session_id")
    if session_id:
        delete_session(db, session_id)
    response.delete_cookie(key="session_id", samesite="none", secure=True)
    return {"success": True}


@router.get("/api/auth/user")
async def get_auth_user(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return None
    return {
        "id": user.id,
        "email": user.email,
        "firstName": user.firstName,
        "lastName": user.lastName,
        "role": user.role,
        "username": user.username,
        "profileImageUrl": user.profileImageUrl
    }

class InviteVerifyResponse(BaseModel):
    email: str
    role: str

@router.get("/api/auth/verify-invite/{token}", response_model=InviteVerifyResponse)
async def verify_invite_token(token: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.inviteToken == token).first()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid or expired invite token")
        
    if user.inviteExpiresAt and user.inviteExpiresAt < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Invite token has expired")
        
    return InviteVerifyResponse(email=user.email, role=user.role)

class CompleteRegistrationRequest(BaseModel):
    token: str
    username: str
    password: str

@router.post("/api/auth/complete-registration")
async def complete_registration(request: CompleteRegistrationRequest, response: Response, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.inviteToken == request.token).first()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid or expired invite token")
        
    if user.inviteExpiresAt and user.inviteExpiresAt < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Invite token has expired")
        
    existing_username = db.query(User).filter(User.username == request.username).first()
    if existing_username and existing_username.id != user.id:
        raise HTTPException(status_code=400, detail="Username is already taken")

    user.username = request.username
    user.passwordHash = hash_password(request.password)
    user.inviteToken = None
    user.inviteExpiresAt = None
    
    db.commit()
    db.refresh(user)
    
    # Log them in automatically
    session_id = create_session(db, user.id)
    response.set_cookie(key="session_id", value=session_id, httponly=True, max_age=7*24*60*60, samesite="none", secure=True)
    
    storage.create_audit_log(db, {
        "action": "USER_REGISTERED",
        "actorUserId": user.id,
        "details": {"username": user.username, "role": user.role}
    })
    
    return {
        "success": True,
        "user": {
            "id": user.id,
            "email": user.email,
            "role": user.role,
            "username": user.username
        }
    }

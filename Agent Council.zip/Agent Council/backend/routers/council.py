from fastapi import APIRouter, Request, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime

from database import get_db
from models import QuestionConfig
from schemas import CreateDecisionRequest
from auth import require_auth
from storage import storage
from client import client as openai_client
from utils import serialize_use_case

router = APIRouter()

# ============ COUNCIL ROUTES ============

@router.get("/api/decision-types")
async def get_decision_types(request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    return ["APPROVE", "DISAPPROVE", "APPROVE_WITH_CONDITIONS", "NEEDS_MORE_INFORMATION", "PENDING"]


@router.get("/api/questions")
async def get_questions(request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    questions = db.query(QuestionConfig).filter(QuestionConfig.isActive == 1).all()
    return questions


# ============ POLICY & OPA ROUTES ============
@router.get("/api/policies")
async def get_policies(request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    return storage.get_policies(db)


@router.get("/api/policies/{category}")
async def get_policy_by_category(category: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    policy = storage.get_active_policy(db, category)
    if not policy:
        raise HTTPException(status_code=404, detail="Policy not found")
    
    items = storage.get_policy_items(db, policy.id)
    opa_version = storage.get_latest_opa_version(db, category)
    
    storage.create_audit_log(db, {
        "action": "POLICY_VIEWED",
        "actorUserId": user.id,
        "details": {"category": category, "policyId": policy.id, "version": policy.version}
    })
    
    return {
        "policy": policy,
        "items": items,
        "opaVersion": opa_version.version if opa_version else None
    }


@router.post("/api/policies/{category}/item/{item_index}/edit")
async def edit_policy_item(category: str, item_index: int, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    body = await request.json()
    title = body.get("title")
    statement = body.get("statement")
    controls = body.get("controls")
    
    current_policy = storage.get_active_policy(db, category)
    if not current_policy:
        raise HTTPException(status_code=404, detail="Policy not found")
    
    current_items = storage.get_policy_items(db, current_policy.id)
    next_version = current_policy.version + 1
    
    storage.update_policy_status(db, current_policy.id, "ARCHIVED")
    
    new_policy = storage.create_policy(db, {
        "category": category,
        "fullName": current_policy.fullName,
        "version": next_version,
        "status": "ACTIVE",
        "updatedBy": user.id
    })
    
    for item in current_items:
        if item.itemIndex == item_index:
            storage.create_policy_item(db, {
                "policyId": new_policy.id,
                "itemIndex": item.itemIndex,
                "title": title or item.title,
                "statement": statement or item.statement,
                "controls": controls or item.controls
            })
        else:
            storage.create_policy_item(db, {
                "policyId": new_policy.id,
                "itemIndex": item.itemIndex,
                "title": item.title,
                "statement": item.statement,
                "controls": item.controls
            })
    
    storage.create_audit_log(db, {
        "action": "POLICY_ITEM_EDITED",
        "actorUserId": user.id,
        "details": {"category": category, "version": next_version, "itemIndex": item_index, "policyId": new_policy.id}
    })
    
    updated_items = storage.get_policy_items(db, new_policy.id)
    return {"policy": new_policy, "items": updated_items}


@router.get("/api/council/use-cases/review")
async def get_use_cases_for_review(request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    use_cases = storage.get_use_cases_for_review(db)
    return [serialize_use_case(uc) for uc in use_cases]


@router.get("/api/council/use-cases/{use_case_id}")
async def get_council_use_case(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    
    messages = storage.get_messages_by_use_case(db, use_case_id)
    assessment = storage.get_assessment_by_use_case(db, use_case_id)
    decision = storage.get_decision_by_use_case(db, use_case_id)
    thread = storage.get_council_thread_by_use_case(db, use_case_id)
    
    return {
        "useCase": serialize_use_case(use_case),
        "messages": messages,
        "assessment": assessment,
        "decision": decision,
        "thread": thread
    }


@router.post("/api/council/use-cases/{use_case_id}/decision")
async def create_council_decision(use_case_id: str, data: CreateDecisionRequest, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    
    decision = storage.create_decision(db, {
        "useCaseId": use_case_id,
        "status": data.status,
        "rationale": data.rationale or [],
        "decidedBy": user.id
    })
    
    thread_status = "approved" if data.status in ["APPROVE", "APPROVE_WITH_CONDITIONS"] else "disapproved" if data.status == "DISAPPROVE" else "approval_required"
    
    storage.update_use_case(db, use_case_id, {
        "status": data.status,
        "currentStep": "4",
        "threadStatus": thread_status,
        "missingInfo": [],
        "missingData": []
    })
    
    storage.create_audit_log(db, {
        "useCaseId": use_case_id,
        "action": "DECISION_SET",
        "actorUserId": user.id,
        "details": {"status": data.status, "rationale": data.rationale}
    })
    
    return decision


@router.post("/api/council/use-cases/{use_case_id}/thread")
async def create_council_thread(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    
    existing_thread = storage.get_council_thread_by_use_case(db, use_case_id)
    if existing_thread:
        return existing_thread
    
    thread = storage.create_council_thread(db, {
        "useCaseId": use_case_id,
        "councilUserId": user.id,
        "status": "OPEN"
    })
    return thread


@router.get("/api/council/threads/{thread_id}/messages")
async def get_council_thread_messages(thread_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    return storage.get_council_messages_by_thread(db, thread_id)


@router.post("/api/council/threads/{thread_id}/messages")
async def send_council_thread_message(thread_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    body = await request.json()
    content = body.get("content", "")
    
    message = storage.create_council_message(db, {
        "councilThreadId": thread_id,
        "role": "council",
        "content": content
    })
    
    storage.create_audit_log(db, {
        "action": "COUNCIL_MESSAGE_SENT",
        "actorUserId": user.id,
        "details": {"threadId": thread_id}
    })
    
    return message


# ============ COUNCIL CHAT ROUTES ============

@router.get("/api/council/chat/sessions")
async def get_council_chat_sessions(request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    return storage.get_council_chat_sessions_by_user(db, user.id)


@router.post("/api/council/chat/sessions")
async def create_council_chat_session(request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    body = await request.json()
    title = body.get("title", "New Chat")
    
    session = storage.create_council_chat_session(db, {
        "userId": user.id,
        "title": title
    })
    return session


@router.get("/api/council/chat/sessions/{session_id}")
async def get_council_chat_session(session_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    session = storage.get_council_chat_session(db, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    messages = storage.get_council_chat_messages_by_session(db, session_id)
    return {"session": session, "messages": messages}


@router.delete("/api/council/chat/sessions/{session_id}")
async def delete_council_chat_session(session_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    session = storage.get_council_chat_session(db, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    storage.delete_council_chat_session(db, session_id)
    return {"success": True}


@router.patch("/api/council/chat/sessions/{session_id}")
async def update_council_chat_session(session_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    session = storage.get_council_chat_session(db, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    body = await request.json()
    title = body.get("title")
    
    updated = storage.update_council_chat_session(db, session_id, {"title": title})
    return updated


@router.post("/api/council/chat/sessions/{session_id}/messages")
async def send_council_chat_message(session_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    session = storage.get_council_chat_session(db, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    body = await request.json()
    message = body.get("message", "").strip()
    if not message:
        raise HTTPException(status_code=400, detail="Message is required")
    
    user_message = storage.create_council_chat_message(db, {
        "sessionId": session_id,
        "role": "user",
        "content": message
    })
    
    previous_messages = storage.get_council_chat_messages_by_session(db, session_id)
    all_policies = storage.get_policies(db)
    reviewable_cases = storage.get_use_cases_for_review(db)
    
    policy_summary = "\n".join([f"{p.category}: {p.fullName} (v{p.version})" for p in all_policies]) or "No policies defined yet"
    review_summary = "\n".join([f"- {c.title or '(untitled)'} (Risk: {c.riskLevel or 'N/A'})" for c in reviewable_cases[:10]]) or "No cases pending review"
    
    system_prompt = f"""You are the AI Governance Council Assistant. You help council members with all governance tasks.

COUNCIL MEMBER: {user.firstName} {user.lastName}

POLICIES:
{policy_summary}

PENDING CASES:
{review_summary}

Be concise and helpful. Use markdown formatting. Suggest logical next actions."""

    conversation = [{"role": "system", "content": system_prompt}]
    for msg in previous_messages[-20:]:
        role = "assistant" if msg.role == "assistant" else "user"
        conversation.append({"role": role, "content": msg.content})
    
    try:
        response = openai_client.chat.completions.create(
            model="gemini-2.5-flash",
            messages=conversation,
            max_tokens=2048,
            temperature=0.7
        )
        ai_content = response.choices[0].message.content or "I couldn't generate a response."
    except Exception as e:
        print(f"Error in council chat: {e}")
        ai_content = "I apologize, but I'm experiencing technical difficulties. Please try again."
    
    ai_message = storage.create_council_chat_message(db, {
        "sessionId": session_id,
        "role": "assistant",
        "content": ai_content
    })
    
    if len(previous_messages) <= 1 and session.title == "New Chat":
        title_summary = message[:50] + ("..." if len(message) > 50 else "")
        storage.update_council_chat_session(db, session_id, {"title": title_summary})
    
    return {"userMessage": user_message, "aiMessage": ai_message}


# ============ AUDIT ROUTES ============

@router.get("/api/audits")
async def get_audits(request: Request, status: Optional[str] = None, from_date: Optional[str] = None, to_date: Optional[str] = None, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    if user.role != "COUNCIL":
        raise HTTPException(status_code=403, detail="Council role required")
    
    filters = {}
    if from_date:
        filters["from"] = datetime.fromisoformat(from_date)
    if to_date:
        filters["to"] = datetime.fromisoformat(to_date)
    
    logs = storage.get_audit_logs(db, filters if filters else None)
    
    result = []
    for log in logs:
        actor = storage.get_user_by_id(db, log.actorUserId)
        use_case = storage.get_use_case(db, log.useCaseId) if log.useCaseId else None
        result.append({
            **log.__dict__,
            "actorName": f"{actor.firstName} {actor.lastName}" if actor else "Unknown",
            "useCaseTitle": use_case.title if use_case else None
        })
    
    return result

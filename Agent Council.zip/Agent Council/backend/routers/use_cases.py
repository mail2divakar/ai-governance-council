from fastapi import APIRouter, Request, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import json

from database import get_db
from models import UseCase, Message, QuestionConfig, User
from schemas import CreateUseCaseRequest, UpdateUseCaseRequest, SendMessageRequest
from auth import require_auth
from storage import storage
from client import async_client
from utils import serialize_use_case
import models

router = APIRouter()

def compute_thread_status(use_case: UseCase, db: Session, configs: List[QuestionConfig] = None) -> dict:
    if configs is None:
        configs = db.query(QuestionConfig).filter(QuestionConfig.isActive == 1).order_by(QuestionConfig.id).all()
    
    answered = []
    for c in configs:
        val = getattr(use_case, c.id, None)
        if val is None and use_case.dynamicAnswers:
            val = use_case.dynamicAnswers.get(c.id)
            
        if val is not None and val != "":
            answered.append(c.id)
            
    total = len(configs) if configs else 1
    progress = (len(answered) / total) * 100
    
    current_q = "complete"
    intake_step = "COMPLETE"
    
    for c in configs:
        if c.id not in answered:
            current_q = c.id
            intake_step = c.section
            break

    return {
        "threadStatus": "approval_required" if len(answered) == total else "info_required",
        "progress": progress,
        "answered": answered,
        "currentQuestion": current_q,
        "intakeStep": intake_step
    }


def compute_stage(use_case: UseCase, thread_status: str, has_assessment: bool) -> str:
    if thread_status == "approved" or thread_status == "disapproved":
        return "DECISION"
    if has_assessment:
        return "ASSESSMENT"
    if thread_status == "approval_required" or thread_status == "data_required":
        return "DETAILS"
    return "BASIC_INFO"


def compute_risk_score(use_case: UseCase, db: Session, configs: List[QuestionConfig] = None) -> dict:
    if configs is None:
        configs = db.query(QuestionConfig).filter(QuestionConfig.isActive == 1).all()
    
    weighted_sum = 0.0
    total_possible_weight = 0.0
    drivers = []
    
    for c in configs:
        if c.weight > 0:
            total_possible_weight += c.weight * 5  # Assume max score is 5 for weighted questions
            
            val = getattr(use_case, c.id, None)
            if val is None and use_case.dynamicAnswers:
                val = use_case.dynamicAnswers.get(c.id)
                
            try:
                score_val = float(val) if val is not None else 0.0
                weighted_sum += score_val * c.weight
                
                if score_val >= 4:
                    drivers.append(f"High risk in {c.label}")
            except (ValueError, TypeError):
                pass
                
    score = (weighted_sum / total_possible_weight) * 100 if total_possible_weight > 0 else 0.0
    
    if score >= 70: tier = "CRITICAL"
    elif score >= 50: tier = "HIGH"
    elif score >= 25: tier = "MEDIUM"
    else: tier = "LOW"
    
    return {
        "score": score,
        "tier": tier,
        "drivers": drivers[:3]
    }


async def extract_fields_from_conversation(content: str, use_case: UseCase, messages: List[Message], db: Session) -> dict:
    # Use only the last 3 messages + current content to keep input size manageable
    recent_msgs = messages[-3:] if len(messages) > 3 else messages
    conversation_text = "\n".join([f"{m.role}: {m.content}" for m in recent_msgs])
    conversation_text += f"\nuser: {content}"
    # Cap total conversation text at 4000 chars to avoid token overflow
    if len(conversation_text) > 4000:
        conversation_text = conversation_text[-4000:]

    configs = db.query(QuestionConfig).filter(QuestionConfig.isActive == 1).all()

    extraction_fields_prompt = ""
    for c in configs:
        prompt_text = c.extractionPrompt or f"extract the user's answer to: '{c.label}'"
        extraction_fields_prompt += f"- {c.id}: {prompt_text}\n"

    try:
        response = await async_client.chat.completions.create(
            model="gemini-2.5-flash",
            messages=[
                {"role": "system", "content": f"""Extract governance intake fields from the conversation. Return a JSON object with only the fields that have clear values.

INSTRUCTIONS:
- If the user provides a project description, INFER all fields where possible — including RISK scores (1-5 scale) and BENEFIT scores (1-3 scale).
- Use the per-field scoring guidance inside the questions to determine each score.
- For RISK and BENEFIT score questions: if you infer the score, also return an inferred reasoning for the corresponding reasoning question.
- ALWAYS return risk AND benefit scores with reasonings when a description is present.

FIELD EXTRACTION GUIDE (use these exact keys in the JSON):
{extraction_fields_prompt}

IMPORTANT:
- Return only a valid JSON object where keys are the field ids (e.g. "q1", "q2")."""},
                {"role": "user", "content": f"Extract fields from:\n{conversation_text}"}
            ],
            response_format={"type": "json_object"},
            max_tokens=8192
        )

        raw = response.choices[0].message.content or "{}"

        # Partial JSON recovery: if truncated, salvage complete key-value pairs
        try:
            fields = json.loads(raw)
        except json.JSONDecodeError:
            import re
            fields = {}
            for m in re.finditer(r'"(q\d+)"\s*:\s*("(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?)', raw):
                key, val = m.group(1), m.group(2)
                try:
                    fields[key] = json.loads(val)
                except Exception:
                    fields[key] = val.strip('"')

        for key, value in fields.items():
            if isinstance(value, list):
                fields[key] = ", ".join(str(v) for v in value)

        return fields
    except Exception as e:
        print(f"Error extracting fields: {e}")
        return {}


async def generate_agent_response(content: str, use_case: UseCase, messages: List[Message], status_result: dict, db: Session, is_form_update: bool = False) -> str:
    configs = db.query(QuestionConfig).filter(QuestionConfig.isActive == 1).order_by(QuestionConfig.id).all()
    
    sections = {}
    for c in configs:
        sections.setdefault(c.section, []).append(c)
        
    system_prompt = """You are a KSG AI Governance Council Officer. Help users register and govern AI use cases through natural conversation based on our configured Intake Framework.

RESPONSE STYLE - CRITICAL:
- Keep responses to 2-4 sentences maximum
- Never use markdown formatting (no #, *, -, bullet points, or headers)
- Be warm and conversational, like a helpful colleague
- Ask only ONE question at a time
- Acknowledge briefly, then ask next question

INTAKE FRAMEWORK:
"""
    for sec, qs in sections.items():
        system_prompt += f"\nSECTION: {sec}\n"
        for q in qs:
            system_prompt += f"- {q.id}: {q.label}\n"

    system_prompt += "\nWhen starting a new intake, guide them through these sections one by one. Ask for reasoning when they give scale-based scores."

    context = f"""Current use case: {use_case.title}
Stage: {use_case.stage}
Thread Status: {status_result['threadStatus']}
Progress: {status_result['progress']}%
Current Question: {status_result['currentQuestion']}
Section: {status_result['intakeStep']}

Current answered fields: {', '.join(status_result['answered'])}
Missing fields: {[c.id for c in configs if c.id not in status_result['answered']]}
"""
    
    conversation = [{"role": "system", "content": system_prompt + "\n\n" + context}]
    for msg in messages[-5:]:
        role = "assistant" if msg.role == "agent" else "user"
        conversation.append({"role": role, "content": msg.content})
    conversation.append({"role": "user", "content": content})
    
    try:
        response = await async_client.chat.completions.create(
            model="gemini-2.5-flash",
            messages=conversation,
            max_tokens=300 if is_form_update else 1000,
            temperature=0.7
        )
        return response.choices[0].message.content or "I'm having trouble responding. Please try again."
    except Exception as e:
        print(f"Error generating response: {e}")
        return "I apologize, but I'm experiencing technical difficulties. Please try again in a moment."


def build_search_text(use_case: UseCase) -> str:
    parts = [
        use_case.title or "",
        use_case.whatTheAIDoes or "",
        use_case.whoUsesIt or "",
        use_case.userPopulation or "",
        use_case.decisionsOrActions or "",
        use_case.dataItMightTouch or ""
    ]
    return " ".join(parts).lower()


def calculate_similarity(text1: str, text2: str) -> float:
    words1 = set(text1.split())
    words2 = set(text2.split())
    if not words1 or not words2:
        return 0
    intersection = words1 & words2
    union = words1 | words2
    return len(intersection) / len(union) if union else 0


def find_similar_use_cases(use_case_id: str, user_id: str, all_use_cases: List[UseCase], search_text: str, threshold: float = 0.15) -> List[dict]:
    similar = []
    for uc in all_use_cases:
        if uc.id == use_case_id:
            continue
        uc_text = build_search_text(uc)
        score = calculate_similarity(search_text, uc_text)
        if score >= threshold:
            similar.append({
                "id": uc.id,
                "title": uc.title,
                "similarity": round(score, 2),
                "status": uc.status,
                "riskLevel": uc.riskLevel
            })
    similar.sort(key=lambda x: x["similarity"], reverse=True)
    return similar[:5]


# ============ USE CASE ROUTES ============

@router.get("/api/use-cases")
async def get_use_cases(request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    
    if user.role == "ADMIN":
        use_cases = storage.get_all_use_cases(db)
    else:
        use_cases = storage.get_use_cases_by_user(db, user.id)
        
    # Batch fetch all potential creators to avoid N+1 naming queries
    user_ids = list(set(uc.userId for uc in use_cases))
    creators = db.query(User).filter(User.id.in_(user_ids)).all() if user_ids else []
    users_cache = {}
    for c in creators:
        name = f"{c.firstName or ''} {c.lastName or ''}".strip()
        users_cache[c.id] = name or c.email or "Unknown"

    result = []
    for uc in use_cases:
        try:
            item = serialize_use_case(uc)
            item["creatorName"] = users_cache.get(uc.userId, "Unknown")
            result.append(item)
        except Exception as e:
            print(f"Error serializing use case {uc.id}: {e}")
            raise e
            
    return result


@router.get("/api/use-cases/{use_case_id}")
async def get_use_case(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id and getattr(user, "role", "") not in ["ADMIN", "COUNCIL"]:
        raise HTTPException(status_code=403, detail="Not authorized")
    return serialize_use_case(use_case)


@router.get("/api/use-cases/{use_case_id}/detail-bundle")
async def get_use_case_detail_bundle(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    """Return use case + messages + assessment + decision + similar in one call."""
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id and getattr(user, "role", "") not in ["ADMIN", "COUNCIL"]:
        raise HTTPException(status_code=403, detail="Not authorized")

    messages = storage.get_messages_by_use_case(db, use_case_id)
    assessment = storage.get_assessment_by_use_case(db, use_case_id)
    decision = storage.get_decision_by_use_case(db, use_case_id)

    # Similar cases
    user_use_cases = storage.get_use_cases_by_user(db, user.id)
    search_text = build_search_text(use_case)
    similar = find_similar_use_cases(use_case.id, user.id, user_use_cases, search_text, 0.15)

    return {
        "useCase": serialize_use_case(use_case),
        "messages": messages,
        "assessment": assessment,
        "decision": decision,
        "similar": similar,
    }


@router.post("/api/use-cases")
async def create_use_case(data: CreateUseCaseRequest, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    
    use_case = storage.create_use_case(db, {
        "userId": user.id,
        "title": data.title or "New AI Use Case",
        "whatTheAIDoes": data.initialMessage,
        "status": "PENDING",
        "currentStep": "1",
        "totalSteps": "4"
    })
    
    if data.initialMessage:
        storage.create_message(db, {
            "useCaseId": use_case.id,
            "role": "user",
            "content": data.initialMessage
        })
        
        all_messages = storage.get_messages_by_use_case(db, use_case.id)
        extracted_fields = await extract_fields_from_conversation(data.initialMessage, use_case, all_messages, db)
        if extracted_fields:
            storage.update_use_case(db, use_case.id, extracted_fields)
        
        updated_use_case = storage.get_use_case(db, use_case.id)
        
        configs = db.query(QuestionConfig).filter(QuestionConfig.isActive == 1).order_by(QuestionConfig.id).all()
        status_result = compute_thread_status(updated_use_case, db, configs)
        assessment = storage.get_assessment_by_use_case(db, use_case.id)
        stage = compute_stage(updated_use_case, status_result["threadStatus"], assessment is not None)
        risk = compute_risk_score(updated_use_case, db, configs)
        
        storage.update_use_case(db, use_case.id, {
            "threadStatus": status_result["threadStatus"],
            "questionsAnswered": status_result["answered"],
            "currentQuestion": status_result["currentQuestion"],
            "intakeStep": status_result["intakeStep"],
            "intakeProgressPercentage": status_result["progress"],
            "stage": stage,
            "calculatedRiskScore": risk["score"],
            "calculatedRiskTier": risk["tier"],
            "riskScore": str(risk["score"]),
            "riskLevel": risk["tier"],
            "riskDrivers": risk["drivers"]
        })
        
        updated_use_case = storage.get_use_case(db, use_case.id)
        agent_response = await generate_agent_response(data.initialMessage, updated_use_case, all_messages, status_result, db)
        storage.create_message(db, {
            "useCaseId": use_case.id,
            "role": "agent",
            "content": agent_response
        })
    
    final_use_case = storage.get_use_case(db, use_case.id)
    
    storage.create_audit_log(db, {
        "useCaseId": use_case.id,
        "action": "USE_CASE_CREATED",
        "actorUserId": user.id,
        "details": {"title": final_use_case.title}
    })
    
    return serialize_use_case(final_use_case)


@router.patch("/api/use-cases/{use_case_id}")
async def update_use_case(use_case_id: str, data: UpdateUseCaseRequest, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updates = data.model_dump(exclude_unset=True)
    # Apply initial updates
    use_case = storage.update_use_case(db, use_case_id, updates)
    
    # Compute status and risk with the updated object
    configs = db.query(QuestionConfig).filter(QuestionConfig.isActive == 1).order_by(QuestionConfig.id).all()
    status_result = compute_thread_status(use_case, db, configs=configs)
    assessment = storage.get_assessment_by_use_case(db, use_case_id)
    stage = compute_stage(use_case, status_result["threadStatus"], assessment is not None)
    risk = compute_risk_score(use_case, db, configs=configs)
    
    # Batch apply all computation results in one final update
    updated_use_case = storage.update_use_case(db, use_case_id, {
        "threadStatus": status_result["threadStatus"],
        "questionsAnswered": status_result["answered"],
        "currentQuestion": status_result["currentQuestion"],
        "intakeStep": status_result["intakeStep"],
        "intakeProgressPercentage": status_result["progress"],
        "stage": stage,
        "calculatedRiskScore": risk["score"],
        "calculatedRiskTier": risk["tier"],
        "riskScore": str(risk["score"]),
        "riskLevel": risk["tier"],
        "riskDrivers": risk["drivers"]
    })
    
    return serialize_use_case(updated_use_case)


@router.delete("/api/use-cases/{use_case_id}")
async def delete_use_case(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    success = storage.delete_use_case(db, use_case_id)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to delete use case")
        
    storage.create_audit_log(db, {
        "action": "USE_CASE_DELETED",
        "actorUserId": user.id,
        "details": {"useCaseId": use_case_id, "title": use_case.title}
    })
    
    return {"success": True}


@router.get("/api/use-cases/{use_case_id}/messages")
async def get_messages(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id and getattr(user, "role", "") not in ["ADMIN", "COUNCIL"]:
        raise HTTPException(status_code=403, detail="Not authorized")
    return storage.get_messages_by_use_case(db, use_case_id)


@router.post("/api/use-cases/{use_case_id}/messages")
async def send_message(use_case_id: str, data: SendMessageRequest, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    storage.create_message(db, {
        "useCaseId": use_case_id,
        "role": "user",
        "content": data.content
    })
    
    all_messages = storage.get_messages_by_use_case(db, use_case_id)
    if not data.isFormUpdate:
        extracted_fields = await extract_fields_from_conversation(data.content, use_case, all_messages, db)
        if extracted_fields:
            use_case = storage.update_use_case(db, use_case_id, extracted_fields)
    
    # Compute everything with the current object
    # If it's a form update, we still want the freshest computed data for the UI response
    configs = db.query(QuestionConfig).filter(QuestionConfig.isActive == 1).order_by(QuestionConfig.id).all()
    status_result = compute_thread_status(use_case, db, configs=configs)
    assessment = storage.get_assessment_by_use_case(db, use_case_id)
    stage = compute_stage(use_case, status_result["threadStatus"], assessment is not None)
    risk = compute_risk_score(use_case, db, configs=configs)
    
    # One final update for the computations
    updated_use_case = storage.update_use_case(db, use_case_id, {
        "threadStatus": status_result["threadStatus"],
        "questionsAnswered": status_result["answered"],
        "currentQuestion": status_result["currentQuestion"],
        "intakeStep": status_result["intakeStep"],
        "intakeProgressPercentage": status_result["progress"],
        "stage": stage,
        "calculatedRiskScore": risk["score"],
        "calculatedRiskTier": risk["tier"],
        "riskScore": str(risk["score"]),
        "riskLevel": risk["tier"],
        "riskDrivers": risk["drivers"]
    })
    
    agent_response = await generate_agent_response(data.content, updated_use_case, all_messages, status_result, db, is_form_update=data.isFormUpdate)
    agent_message = storage.create_message(db, {
        "useCaseId": use_case_id,
        "role": "agent",
        "content": agent_response
    })
    
    return {
        **agent_message.__dict__,
        "threadStatus": status_result["threadStatus"],
        "progress": status_result["progress"],
        "currentQuestion": status_result["currentQuestion"],
        "intakeStep": status_result["intakeStep"],
        "stage": stage,
        "risk": risk
    }


@router.get("/api/use-cases/{use_case_id}/similar")
async def get_similar_use_cases(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id and getattr(user, "role", "") not in ["ADMIN", "COUNCIL"]:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    user_use_cases = storage.get_use_cases_by_user(db, user.id)
    search_text = build_search_text(use_case)
    similar_cases = find_similar_use_cases(use_case.id, user.id, user_use_cases, search_text, 0.15)
    return similar_cases


@router.get("/api/use-cases/{use_case_id}/assessment")
async def get_assessment(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id and getattr(user, "role", "") not in ["ADMIN", "COUNCIL"]:
        raise HTTPException(status_code=403, detail="Not authorized")
    assessment = storage.get_assessment_by_use_case(db, use_case_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")
    return assessment


@router.post("/api/use-cases/{use_case_id}/assessment")
async def create_assessment(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    domains = []
    risks = []
    gaps = []
    recommendations = []
    
    if use_case.hasPersonalData == "yes":
        domains.append("Privacy_and_Consent")
        risks.append("Personal data processing requires privacy controls")
        recommendations.append("Implement data subject access request handling")
    
    if use_case.hasSensitiveData == "yes":
        domains.append("Data_Governance")
        risks.append("Sensitive data handling increases risk exposure")
        recommendations.append("Apply data classification and encryption policies")
    
    if use_case.thirdPartyTools and use_case.thirdPartyTools.lower() not in ["no", "none", "n/a"]:
        domains.append("ThirdParty_and_Vendor_Risk")
        risks.append("Third-party AI tools introduce vendor dependency")
        recommendations.append("Conduct vendor risk assessment")
    
    if use_case.humanInTheLoop == "no":
        domains.append("Responsible_AI")
        risks.append("Lack of human oversight in decision-making")
        recommendations.append("Implement human review checkpoints")
    
    if use_case.deploymentType == "automated_action":
        domains.append("Model_Risk_Management")
        risks.append("Automated actions require robust error handling")
        recommendations.append("Implement rollback mechanisms and monitoring")
    
    if not domains:
        domains = ["Model_Risk_Management", "Documentation_and_Records"]
        risks = ["General AI governance review required"]
        recommendations = ["Complete governance intake documentation"]
    
    if not use_case.hasArchitectureDiagram or use_case.hasArchitectureDiagram == "false":
        gaps.append("Missing architecture diagram")
    if not use_case.hasDataFlowDoc or use_case.hasDataFlowDoc == "false":
        gaps.append("Missing data flow documentation")
    if not use_case.hasEvaluationResults or use_case.hasEvaluationResults == "false":
        gaps.append("Missing model evaluation results")
    if not use_case.hasMonitoringPlan or use_case.hasMonitoringPlan == "false":
        gaps.append("Missing monitoring plan")
    
    assessment = storage.create_assessment(db, {
        "useCaseId": use_case_id,
        "domains": domains,
        "risks": risks,
        "gaps": gaps,
        "recommendations": recommendations
    })
    
    storage.update_use_case(db, use_case_id, {
        "currentStep": "3",
        "governanceDomains": domains
    })
    
    storage.create_audit_log(db, {
        "useCaseId": use_case_id,
        "action": "ASSESSMENT_RUN",
        "actorUserId": user.id,
        "details": {"domains": domains, "riskCount": len(risks)}
    })
    
    return assessment


@router.get("/api/use-cases/{use_case_id}/decision")
async def get_decision(use_case_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_auth(request, db)
    use_case = storage.get_use_case(db, use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    if use_case.userId != user.id and getattr(user, "role", "") not in ["ADMIN", "COUNCIL"]:
        raise HTTPException(status_code=403, detail="Not authorized")
    decision = storage.get_decision_by_use_case(db, use_case_id)
    if not decision:
        raise HTTPException(status_code=404, detail="Decision not found")
    return decision

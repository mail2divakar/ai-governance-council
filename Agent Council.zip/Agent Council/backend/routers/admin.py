from fastapi import APIRouter, Request, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List
import os
import shutil
import tempfile
from datetime import datetime
import uuid

from database import get_db
from models import QuestionConfig, AdminDocument, generate_uuid, User
from schemas import AdminDocumentOut
from auth import require_auth, require_role
from pydantic import BaseModel, EmailStr
import secrets
from datetime import datetime, timedelta
import vector_store
from client import client as openai_client

router = APIRouter()

class InviteRequest(BaseModel):
    email: EmailStr
    role: str

@router.post("/api/admin/users/invite")
async def invite_user(data: InviteRequest, request: Request, db: Session = Depends(get_db)):
    user = await require_role(["ADMIN"])(request, db)
    
    if data.role not in ["PROJECT", "COUNCIL", "ADMIN"]:
        raise HTTPException(status_code=400, detail="Invalid role specified")
        
    existing_user = db.query(User).filter(User.email == data.email).first()
    
    token = secrets.token_urlsafe(32)
    expires_at = datetime.utcnow() + timedelta(days=3)
    
    if existing_user:
        if existing_user.username and existing_user.passwordHash:
            raise HTTPException(status_code=400, detail="User already registered")
            
        existing_user.role = data.role
        existing_user.inviteToken = token
        existing_user.inviteExpiresAt = expires_at
    else:
        new_user = User(
            email=data.email,
            role=data.role,
            inviteToken=token,
            inviteExpiresAt=expires_at
        )
        db.add(new_user)
        
    db.commit()
    
    # In a production environment, you would use an SMTP server here (like SendGrid).
    # Since we are mocking email delivery, we just return the link to the Admin UI.
    invite_link = f"/invite/{token}"
    
    return {
        "success": True,
        "message": "Invite token generated successfully.",
        "inviteLink": invite_link,
        "email": data.email
    }

@router.get("/api/admin/users")
async def list_users(request: Request, db: Session = Depends(get_db)):
    user = await require_role(["ADMIN"])(request, db)
    users = db.query(User).order_by(User.createdAt.desc()).all()
    
    return [
        {
            "id": u.id,
            "email": u.email,
            "firstName": u.firstName,
            "lastName": u.lastName,
            "role": u.role,
            "username": u.username,
            "hasPassword": bool(u.passwordHash),
            "inviteToken": u.inviteToken,
            "inviteExpiresAt": u.inviteExpiresAt.isoformat() if u.inviteExpiresAt else None,
            "createdAt": u.createdAt.isoformat() if u.createdAt else None
        }
        for u in users
    ]

# ============ QUESTION CONFIG ROUTES ============

@router.get("/api/admin/questions")
async def get_question_configs(request: Request, db: Session = Depends(get_db)):
    await require_auth(request, db)
    configs = db.query(QuestionConfig).order_by(QuestionConfig.section, QuestionConfig.id).all()
    total_weight = sum(c.weight or 0 for c in configs if c.section == "RISK")
    result = []
    for c in configs:
        result.append({
            "id": c.id,
            "section": c.section,
            "label": c.label,
            "type": c.type,
            "extractionPrompt": c.extractionPrompt,
            "weight": c.weight,
            "isActive": c.isActive,
            "weightPercent": round((c.weight or 0) / total_weight * 100, 1) if total_weight and c.section == "RISK" else None,
            "createdAt": c.createdAt.isoformat() if c.createdAt else None,
            "updatedAt": c.updatedAt.isoformat() if c.updatedAt else None,
        })
    return result


@router.post("/api/admin/questions")
async def create_question_config(data: dict, request: Request, db: Session = Depends(get_db)):
    await require_auth(request, db)
    required = ["id", "section", "label", "type"]
    for field in required:
        if not data.get(field):
            raise HTTPException(status_code=400, detail=f"'{field}' is required")
    existing = db.query(QuestionConfig).filter(QuestionConfig.id == data["id"]).first()
    if existing:
        raise HTTPException(status_code=409, detail=f"Question with id '{data['id']}' already exists")
    config = QuestionConfig(
        id=data["id"],
        section=data["section"],
        label=data["label"],
        type=data["type"],
        extractionPrompt=data.get("extractionPrompt", ""),
        weight=float(data.get("weight", 0)),
        isActive=int(data.get("isActive", 1)),
    )
    db.add(config)
    db.commit()
    db.refresh(config)
    return {"id": config.id, "message": "Created successfully"}


@router.patch("/api/admin/questions/{question_id}")
async def update_question_config(question_id: str, data: dict, request: Request, db: Session = Depends(get_db)):
    await require_auth(request, db)
    config = db.query(QuestionConfig).filter(QuestionConfig.id == question_id).first()
    if not config:
        raise HTTPException(status_code=404, detail="Question not found")
    allowed = ["label", "type", "extractionPrompt", "weight", "isActive", "section"]
    for key in allowed:
        if key in data:
            val = data[key]
            if key == "weight":
                val = float(val)
            elif key == "isActive":
                val = int(val)
            setattr(config, key, val)
    config.updatedAt = datetime.now()
    db.commit()
    db.refresh(config)
    return {"id": config.id, "message": "Updated successfully"}


@router.delete("/api/admin/questions/{question_id}")
async def delete_question_config(question_id: str, request: Request, db: Session = Depends(get_db)):
    await require_auth(request, db)
    config = db.query(QuestionConfig).filter(QuestionConfig.id == question_id).first()
    if not config:
        raise HTTPException(status_code=404, detail="Question not found")
    db.delete(config)
    db.commit()
    return {"message": "Deleted successfully"}


# ============ ADMIN DOCUMENT ROUTES ============

@router.get("/api/admin/documents", response_model=List[AdminDocumentOut])
async def list_documents(request: Request, db: Session = Depends(get_db)):
    user = await require_role(["ADMIN"])(request, db)
    docs = db.query(AdminDocument).order_by(AdminDocument.uploadedAt.desc()).all()
    return docs

@router.post("/api/admin/documents")
async def upload_document(
    request: Request, 
    file: UploadFile = File(...), 
    category: str = Form(...),
    db: Session = Depends(get_db)
):
    user = await require_role(["ADMIN"])(request, db)
    
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
        
    doc_id = generate_uuid()() if callable(generate_uuid) else str(uuid.uuid4())
    
    # Save file temporarily to extract text
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name
        
    try:
        # Extract and chunk text
        text = vector_store.extract_text_from_pdf(tmp_path)
        chunks = vector_store.chunk_text(text)
        
        if not chunks:
            raise HTTPException(status_code=400, detail="Could not extract text from the PDF")
            
        # Store in ChromaDB
        vector_store.store_document_chunks_in_chroma(
            doc_id=doc_id,
            filename=file.filename,
            category=category,
            chunks=chunks,
            embeddings_client=openai_client
        )
        
        # Store tracking record in SQLite
        db_doc = AdminDocument(
            id=doc_id,
            filename=file.filename,
            category=category
        )
        db.add(db_doc)
        db.commit()
        db.refresh(db_doc)
        
        return db_doc
        
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

@router.delete("/api/admin/documents/{doc_id}")
async def delete_document(doc_id: str, request: Request, db: Session = Depends(get_db)):
    user = await require_role(["ADMIN"])(request, db)
    
    # 1. Check if doc exists in SQLite
    doc = db.query(AdminDocument).filter(AdminDocument.id == doc_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
        
    # 2. Perfect delete from ChromaDB
    try:
        vector_store.delete_document_from_chroma(doc_id)
    except Exception as e:
        print(f"Error removing from ChromaDB: {e}")
        # We proceed to delete from SQLite even if vector delete fails
        
    # 3. Delete from SQLite
    db.delete(doc)
    db.commit()
    
    return {"success": True}

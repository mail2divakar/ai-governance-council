import random
from datetime import datetime, timedelta
from database import SessionLocal
from models import UseCase, User
from storage import storage

def seed_use_cases():
    db = SessionLocal()
    try:
        # strict query to finding a user
        user = db.query(User).filter(User.username == "carol_davis").first()
        if not user:
            print("User 'carol_davis' not found. Please run seed.py first.")
            # Fallback to any project user
            user = db.query(User).filter(User.role == "PROJECT").first()
            if not user:
                print("No project user found.")
                return

        print(f"Seeding use cases for user: {user.username} ({user.id})")

        use_cases_data = [
            {
                "title": "HR Resume Screener",
                "whatTheAIDoes": "Analyzes applicant resumes to rank candidates for open positions based on skills and experience.",
                "status": "PENDING",
                "stage": "RISK_ASSESSMENT",
                "riskLevel": "HIGH",
                "riskScore": "75",
                "businessOwner": "Sarah Connor",
                "executiveSponsor": "Terminator T-800",
                "threadStatus": "approval_required",
                "governanceDomains": ["Fairness_and_Bias", "Privacy"],
                "createdAt": datetime.now() - timedelta(days=2),
                "updatedAt": datetime.now() - timedelta(hours=5),
            },
            {
                "title": "Customer Support Helper",
                "whatTheAIDoes": "LLM-based chatbot that helps human agents draft responses to customer inquiries.",
                "status": "APPROVED",
                "stage": "DECISION",
                "riskLevel": "MEDIUM",
                "riskScore": "45",
                "businessOwner": "John Doe",
                "executiveSponsor": "Jane Smith",
                "threadStatus": "approved",
                "governanceDomains": ["Reliability"],
                "createdAt": datetime.now() - timedelta(days=10),
                "updatedAt": datetime.now() - timedelta(days=1),
            },
             {
                "title": "Fraud Detection System",
                "whatTheAIDoes": "Real-time analysis of transaction data to identify and block potentially fraudulent activities.",
                "status": "PENDING",
                "stage": "ASSESSMENT",
                "riskLevel": "HIGH",
                "riskScore": "82",
                "businessOwner": "Money Penny",
                "executiveSponsor": "James Bond",
                "threadStatus": "data_required",
                "governanceDomains": ["Security", "Privacy", "Explainability"],
                "createdAt": datetime.now() - timedelta(days=5),
                "updatedAt": datetime.now() - timedelta(days=3),
            },
            {
                "title": "Inventory Forecaster",
                "whatTheAIDoes": "Predicts future inventory needs based on historical sales data and seasonal trends.",
                "status": "APPROVED",
                "stage": "DECISION",
                "riskLevel": "LOW",
                "riskScore": "15",
                "businessOwner": "Alice Logistics",
                "executiveSponsor": "Bob SupplyChain",
                "threadStatus": "approved",
                "governanceDomains": [],
                "createdAt": datetime.now() - timedelta(days=15),
                "updatedAt": datetime.now() - timedelta(days=14),
            },
            {
                "title": "Marketing Copy Generator",
                "whatTheAIDoes": "Generates draft email marketing copy and social media posts.",
                "status": "PENDING",
                "stage": "BASIC_INFO",
                "riskLevel": "LOW",
                "riskScore": "20",
                "businessOwner": "Don Draper",
                "executiveSponsor": "Roger Sterling",
                "threadStatus": "info_required",
                "governanceDomains": ["Copyright"],
                "createdAt": datetime.now() - timedelta(minutes=30),
                "updatedAt": datetime.now() - timedelta(minutes=10),
            },
            {
                "title": "Medical Diagnosis Assistant",
                "whatTheAIDoes": "Analyzes X-ray and MRI images to assist radiologists in detecting anomalies.",
                "status": "PENDING",
                "stage": "RISK_ASSESSMENT",
                "riskLevel": "CRITICAL",
                "riskScore": "95",
                "businessOwner": "Dr. Gregory House",
                "executiveSponsor": "Dr. Lisa Cuddy",
                "threadStatus": "verification_required",
                "governanceDomains": ["Safety", "Reliability", "Fairness_and_Bias"],
                "createdAt": datetime.now() - timedelta(days=1),
                "updatedAt": datetime.now() - timedelta(hours=2),
            },
            {
                "title": "Code Completion Tool",
                "whatTheAIDoes": "Internal tool providing code suggestions to developers within the IDE.",
                "status": "APPROVED",
                "stage": "DECISION",
                "riskLevel": "MEDIUM",
                "riskScore": "30",
                "businessOwner": "Linus Torvalds",
                "executiveSponsor": "Bill Gates",
                "threadStatus": "approved",
                "governanceDomains": ["Security"],
                "createdAt": datetime.now() - timedelta(days=20),
                "updatedAt": datetime.now() - timedelta(days=19),
            },
        ]

        created_count = 0
        for uc_data in use_cases_data:
            # Check if title exists to avoid duplicates
            exists = db.query(UseCase).filter(UseCase.title == uc_data["title"], UseCase.userId == user.id).first()
            if exists:
                print(f"Skipping existing: {uc_data['title']}")
                continue
            
            uc_data["userId"] = user.id
            # Ensure JSON fields are lists
            if "governanceDomains" in uc_data:
                # SQLite wrapper handles JSON, but make sure it's a list
                pass 
                
            storage.create_use_case(db, uc_data)
            created_count += 1
            
        print(f"Successfully created {created_count} use cases.")

    except Exception as e:
        print(f"Error seeding use cases: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    seed_use_cases()

@echo off
py -3.11 %*

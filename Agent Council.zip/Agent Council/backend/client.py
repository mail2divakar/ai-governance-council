import os
import openai
from dotenv import load_dotenv

load_dotenv()

GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"

client = openai.OpenAI(
    api_key=os.environ.get("GOOGLE_API_KEY"),
    base_url=GEMINI_BASE_URL,
)

async_client = openai.AsyncOpenAI(
    api_key=os.environ.get("GOOGLE_API_KEY"),
    base_url=GEMINI_BASE_URL,
)

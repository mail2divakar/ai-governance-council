from pydantic import BaseModel, Field
from typing import Optional, List, Any, Dict
from datetime import datetime

class UserBase(BaseModel):
    email: Optional[str] = None
    firstName: Optional[str] = None
    lastName: Optional[str] = None
    role: Optional[str] = "PROJECT"
    username: Optional[str] = None

class UserOut(UserBase):
    id: str
    profileImageUrl: Optional[str] = None
    createdAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class LoginRequest(BaseModel):
    username: str
    password: str

class CreateUseCaseRequest(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    initialMessage: Optional[str] = None

class UpdateUseCaseRequest(BaseModel):
    title: Optional[str] = None
    whatTheAIDoes: Optional[str] = None
    whoUsesIt: Optional[str] = None
    userPopulation: Optional[str] = None
    decisionsOrActions: Optional[str] = None
    dataItMightTouch: Optional[str] = None
    dataClassification: Optional[str] = None
    hasPersonalData: Optional[str] = None
    hasSensitiveData: Optional[str] = None
    thirdPartyTools: Optional[str] = None
    humanInTheLoop: Optional[str] = None
    deploymentType: Optional[str] = None
    decisionImpact: Optional[str] = None
    status: Optional[str] = None
    businessOwner: Optional[str] = None
    executiveSponsor: Optional[str] = None
    projectDescription: Optional[str] = None
    targetAudiences: Optional[str] = None
    inputDataSources: Optional[str] = None
    isAIResearch: Optional[str] = None
    patientConsentDisclosure: Optional[str] = None
    safetyRiskLikelihood: Optional[int] = None
    safetyRiskReasoning: Optional[str] = None
    securityRiskLikelihood: Optional[int] = None
    securityRiskReasoning: Optional[str] = None
    biasFairnessLikelihood: Optional[int] = None
    biasFairnessReasoning: Optional[str] = None
    reliabilityLikelihood: Optional[int] = None
    reliabilityReasoning: Optional[str] = None
    privacyLikelihood: Optional[int] = None
    privacyReasoning: Optional[str] = None
    riskMitigationStrategy: Optional[str] = None
    aiTechniquesUsed: Optional[str] = None
    monitoringMetrics: Optional[str] = None
    revenueGenerationImpact: Optional[int] = None
    revenueGenerationReasoning: Optional[str] = None
    revenueGenerationKpi: Optional[str] = None
    patientExperienceImpact: Optional[int] = None
    patientExperienceReasoning: Optional[str] = None
    patientExperienceKpi: Optional[str] = None
    employeeProductivityImpact: Optional[int] = None
    employeeProductivityReasoning: Optional[str] = None
    employeeProductivityKpi: Optional[str] = None
    employeeSatisfactionImpact: Optional[int] = None
    employeeSatisfactionReasoning: Optional[str] = None
    employeeSatisfactionKpi: Optional[str] = None
    benefitAssessmentSummary: Optional[str] = None
    calculatedRiskScore: Optional[float] = None
    calculatedRiskTier: Optional[str] = None
    intakeStep: Optional[str] = None
    questionsAnswered: Optional[List[str]] = None
    currentQuestion: Optional[str] = None
    intakeProgressPercentage: Optional[float] = None
    recommendation: Optional[str] = None
    requiredReviewers: Optional[List[str]] = None
    conditions: Optional[List[str]] = None
    approvalStatus: Optional[str] = None
    decisionNotes: Optional[str] = None
    dynamicAnswers: Optional[dict] = None

    model_config = {"extra": "allow"}

class SendMessageRequest(BaseModel):
    content: str = Field(min_length=1, max_length=10000)
    isFormUpdate: bool = False

class CreateDecisionRequest(BaseModel):
    status: str
    rationale: Optional[List[str]] = []


class QuestionConfigBase(BaseModel):
    id: str
    section: str
    label: str
    type: str
    extractionPrompt: Optional[str] = None
    weight: float = 0.0
    isActive: int = 1


class QuestionConfigCreate(QuestionConfigBase):
    pass


class QuestionConfigUpdate(BaseModel):
    section: Optional[str] = None
    label: Optional[str] = None
    type: Optional[str] = None
    extractionPrompt: Optional[str] = None
    weight: Optional[float] = None
    isActive: Optional[int] = None


class QuestionConfigOut(QuestionConfigBase):
    createdAt: datetime
    updatedAt: datetime
    
    class Config:
        from_attributes = True


class UseCaseOut(BaseModel):
    id: str
    userId: str
    creatorName: Optional[str] = None
    title: str
    whatTheAIDoes: Optional[str] = None
    whoUsesIt: Optional[str] = None
    userPopulation: Optional[str] = None
    decisionsOrActions: Optional[str] = None
    dataItMightTouch: Optional[str] = None
    dataClassification: Optional[str] = None
    hasPersonalData: Optional[str] = None
    hasSensitiveData: Optional[str] = None
    thirdPartyTools: Optional[str] = None
    governanceDomains: Optional[List[str]] = None
    threadStatus: Optional[str] = None
    missingInfo: Optional[List[str]] = None
    missingData: Optional[List[str]] = None
    hasArchitectureDiagram: Optional[str] = None
    hasDataFlowDoc: Optional[str] = None
    hasEvaluationResults: Optional[str] = None
    hasMonitoringPlan: Optional[str] = None
    humanInTheLoop: Optional[str] = None
    deploymentType: Optional[str] = None
    decisionImpact: Optional[str] = None
    stage: Optional[str] = None
    riskScore: Optional[str] = None
    riskLevel: Optional[str] = None
    riskDrivers: Optional[List[str]] = None
    similarUseCaseIds: Optional[List[str]] = None
    status: Optional[str] = None
    currentStep: Optional[str] = None
    totalSteps: Optional[str] = None
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
    
    businessOwner: Optional[str] = None
    executiveSponsor: Optional[str] = None
    projectDescription: Optional[str] = None
    targetAudiences: Optional[str] = None
    inputDataSources: Optional[str] = None
    isAIResearch: Optional[str] = None
    patientConsentDisclosure: Optional[str] = None
    safetyRiskLikelihood: Optional[int] = None
    safetyRiskReasoning: Optional[str] = None
    securityRiskLikelihood: Optional[int] = None
    securityRiskReasoning: Optional[str] = None
    biasFairnessLikelihood: Optional[int] = None
    biasFairnessReasoning: Optional[str] = None
    reliabilityLikelihood: Optional[int] = None
    reliabilityReasoning: Optional[str] = None
    privacyLikelihood: Optional[int] = None
    privacyReasoning: Optional[str] = None
    riskMitigationStrategy: Optional[str] = None
    aiTechniquesUsed: Optional[str] = None
    monitoringMetrics: Optional[str] = None
    revenueGenerationImpact: Optional[int] = None
    revenueGenerationReasoning: Optional[str] = None
    revenueGenerationKpi: Optional[str] = None
    patientExperienceImpact: Optional[int] = None
    patientExperienceReasoning: Optional[str] = None
    patientExperienceKpi: Optional[str] = None
    employeeProductivityImpact: Optional[int] = None
    employeeProductivityReasoning: Optional[str] = None
    employeeProductivityKpi: Optional[str] = None
    employeeSatisfactionImpact: Optional[int] = None
    employeeSatisfactionReasoning: Optional[str] = None
    employeeSatisfactionKpi: Optional[str] = None
    benefitAssessmentSummary: Optional[str] = None
    calculatedRiskScore: Optional[float] = None
    calculatedRiskTier: Optional[str] = None
    intakeStep: Optional[str] = None
    questionsAnswered: Optional[List[str]] = None
    currentQuestion: Optional[str] = None
    intakeProgressPercentage: Optional[float] = None
    recommendation: Optional[str] = None
    requiredReviewers: Optional[List[str]] = None
    conditions: Optional[List[str]] = None
    approvalStatus: Optional[str] = None
    decisionNotes: Optional[str] = None
    
    dynamicAnswers: Optional[Dict[str, Any]] = None
    
    class Config:
        from_attributes = True

class MessageOut(BaseModel):
    id: str
    useCaseId: str
    role: str
    content: str
    metadata: Optional[Any] = Field(default=None, validation_alias="message_metadata")
    createdAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True
        populate_by_name = True

class AssessmentOut(BaseModel):
    id: str
    useCaseId: str
    domains: Optional[List[str]] = None
    risks: Optional[List[str]] = None
    gaps: Optional[List[str]] = None
    recommendations: Optional[List[str]] = None
    createdAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class DecisionOut(BaseModel):
    id: str
    useCaseId: str
    status: str
    rationale: Optional[List[str]] = None
    decidedBy: str
    createdAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class PolicyOut(BaseModel):
    id: str
    category: str
    fullName: str
    version: int
    status: str
    updatedBy: str
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class PolicyItemOut(BaseModel):
    id: str
    policyId: str
    itemIndex: int
    title: str
    statement: str
    controls: Optional[List[str]] = None
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class AuditLogOut(BaseModel):
    id: str
    useCaseId: Optional[str] = None
    action: str
    actorUserId: str
    details: Optional[Any] = None
    createdAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class CouncilChatSessionOut(BaseModel):
    id: str
    userId: str
    title: str
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class CouncilChatMessageOut(BaseModel):
    id: str
    sessionId: str
    role: str
    content: str
    metadata: Optional[Any] = Field(default=None, validation_alias="message_metadata")
    createdAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True
        populate_by_name = True

class CouncilThreadOut(BaseModel):
    id: str
    useCaseId: str
    councilUserId: str
    status: str
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class CouncilMessageOut(BaseModel):
    id: str
    councilThreadId: str
    role: str
    content: str
    metadata: Optional[Any] = Field(default=None, validation_alias="message_metadata")
    createdAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True
        populate_by_name = True

class AdminDocumentOut(BaseModel):
    id: str
    filename: str
    category: str
    uploadedAt: Optional[datetime] = None
    
    class Config:
        from_attributes = True

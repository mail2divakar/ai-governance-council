import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from dotenv import load_dotenv
import httpx

from dotenv import load_dotenv
load_dotenv()

from routers import auth, admin, use_cases, council, export, project

app = FastAPI(title="KSG AI Governance Council API")

allowed_origins = []
if os.environ.get("REPL_SLUG"):
    repl_host = f"https://{os.environ.get('REPL_SLUG')}.{os.environ.get('REPL_OWNER', '')}.repl.co"
    allowed_origins.append(repl_host)
if os.environ.get("REPLIT_DEV_DOMAIN"):
    allowed_origins.append(f"https://{os.environ.get('REPLIT_DEV_DOMAIN')}")
allowed_origins.extend(["http://localhost:5000", "http://localhost:5173", "http://127.0.0.1:5000"])

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins if allowed_origins else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, tags=["Auth"])
app.include_router(admin.router, tags=["Admin"])
app.include_router(use_cases.router, tags=["Use Cases"])
app.include_router(council.router, tags=["Council"])
app.include_router(export.router, tags=["Export"])
app.include_router(project.router, tags=["Project"])

# ===== AGUI Endpoint Setup =====
try:
    from agui_agent import setup_agui_endpoint
    setup_agui_endpoint(app, path="/api/agui")
    print("AGUI endpoint initialized at /api/agui")
except Exception as e:
    print(f"Warning: Could not initialize AGUI endpoint: {e}")

vite_dev_server = "http://127.0.0.1:5173"

@app.api_route("/{path:path}", methods=["GET"])
async def catch_all(path: str, request: Request):
    if path.startswith("api/"):
        raise HTTPException(status_code=404, detail="API endpoint not found")
    
    if os.environ.get("NODE_ENV") == "production":
        static_file = f"dist/public/{path}"
        if os.path.isfile(static_file):
            return FileResponse(static_file)
        return FileResponse("dist/public/index.html")
    else:
        try:
            async with httpx.AsyncClient() as client:
                full_url = f"{vite_dev_server}/{path}"
                headers = dict(request.headers)
                headers.pop("host", None)
                response = await client.get(full_url, headers=headers, follow_redirects=True)
                return Response(
                    content=response.content,
                    status_code=response.status_code,
                    headers=dict(response.headers)
                )
        except Exception as e:
            print(f"Vite proxy error: {e}")
            raise HTTPException(status_code=503, detail="Frontend server unavailable")


@app.get("/")
async def serve_root(request: Request):
    if os.environ.get("NODE_ENV") == "production":
        return FileResponse("dist/public/index.html")
    else:
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(f"{vite_dev_server}/", follow_redirects=True)
                return Response(
                    content=response.content,
                    status_code=response.status_code,
                    headers=dict(response.headers)
                )
        except Exception as e:
            print(f"Vite proxy error: {e}")
            raise HTTPException(status_code=503, detail="Frontend server unavailable")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)

import docx
import json

doc = docx.Document('AI_new_idea_submission_questionnaire_data.docx')
tables_data = []
for t in doc.tables:
    table_data = []
    for row in t.rows:
        row_data = [c.text.strip(' \n\r\t') for c in row.cells]
        table_data.append(row_data)
    tables_data.append(table_data)

with open('dump.json', 'w', encoding='utf-8') as f:
    json.dump(tables_data, f, indent=2)

"""
AGUI + Google ADK Governance Intake Agent

This module provides the conversational intake agent for AI governance use cases.
Uses AG-UI protocol for real-time form/chat synchronization.
"""

from __future__ import annotations
import os
import json
from typing import Dict, Optional, List

from ag_ui_adk import ADKAgent, add_adk_fastapi_endpoint
from google.adk.agents import LlmAgent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.tools import ToolContext
from google.genai import types

DEFAULT_INTAKE: Dict = {
    "step": "BASIC",
    "basic": {
        "useCaseName": None,
        "businessOwner": None,
        "objective": None,
        "deploymentStage": None,
    },
    "data": {
        "dataSources": [],
        "dataTypes": [],
        "containsPII": None,
        "containsPHI": None,
        "regions": [],
        "retentionDays": None,
    },
    "risk": {
        "riskScore": None,
        "riskTier": None,
        "rationale": [],
        "controls": {
            "auditLogging": None,
            "encryptionAtRest": None,
            "encryptionInTransit": None,
            "accessControls": None,
            "humanInTheLoop": None,
        },
    },
    "decision": {
        "recommendation": None,
        "requiredReviewers": [],
        "conditions": [],
        "notes": None,
    },
}

STEPS = ["BASIC", "DATA", "RISK", "DECISION"]


def update_intake(
    tool_context: ToolContext,
    section: str,
    values_json: str,
) -> Dict:
    """
    Update a section of the governance intake.

    Args:
      section: one of 'basic', 'data', 'risk', 'decision'
      values_json: JSON string with key/value pairs to merge
    """
    try:
        values = json.loads(values_json)
    except Exception as e:
        return {
            "status": "error",
            "message": f"Invalid JSON for values_json: {str(e)}",
        }

    intake = tool_context.state.get("intake", {})

    if section not in ["basic", "data", "risk", "decision"]:
        return {"status": "error", "message": f"Invalid section: {section}"}

    intake.setdefault(section, {})
    intake[section].update(values)

    tool_context.state["intake"] = intake
    return {"status": "success", "updated_section": section, "intake": intake}


def set_step(tool_context: ToolContext, step: str) -> Dict:
    """Advance to a specific step in the intake process."""
    if step not in STEPS:
        return {"status": "error", "message": f"Invalid step: {step}"}
    intake = tool_context.state.get("intake") or {}
    intake["step"] = step
    tool_context.state["intake"] = intake
    return {"status": "success", "step": step, "intake": intake}


def calculate_risk(tool_context: ToolContext) -> Dict:
    """Calculate the risk score based on the intake data."""
    intake = tool_context.state.get("intake") or DEFAULT_INTAKE.copy()

    score = 0
    rationale: List[str] = []

    if intake["data"].get("containsPII") is True:
        score += 25
        rationale.append("Contains PII (+25)")
    if intake["data"].get("containsPHI") is True:
        score += 35
        rationale.append("Contains PHI (+35)")
    if intake["basic"].get("deploymentStage") == "Prod":
        score += 20
        rationale.append("Production deployment (+20)")
    elif intake["basic"].get("deploymentStage") == "Pilot":
        score += 10
        rationale.append("Pilot deployment (+10)")

    controls = intake["risk"].get("controls", {})
    if controls.get("auditLogging") is False:
        score += 15
        rationale.append("Audit logging missing (+15)")
    if controls.get("humanInTheLoop") is False:
        score += 10
        rationale.append("No human-in-the-loop (+10)")
    if controls.get("encryptionAtRest") is False:
        score += 10
        rationale.append("No encryption at rest (+10)")

    if score >= 60:
        tier = "High"
    elif score >= 30:
        tier = "Medium"
    else:
        tier = "Low"

    intake["risk"]["riskScore"] = score
    intake["risk"]["riskTier"] = tier
    intake["risk"]["rationale"] = rationale
    tool_context.state["intake"] = intake
    return {"status": "success", "riskScore": score, "riskTier": tier, "rationale": rationale, "intake": intake}


def draft_decision(tool_context: ToolContext) -> Dict:
    """Draft a decision recommendation based on the risk tier."""
    intake = tool_context.state.get("intake") or DEFAULT_INTAKE.copy()
    tier = intake["risk"].get("riskTier") or "Low"

    reviewers: List[str] = []
    recommendation = "Approve"
    conditions: List[str] = []

    if tier == "High":
        recommendation = "Needs Review"
        reviewers = ["Security", "Privacy", "Legal"]
        conditions = [
            "Enable audit logging and retain logs per policy",
            "Complete DPIA / threat model review",
            "Implement role-based access controls and least privilege",
        ]
    elif tier == "Medium":
        recommendation = "Needs Review"
        reviewers = ["Security"]
        conditions = [
            "Confirm encryption in transit/at rest",
            "Confirm access controls (SSO/IAM) and log retention",
        ]

    intake["decision"]["recommendation"] = recommendation
    intake["decision"]["requiredReviewers"] = reviewers
    intake["decision"]["conditions"] = conditions
    tool_context.state["intake"] = intake
    return {"status": "success", "decision": intake["decision"], "intake": intake}


def on_before_agent(callback_context: CallbackContext):
    """Initialize intake state if not present."""
    if (
        "intake" not in callback_context.state
        or callback_context.state["intake"] is None
    ):
        callback_context.state["intake"] = DEFAULT_INTAKE.copy()
    return None


def before_model_modifier(callback_context: CallbackContext, llm_request: LlmRequest) -> Optional[LlmResponse]:
    """Inject intake state into the system prompt."""
    intake = callback_context.state.get("intake") or DEFAULT_INTAKE.copy()

    system_text = f"""
You are an AI/Data Governance Intake Agent for the KSG Governance Council.

Goal:
- Build and complete a governance intake form by asking concise questions.
- Persist all extracted details into shared state using tools.

Form steps (strict order):
1) BASIC: useCaseName, businessOwner, objective, deploymentStage (POC/Pilot/Prod)
2) DATA: dataSources, dataTypes, containsPII, containsPHI, regions, retentionDays
3) RISK: controls (auditLogging, encryptionAtRest, encryptionInTransit, accessControls, humanInTheLoop) then calculate risk
4) DECISION: draft recommendation + required reviewers + conditions

Rules:
- Always call update_intake to write user-provided data.
- Ask only for missing fields in the CURRENT step (max 2 questions per message).
- When a step is complete, call set_step to advance.
- Once RISK fields are complete, call calculate_risk.
- Once risk tier exists, call draft_decision.
- Be conversational and helpful, explain why each piece of information matters for governance.

Tool usage rules:
- When calling update_intake:
  - Always pass values_json as a VALID JSON STRING
  - Example: update_intake(section="basic", values_json="{{\\"useCaseName\\":\\"Policy Bot\\",\\"businessOwner\\":\\"HR IT\\"}}")

Current intake state:
{json.dumps(intake, indent=2)}

Current step: {intake.get('step', 'BASIC')}

If the user message indicates form changes:
- Acknowledge that the form was updated.
- Provide governance recommendations for the current step.
- Continue filling missing fields for the current step.
"""

    original = llm_request.config.system_instruction or types.Content(role="system", parts=[])
    if not isinstance(original, types.Content):
        original = types.Content(role="system", parts=[types.Part(text=str(original))])
    if not original.parts:
        original.parts = [types.Part(text="")]

    original.parts[0].text = system_text
    llm_request.config.system_instruction = original
    return None


def after_model_modifier(callback_context: CallbackContext, llm_response: LlmResponse) -> Optional[LlmResponse]:
    """End invocation after each response to keep responses single-turn."""
    callback_context._invocation_context.end_invocation = True
    return None


governance_agent = LlmAgent(
    name="governance_intake_agent",
    model="gemini-2.5-flash",
    instruction="Run AI/Data governance intake for the KSG Governance Council.",
    tools=[update_intake, set_step, calculate_risk, draft_decision],
    before_agent_callback=on_before_agent,
    before_model_callback=before_model_modifier,
    after_model_callback=after_model_modifier,
)


def create_adk_agent(user_id: str = "default_user") -> ADKAgent:
    """Create an ADK agent instance for a specific user."""
    return ADKAgent(
        adk_agent=governance_agent,
        user_id=user_id,
        session_timeout_seconds=3600,
        use_in_memory_services=True,
    )


def setup_agui_endpoint(app, path: str = "/api/agui"):
    """Add the AGUI endpoint to a FastAPI app."""
    adk_agent = create_adk_agent()
    add_adk_fastapi_endpoint(app, adk_agent, path=path)
    return adk_agent

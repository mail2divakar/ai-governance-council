from datetime import datetime
from typing import Optional, List, Any
from sqlalchemy.orm import Session
from sqlalchemy import desc, or_, and_, not_
from models import (
    User, UseCase, Message, Assessment, Decision,
    Policy, PolicyItem, OpaPolicyVersion,
    CouncilThread, CouncilMessage, AuditLog,
    CouncilChatSession, CouncilChatMessage
)

class Storage:
    
    def get_user_by_username(self, db: Session, username: str) -> Optional[User]:
        return db.query(User).filter(User.username == username).first()
    
    def get_user_by_id(self, db: Session, user_id: str) -> Optional[User]:
        return db.query(User).filter(User.id == user_id).first()
    
    def create_user(self, db: Session, data: dict) -> User:
        user = User(**data)
        db.add(user)
        db.commit()
        db.refresh(user)
        return user
    
    def get_use_cases_by_user(self, db: Session, user_id: str) -> List[UseCase]:
        return db.query(UseCase).filter(UseCase.userId == user_id).order_by(desc(UseCase.createdAt)).all()
    
    def get_all_use_cases(self, db: Session) -> List[UseCase]:
        return db.query(UseCase).order_by(desc(UseCase.createdAt)).all()
    
    def get_use_cases_for_review(self, db: Session) -> List[UseCase]:
        return db.query(UseCase).filter(
            and_(
                or_(
                    UseCase.threadStatus == "approval_required",
                    UseCase.threadStatus == "info_required",
                    UseCase.threadStatus == "data_required"
                ),
                UseCase.threadStatus != "approved",
                UseCase.threadStatus != "disapproved"
            )
        ).order_by(desc(UseCase.createdAt)).all()
    
    def get_decided_use_cases(self, db: Session) -> List[UseCase]:
        return db.query(UseCase).filter(
            or_(
                UseCase.threadStatus == "approved",
                UseCase.threadStatus == "disapproved"
            )
        ).order_by(desc(UseCase.updatedAt)).all()
    
    def get_use_case(self, db: Session, use_case_id: str) -> Optional[UseCase]:
        return db.query(UseCase).filter(UseCase.id == use_case_id).first()
    
    def create_use_case(self, db: Session, data: dict) -> UseCase:
        use_case = UseCase(**data)
        db.add(use_case)
        db.commit()
        db.refresh(use_case)
        return use_case
    
    def update_use_case(self, db: Session, use_case_id: str, data: dict) -> Optional[UseCase]:
        use_case = db.query(UseCase).filter(UseCase.id == use_case_id).first()
        if not use_case:
            return None
            
        # Initialize dynamicAnswers if it's None
        if use_case.dynamicAnswers is None:
            use_case.dynamicAnswers = {}
            
        # Sync q1 (title) to the native title field
        if "q1" in data:
            data["title"] = data["q1"]
        
        # We need to make a copy of dynamicAnswers to ensure SQLAlchemy detects the change
        # since it's a JSON field
        dynamic_answers = dict(use_case.dynamicAnswers)
        dynamic_updated = False
            
        for key, value in data.items():
            if hasattr(use_case, key) and key != 'id':
                setattr(use_case, key, value)
            else:
                # Store in dynamicAnswers if not a direct attribute
                dynamic_answers[key] = value
                dynamic_updated = True
        
        if dynamic_updated:
            use_case.dynamicAnswers = dynamic_answers
            
        use_case.updatedAt = datetime.now()
        db.commit()
        db.refresh(use_case)
        return use_case

    def delete_use_case(self, db: Session, use_case_id: str) -> bool:
        use_case = db.query(UseCase).filter(UseCase.id == use_case_id).first()
        if not use_case:
            return False
            
        # Delete related records
        db.query(Message).filter(Message.useCaseId == use_case_id).delete()
        db.query(Assessment).filter(Assessment.useCaseId == use_case_id).delete()
        db.query(Decision).filter(Decision.useCaseId == use_case_id).delete()
        
        # Delete council threads and messages
        threads = db.query(CouncilThread).filter(CouncilThread.useCaseId == use_case_id).all()
        for thread in threads:
            db.query(CouncilMessage).filter(CouncilMessage.councilThreadId == thread.id).delete()
        db.query(CouncilThread).filter(CouncilThread.useCaseId == use_case_id).delete()
        
        # Delete the use case itself
        db.delete(use_case)
        db.commit()
        return True

    
    def get_messages_by_use_case(self, db: Session, use_case_id: str) -> List[Message]:
        return db.query(Message).filter(Message.useCaseId == use_case_id).order_by(Message.createdAt).all()
    
    def create_message(self, db: Session, data: dict) -> Message:
        message = Message(**data)
        db.add(message)
        db.commit()
        db.refresh(message)
        return message
    
    def get_assessment_by_use_case(self, db: Session, use_case_id: str) -> Optional[Assessment]:
        return db.query(Assessment).filter(Assessment.useCaseId == use_case_id).order_by(desc(Assessment.createdAt)).first()
    
    def create_assessment(self, db: Session, data: dict) -> Assessment:
        assessment = Assessment(**data)
        db.add(assessment)
        db.commit()
        db.refresh(assessment)
        return assessment
    
    def get_decision_by_use_case(self, db: Session, use_case_id: str) -> Optional[Decision]:
        return db.query(Decision).filter(Decision.useCaseId == use_case_id).order_by(desc(Decision.createdAt)).first()
    
    def create_decision(self, db: Session, data: dict) -> Decision:
        decision = Decision(**data)
        db.add(decision)
        db.commit()
        db.refresh(decision)
        return decision
    
    def get_policies(self, db: Session) -> List[Policy]:
        return db.query(Policy).order_by(desc(Policy.createdAt)).all()
    
    def get_active_policy(self, db: Session, category: str) -> Optional[Policy]:
        return db.query(Policy).filter(
            and_(Policy.category == category, Policy.status == "ACTIVE")
        ).order_by(desc(Policy.version)).first()
    
    def create_policy(self, db: Session, data: dict) -> Policy:
        policy = Policy(**data)
        db.add(policy)
        db.commit()
        db.refresh(policy)
        return policy
    
    def update_policy_status(self, db: Session, policy_id: str, status: str) -> Optional[Policy]:
        policy = db.query(Policy).filter(Policy.id == policy_id).first()
        if not policy:
            return None
        policy.status = status
        policy.updatedAt = datetime.now()
        db.commit()
        db.refresh(policy)
        return policy
    
    def get_policy_items(self, db: Session, policy_id: str) -> List[PolicyItem]:
        return db.query(PolicyItem).filter(PolicyItem.policyId == policy_id).order_by(PolicyItem.itemIndex).all()
    
    def create_policy_item(self, db: Session, data: dict) -> PolicyItem:
        item = PolicyItem(**data)
        db.add(item)
        db.commit()
        db.refresh(item)
        return item
    
    def update_policy_item(self, db: Session, item_id: str, data: dict) -> Optional[PolicyItem]:
        item = db.query(PolicyItem).filter(PolicyItem.id == item_id).first()
        if not item:
            return None
        for key, value in data.items():
            if hasattr(item, key):
                setattr(item, key, value)
        item.updatedAt = datetime.now()
        db.commit()
        db.refresh(item)
        return item
    
    def get_latest_opa_version(self, db: Session, category: str) -> Optional[OpaPolicyVersion]:
        return db.query(OpaPolicyVersion).filter(OpaPolicyVersion.category == category).order_by(desc(OpaPolicyVersion.version)).first()
    
    def create_opa_version(self, db: Session, data: dict) -> OpaPolicyVersion:
        opa = OpaPolicyVersion(**data)
        db.add(opa)
        db.commit()
        db.refresh(opa)
        return opa
    
    def get_council_thread_by_use_case(self, db: Session, use_case_id: str) -> Optional[CouncilThread]:
        return db.query(CouncilThread).filter(CouncilThread.useCaseId == use_case_id).order_by(desc(CouncilThread.createdAt)).first()
    
    def create_council_thread(self, db: Session, data: dict) -> CouncilThread:
        thread = CouncilThread(**data)
        db.add(thread)
        db.commit()
        db.refresh(thread)
        return thread
    
    def update_council_thread(self, db: Session, thread_id: str, data: dict) -> Optional[CouncilThread]:
        thread = db.query(CouncilThread).filter(CouncilThread.id == thread_id).first()
        if not thread:
            return None
        for key, value in data.items():
            if hasattr(thread, key):
                setattr(thread, key, value)
        thread.updatedAt = datetime.now()
        db.commit()
        db.refresh(thread)
        return thread
    
    def get_council_messages_by_thread(self, db: Session, thread_id: str) -> List[CouncilMessage]:
        return db.query(CouncilMessage).filter(CouncilMessage.councilThreadId == thread_id).order_by(CouncilMessage.createdAt).all()
    
    def create_council_message(self, db: Session, data: dict) -> CouncilMessage:
        message = CouncilMessage(**data)
        db.add(message)
        db.commit()
        db.refresh(message)
        return message
    
    def get_audit_logs(self, db: Session, filters: Optional[dict] = None) -> List[AuditLog]:
        query = db.query(AuditLog)
        if filters:
            if filters.get("from"):
                query = query.filter(AuditLog.createdAt >= filters["from"])
            if filters.get("to"):
                query = query.filter(AuditLog.createdAt <= filters["to"])
        return query.order_by(desc(AuditLog.createdAt)).all()
    
    def create_audit_log(self, db: Session, data: dict) -> AuditLog:
        log = AuditLog(**data)
        db.add(log)
        db.commit()
        db.refresh(log)
        return log
    
    def get_council_chat_sessions_by_user(self, db: Session, user_id: str) -> List[CouncilChatSession]:
        return db.query(CouncilChatSession).filter(CouncilChatSession.userId == user_id).order_by(desc(CouncilChatSession.updatedAt)).all()
    
    def get_council_chat_session(self, db: Session, session_id: str) -> Optional[CouncilChatSession]:
        return db.query(CouncilChatSession).filter(CouncilChatSession.id == session_id).first()
    
    def create_council_chat_session(self, db: Session, data: dict) -> CouncilChatSession:
        session = CouncilChatSession(**data)
        db.add(session)
        db.commit()
        db.refresh(session)
        return session
    
    def update_council_chat_session(self, db: Session, session_id: str, data: dict) -> Optional[CouncilChatSession]:
        session = db.query(CouncilChatSession).filter(CouncilChatSession.id == session_id).first()
        if not session:
            return None
        for key, value in data.items():
            if hasattr(session, key):
                setattr(session, key, value)
        session.updatedAt = datetime.now()
        db.commit()
        db.refresh(session)
        return session
    
    def delete_council_chat_session(self, db: Session, session_id: str):
        db.query(CouncilChatMessage).filter(CouncilChatMessage.sessionId == session_id).delete()
        db.query(CouncilChatSession).filter(CouncilChatSession.id == session_id).delete()
        db.commit()
    
    def get_council_chat_messages_by_session(self, db: Session, session_id: str) -> List[CouncilChatMessage]:
        return db.query(CouncilChatMessage).filter(CouncilChatMessage.sessionId == session_id).order_by(CouncilChatMessage.createdAt).all()
    
    def create_council_chat_message(self, db: Session, data: dict) -> CouncilChatMessage:
        message = CouncilChatMessage(**data)
        db.add(message)
        db.commit()
        db.refresh(message)
        return message

storage = Storage()

"""Seed script to create demo users and sample data."""
import hashlib
from database import SessionLocal, init_db
from models import User, Policy, PolicyItem


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def seed_database():
    """Seed the database with demo users and policies."""
    init_db()
    db = SessionLocal()
    
    try:
        # Check if users already exist
        existing = db.query(User).first()
        if existing:
            print("Database already seeded, skipping...")
            return
        
        # Create Council users
        council_users = [
            {
                "id": "council-user-1",
                "email": "alice.chen@ksg.ai",
                "firstName": "Alice",
                "lastName": "Chen",
                "username": "alice_chen",
                "passwordHash": hash_password("accm_1"),
                "role": "COUNCIL",
            },
            {
                "id": "council-user-2",
                "email": "bob.martinez@ksg.ai",
                "firstName": "Bob",
                "lastName": "Martinez",
                "username": "bob_martinez",
                "passwordHash": hash_password("bmcm_2"),
                "role": "COUNCIL",
            },
        ]
        
        # Create Admin users
        admin_users = [
            {
                "id": "admin-1",
                "email": "admin@example.com",
                "firstName": "System",
                "lastName": "Admin",
                "username": "admin",
                "passwordHash": hash_password("admin_pass"),
                "role": "ADMIN",
            }
        ]
        
        # Create Project users
        project_users = [
            {
                "id": "project-user-1",
                "email": "carol.davis@example.com",
                "firstName": "Carol",
                "lastName": "Davis",
                "username": "carol_davis",
                "passwordHash": hash_password("cdpt_1"),
                "role": "PROJECT",
            },
            {
                "id": "project-user-2",
                "email": "david.kim@example.com",
                "firstName": "David",
                "lastName": "Kim",
                "username": "david_kim",
                "passwordHash": hash_password("dkpt_2"),
                "role": "PROJECT",
            },
        ]
        
        for user_data in council_users + project_users + admin_users:
            user = User(**user_data)
            db.add(user)
        
        db.commit()
        print(f"Created {len(council_users)} council users, {len(project_users)} project users, and {len(admin_users)} admin users")
        
        # Create policies
        policies_data = [
            {
                "category": "AI_ETHICS",
                "fullName": "AI Ethics and Responsible AI Policy",
                "items": [
                    {
                        "title": "Fairness and Bias Mitigation",
                        "statement": "AI systems must be designed and tested to minimize unfair bias and ensure equitable treatment across all user groups.",
                        "controls": ["Bias testing", "Fairness metrics", "Diverse training data"],
                    },
                    {
                        "title": "Transparency and Explainability",
                        "statement": "AI decisions that significantly impact users must be explainable in understandable terms.",
                        "controls": ["Explainability documentation", "User-facing explanations", "Audit trails"],
                    },
                ],
            },
            {
                "category": "DATA_GOVERNANCE",
                "fullName": "Data Governance and Privacy Policy",
                "items": [
                    {
                        "title": "Data Classification",
                        "statement": "All data used in AI systems must be classified according to sensitivity levels.",
                        "controls": ["Classification labels", "Access controls", "Data inventory"],
                    },
                    {
                        "title": "Privacy by Design",
                        "statement": "AI systems must implement privacy protections from the design phase.",
                        "controls": ["Privacy impact assessment", "Data minimization", "Consent management"],
                    },
                ],
            },
            {
                "category": "MODEL_RISK",
                "fullName": "Model Risk Management Policy",
                "items": [
                    {
                        "title": "Model Validation",
                        "statement": "All AI models must undergo validation before deployment.",
                        "controls": ["Performance testing", "Accuracy metrics", "Edge case testing"],
                    },
                    {
                        "title": "Model Monitoring",
                        "statement": "Deployed models must be continuously monitored for drift and degradation.",
                        "controls": ["Drift detection", "Performance monitoring", "Alert systems"],
                    },
                ],
            },
            {
                "category": "SECURITY",
                "fullName": "AI Security Policy",
                "items": [
                    {
                        "title": "Access Control",
                        "statement": "AI systems must implement role-based access control.",
                        "controls": ["RBAC", "Authentication", "Authorization"],
                    },
                    {
                        "title": "Data Protection",
                        "statement": "AI training data and model artifacts must be encrypted.",
                        "controls": ["Encryption at rest", "Encryption in transit", "Key management"],
                    },
                ],
            },
            {
                "category": "COMPLIANCE",
                "fullName": "Regulatory Compliance Policy",
                "items": [
                    {
                        "title": "GDPR Compliance",
                        "statement": "AI systems processing EU personal data must comply with GDPR.",
                        "controls": ["DSAR handling", "Right to explanation", "Data portability"],
                    },
                    {
                        "title": "Industry Standards",
                        "statement": "AI systems must comply with relevant industry-specific regulations.",
                        "controls": ["Regulatory mapping", "Compliance audits", "Documentation"],
                    },
                ],
            },
        ]
        
        for policy_data in policies_data:
            policy = Policy(
                category=policy_data["category"],
                fullName=policy_data["fullName"],
                version=1,
                status="ACTIVE",
                updatedBy="council-user-1",
            )
            db.add(policy)
            db.commit()
            db.refresh(policy)
            
            for idx, item_data in enumerate(policy_data["items"]):
                item = PolicyItem(
                    policyId=policy.id,
                    itemIndex=idx,
                    title=item_data["title"],
                    statement=item_data["statement"],
                    controls=item_data["controls"],
                )
                db.add(item)
        
        db.commit()
        print(f"Created {len(policies_data)} policies with items")
        
        print("\n=== Demo Accounts ===")
        print("\nCouncil Members:")
        print("  alice_chen / accm_1")
        print("  bob_martinez / bmcm_2")
        print("\nAdministrators:")
        print("  admin / admin_pass")
        print("\nProject Teams:")
        print("  carol_davis / cdpt_1")
        print("  david_kim / dkpt_2")
        print("\nDatabase seeded successfully!")
        
    finally:
        db.close()


if __name__ == "__main__":
    seed_database()
